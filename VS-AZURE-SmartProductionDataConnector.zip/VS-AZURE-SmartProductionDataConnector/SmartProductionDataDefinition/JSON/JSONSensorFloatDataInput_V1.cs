﻿
namespace SmartProductionDataDefinition.JSON
{
    public class JSONSensorFloatDataInput_V1
    {
        public string SourceSystem;
        public string StagingLevel;
        public string DeviceName;
        public string SensorName;
        public string Description;
        public string Comment;
        public string Unit;
        public double MeassurementValue;
        public double MeassurementValueLSL;
        public double MeassurementValueUSL;
        public long MeassurementDateTimeJava;
    }
}
