﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartProductionDataDefinition.JSON
{
    public class JSONProcessSensorFloatDataToSmartKPIMachineFloatData_V1
    {
        public JSONSmartKPIMachineFloatData_V1 jsonSmartKPIMachineFloatData;
        public JSONSensorFloatDataOutput_V1 jsonSensorFloatDataOutput;
    }
}
