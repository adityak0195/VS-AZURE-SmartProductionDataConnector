﻿using System.Collections.Generic;

namespace SmartProductionDataDefinition.JSON
{
    public class JSONSmartKPIMachineFloatData_V1
    {
        public List<JSONSmartKPIMachineFloatDataRow_V1> rows = new List<JSONSmartKPIMachineFloatDataRow_V1>();
        public JSONSmartKPIMachineFloatDataDataShape_V1 dataShape = new JSONSmartKPIMachineFloatDataDataShape_V1();
    }
}
