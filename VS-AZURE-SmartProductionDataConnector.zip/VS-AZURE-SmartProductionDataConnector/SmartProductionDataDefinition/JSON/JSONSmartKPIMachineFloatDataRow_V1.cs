﻿using System;

namespace SmartProductionDataDefinition.JSON
{
    public class JSONSmartKPIMachineFloatDataRow_V1
    {
        public long modification_id = -1;
        public Boolean isUpdated = true;
        public string Unit;
        public Boolean move_to_history = true;
        public string Machine;
        public long UTCCreationTime;
        public double MachineData;
        public double MachineDataLSL;
        public double MachineDataUSL;
        public string Plant = "";
        public string MachineDataType;
        public string DELETE_IDENTIFIER = "DirectPush";
        public long CreationTime;
        public string Division = "";
        public long Id;
        public long MachineTime;
        public string SourceSystem;
        public string description;
        public string comment;
    }
}
