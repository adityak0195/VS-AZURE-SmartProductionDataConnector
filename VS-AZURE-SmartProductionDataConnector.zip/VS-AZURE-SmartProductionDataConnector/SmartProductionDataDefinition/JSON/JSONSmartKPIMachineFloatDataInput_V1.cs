﻿
namespace SmartProductionDataDefinition.JSON
{
    public class JSONSmartKPIMachineFloatDataInput_V1
    {
        public string SourceSystem;
        public string StagingLevel;
        public JSONSmartKPIMachineFloatData_V1 SmartKPIMachineFloatData;
    }
}
