﻿
namespace SmartProductionDataDefinition.JSON
{
    public class JSONSmartKPIMachineFloatDataDataShape_V1
    {
        public JSONSmartKPIMachineFloatDataDataShapeFieldDefinition_V1 fieldDefinitions = new JSONSmartKPIMachineFloatDataDataShapeFieldDefinition_V1();
    }
}
