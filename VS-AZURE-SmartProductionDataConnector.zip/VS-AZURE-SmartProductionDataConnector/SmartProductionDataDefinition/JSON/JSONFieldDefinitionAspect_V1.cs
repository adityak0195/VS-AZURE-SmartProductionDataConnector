﻿using System;

namespace SmartProductionDataDefinition.JSON
{
    public class JSONFieldDefinitionAspect_V1
    {
        public Boolean isPrimaryKey;
    }
}
