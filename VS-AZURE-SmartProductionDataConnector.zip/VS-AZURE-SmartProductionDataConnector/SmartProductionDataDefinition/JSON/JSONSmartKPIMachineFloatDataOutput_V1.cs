﻿
using System;

namespace SmartProductionDataDefinition.JSON
{
    public class JSONSmartKPIMachineFloatDataOutput_V1
    {
        public string Result;
        public Guid Guid;
    }
}
