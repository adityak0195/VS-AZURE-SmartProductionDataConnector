﻿namespace SmartProductionDataDefinition.JSON
{
    public class JSONFieldDefinition_V1
    {
        public string name;
        public JSONFieldDefinitionAspect_V1 aspects;
        public string description;
        public string baseType;
        public int ordinal;
    }
}
