﻿
namespace SmartProductionDataDefinition.JSON
{
    public class JSONSmartKPIMachineFloatDataDataShapeFieldDefinition_V1
    {
        public JSONFieldDefinition_V1 MachineDataLSL = new JSONFieldDefinition_V1()
        {
            name = "MachineDataLSL",
            aspects = new JSONFieldDefinitionAspect_V1(),
            description = "MachineDataLSL",
            baseType = "NUMBER",
            ordinal = 6
        };
        public JSONFieldDefinition_V1 modification_id = new JSONFieldDefinition_V1()
        {
            name = "modification_id",
            aspects = new JSONFieldDefinitionAspect_V1(),
            description = "modification_id",
            baseType = "LONG",
            ordinal = 13
        };
        public JSONFieldDefinition_V1 isUpdated = new JSONFieldDefinition_V1()
        {
            name = "isUpdated",
            aspects = new JSONFieldDefinitionAspect_V1(),
            description = "isUpdated",
            baseType = "BOOLEAN",
            ordinal = 8
        };
        public JSONFieldDefinition_V1 description = new JSONFieldDefinition_V1()
        {
            name = "description",
            aspects = new JSONFieldDefinitionAspect_V1(),
            description = "description",
            baseType = "STRING",
            ordinal = 10
        };
        public JSONFieldDefinition_V1 Unit = new JSONFieldDefinition_V1()
        {
            name = "Unit",
            aspects = new JSONFieldDefinitionAspect_V1(),
            description = "Unit",
            baseType = "STRING",
            ordinal = 9
        };
        public JSONFieldDefinition_V1 move_to_history = new JSONFieldDefinition_V1()
        {
            name = "move_to_history",
            aspects = new JSONFieldDefinitionAspect_V1(),
            description = "move_to_history",
            baseType = "BOOLEAN",
            ordinal = 14
        };
        public JSONFieldDefinition_V1 Machine = new JSONFieldDefinition_V1()
        {
            name = "Machine",
            aspects = new JSONFieldDefinitionAspect_V1(),
            description = "Machine",
            baseType = "STRING",
            ordinal = 2
        };
        public JSONFieldDefinition_V1 MachineDataUSL = new JSONFieldDefinition_V1()
        {
            name = "MachineDataUSL",
            aspects = new JSONFieldDefinitionAspect_V1(),
            description = "MachineDataUSL",
            baseType = "NUMBER",
            ordinal = 7
        };
        public JSONFieldDefinition_V1 UTCCreationTime = new JSONFieldDefinition_V1()
        {
            name = "UTCCreationTime",
            aspects = new JSONFieldDefinitionAspect_V1(),
            description = "UTCCreationTime",
            baseType = "DATETIME",
            ordinal = 12
        };
        public JSONFieldDefinition_V1 MachineData = new JSONFieldDefinition_V1()
        {
            name = "MachineData",
            aspects = new JSONFieldDefinitionAspect_V1(),
            description = "MachineData",
            baseType = "NUMBER",
            ordinal = 5
        };
        public JSONFieldDefinition_V1 Plant = new JSONFieldDefinition_V1()
        {
            name = "Plant",
            aspects = new JSONFieldDefinitionAspect_V1(),
            description = "Plant",
            baseType = "STRING",
            ordinal = 0
        };
        public JSONFieldDefinition_V1 MachineDataType = new JSONFieldDefinition_V1()
        {
            name = "MachineDataType",
            aspects = new JSONFieldDefinitionAspect_V1(),
            description = "MachineDataType",
            baseType = "STRING",
            ordinal = 4
        };
        public JSONFieldDefinition_V1 DELETE_IDENTIFIER = new JSONFieldDefinition_V1()
        {
            name = "DELETE_IDENTIFIER",
            aspects = new JSONFieldDefinitionAspect_V1(),
            description = "DELETE_IDENTIFIER",
            baseType = "STRING",
            ordinal = 0
        };
        public JSONFieldDefinition_V1 CreationTime = new JSONFieldDefinition_V1()
        {
            name = "CreationTime",
            aspects = new JSONFieldDefinitionAspect_V1(),
            description = "CreationTime",
            baseType = "DATETIME",
            ordinal = 1
        };
        public JSONFieldDefinition_V1 comment = new JSONFieldDefinition_V1()
        {
            name = "comment",
            aspects = new JSONFieldDefinitionAspect_V1(),
            description = "comment",
            baseType = "STRING",
            ordinal = 11
        };
        public JSONFieldDefinition_V1 Division = new JSONFieldDefinition_V1()
        {
            name = "Division",
            aspects = new JSONFieldDefinitionAspect_V1(),
            description = "Division",
            baseType = "STRING",
            ordinal = 0
        };
        public JSONFieldDefinition_V1 Id = new JSONFieldDefinition_V1()
        {
            name = "Id",
            aspects = new JSONFieldDefinitionAspect_V1(),
            description = "Id",
            baseType = "LONG",
            ordinal = 0
        };
        public JSONFieldDefinition_V1 MachineTime = new JSONFieldDefinition_V1()
        {
            name = "MachineTime",
            aspects = new JSONFieldDefinitionAspect_V1(),
            description = "MachineTime",
            baseType = "DATETIME",
            ordinal = 3
        };
        public JSONFieldDefinition_V1 SourceSystem = new JSONFieldDefinition_V1()
        {
            name = "SourceSystem",
            aspects = new JSONFieldDefinitionAspect_V1() { isPrimaryKey = true},
            description = "SourceSystem",
            baseType = "STRING",
            ordinal = 0
        };
    }
}
