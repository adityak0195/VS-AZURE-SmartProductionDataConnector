﻿
using System;

namespace SmartProductionDataDefinition.JSON
{
    public class JSONSensorFloatDataOutput_V1
    {
        public string Result;
        public JSONSensorFloatDataInput_V1 JSONinput;
        public Guid Guid;
    }
}
