﻿using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.WindowsAzure.Storage.Auth;
using Microsoft.WindowsAzure.Storage.Blob;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartProductionDataConnectorManualChecks_V1
{
    public class Worker
    {
        public static void getFilesWithId(string sourcePath, string id)
        {
            string storageAccountName = "prdthingworxqrjxoxst00";
            string containerName = "smartproductiondataupload-v3";
            string sasToken = "sp=rl&st=2024-04-16T09:04:02Z&se=2025-12-31T18:04:02Z&spr=https&sv=2022-11-02&sr=c&sig=STTfhR0xkc9wDgGX%2FBA1WkvsBuaoixVVF%2FBhu2vhc1Y%3D";

            string blobUri = "https://" + storageAccountName + ".blob.core.windows.net";

            BlobServiceClient blobSourceServiceClient = new BlobServiceClient
            (new Uri($"{blobUri}?{sasToken}"), null);

            BlobContainerClient blobContainerClient = blobSourceServiceClient.GetBlobContainerClient(containerName);




            // Call the listing operation and return pages of the specified size.
            var resultSegment = blobContainerClient.GetBlobs(BlobTraits.None, BlobStates.None, sourcePath)
                .AsPages(default, 1000);

            // Enumerate the blobs returned for each page.
            foreach (Page<BlobItem> blobPage in resultSegment)
            {
                foreach (BlobItem blobItem in blobPage.Values)
                {
                    //Console.WriteLine("**********************************************************");
                    if (blobItem == null)
                    {
                        Console.WriteLine("NULL");
                    }
                    else if (blobItem.Name.ToLower().EndsWith(".json"))
                    {

                        //reading source data
                        BlobDownloadResult sourceContent = blobContainerClient.GetBlobClient(blobItem.Name).DownloadContent();
                        string contentString = sourceContent.Content.ToString();
                        if (contentString.Contains(id))
                        {
                            Console.WriteLine("Blob name: {0}", blobItem.Name);
                        }
                    }
                }
            }

            Console.WriteLine("*****READY*****");
            Console.ReadLine();
        }
    }
}
