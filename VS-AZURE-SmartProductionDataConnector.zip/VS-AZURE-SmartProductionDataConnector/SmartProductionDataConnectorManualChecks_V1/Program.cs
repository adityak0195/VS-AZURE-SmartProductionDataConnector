﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
SmartProductionDataConnectorManualChecks_V1.Worker.getFilesWithId("PROD/CVS/smartKPIValues/2024/4/12/smartproductionBER.corp.knorr-bremse.com", "731527817");