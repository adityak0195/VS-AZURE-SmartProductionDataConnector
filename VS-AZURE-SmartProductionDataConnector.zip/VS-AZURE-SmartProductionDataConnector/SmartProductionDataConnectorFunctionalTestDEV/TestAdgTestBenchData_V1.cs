﻿
namespace SmartProductionDataConnectorFunctionalTestDEV

{
    [TestClass]
    public class TestAdgTestBenchData_V1
    {
        /************************************************************************************************
         * 
         * This test uploads data via the AdgTestBenchData_V1 function to the 
         * final BlobStorage --> GlobalSettings_V1.BLOB_CONTAINER 
         * an checks if content is in BlobStorage
         * 
         ************************************************************************************************/

        [TestMethod]
        public async Task DoAdgTestBenchDataTests_DEV_WEEU()
        {
            string StagingLevel = "DEV";
            Uri url_AdgTestBenchData_V1 = new("https://dev-thingworx-weeu-smartproduction-4rhjurm-funcapp.azurewebsites.net/api/AdgTestBenchData_V1?code=XJpRyUMnb7dtfdBGogRfLXoVkmpFPpo8pW3WzH2kY0jZAzFuSc76Pw==");
            string connectionstring = "DefaultEndpointsProtocol=https;AccountName=devthingworxpw6mcest00;AccountKey=wAqnNKqmb6gpof4lr8XT20zCujC5lXgXU9hBvEAl5fwVhUHFOHxtP7jyMr3GANH2/f3qQbDC5ytN+AStVB1/eA==;EndpointSuffix=core.windows.net";


            SmartProductionDataConnectorFunctionalTest.TestAdgTestBenchData_V1 testAdgTestBenchData_V1 = new();
            await testAdgTestBenchData_V1.DoAdgTestBenchDataTests(StagingLevel, url_AdgTestBenchData_V1, connectionstring, connectionstring);
        }


    }
}