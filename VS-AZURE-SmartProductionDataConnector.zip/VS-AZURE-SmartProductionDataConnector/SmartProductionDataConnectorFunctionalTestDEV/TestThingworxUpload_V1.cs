﻿
namespace SmartProductionDataConnectorFunctionalTestDEV
{
    [TestClass]
    public class TestThingworxUpload_V1
    {

        /************************************************************************************************
         * 
         * This test uploads data via the ThingworxUpload_V1 function to the 
         * final BlobStorage --> GlobalSettings_V1.BLOB_CONTAINER 
         * an checks if content is in BlobStorage
         * 
         * Same for data with DELETE IDENTIFIER
         * 
         ************************************************************************************************/

        [TestMethod]
        public async Task DoThingworxUploadTests_DEV_WEEU()
        {
            string StagingLevel = "DEV";
            Uri url_ThingworxUpload_V1 = new("https://dev-thingworx-weeu-smartproduction-4rhjurm-funcapp.azurewebsites.net/api/ThingworxUpload_V1?code=yUHgUCeHeUQAWBwcLKn1viz6ST383NAH26do-IC18mAXAzFujGQ3kg==");
            Uri url_ThingworxDeletedUpload_V1 = new("https://dev-thingworx-weeu-smartproduction-4rhjurm-funcapp.azurewebsites.net/api/ThingworxDeletedUpload_V1?code=cCdF3pWHp8Bg23vLW89Bx0_F3ErYrQ82BqEwzyZnVeZWAzFubSqUpg==");
            string connectionstring = "DefaultEndpointsProtocol=https;AccountName=devthingworxpw6mcest00;AccountKey=wAqnNKqmb6gpof4lr8XT20zCujC5lXgXU9hBvEAl5fwVhUHFOHxtP7jyMr3GANH2/f3qQbDC5ytN+AStVB1/eA==;EndpointSuffix=core.windows.net";

            SmartProductionDataConnectorFunctionalTest.TestThingworxUpload_V1 testThingworxUpload_V1 = new();
            await testThingworxUpload_V1.DoThingworxUploadTests(StagingLevel, url_ThingworxUpload_V1, url_ThingworxDeletedUpload_V1, connectionstring);
        }

    }
}