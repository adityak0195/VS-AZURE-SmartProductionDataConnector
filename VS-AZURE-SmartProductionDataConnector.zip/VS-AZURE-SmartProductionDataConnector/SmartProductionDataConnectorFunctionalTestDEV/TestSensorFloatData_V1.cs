

namespace SmartProductionDataConnectorFunctionalTestDEV
{
    [TestClass]
    public class TestSensorFloatData_V1
    {

        /************************************************************************************************
         * 
         * This test uploads data via the SensorFloatData_V1 function to the buffer BlobStorage 
         * an checks if file is in BlobStorage
         * 
         * After 5 Min content must be in final BlobStorage --> GlobalSettings_V1.BLOB_CONTAINER
         * 
         ************************************************************************************************/

        [TestMethod]
        public async Task DoSensorFloatDataTestsWEEUDEV()
        {
            string StagingLevel = "DEV";
            Uri url = new("https://dev-thingworx-weeu-smartproduction-4rhjurm-funcapp.azurewebsites.net/api/SensorFloatData_V1?code=_NsuNo8Pr6RNVq8reviuwP8AzGHFfcySu_QssGE1GzGKAzFuiICS6A==");
            string connectionstring = "DefaultEndpointsProtocol=https;AccountName=devthingworxpw6mcest00;AccountKey=wAqnNKqmb6gpof4lr8XT20zCujC5lXgXU9hBvEAl5fwVhUHFOHxtP7jyMr3GANH2/f3qQbDC5ytN+AStVB1/eA==;EndpointSuffix=core.windows.net";

            SmartProductionDataConnectorFunctionalTest.TestSensorFloatData_V1 testSensorFloatData_V1 = new();
            await testSensorFloatData_V1.DoSensorFloatDataTests(StagingLevel, url, connectionstring, connectionstring);
        }

        //        [TestMethod]
        //        public async Task DoSensorFloatDataTestsSEASUDEV()
        //        {
        //            string StagingLevel = "DEV";
        //            Uri url = new("https://dev-thingworx-seas-smartproduction-dtaicl4-funcapp.azurewebsites.net/api/SensorFloatData_V1?code=_OQzXJrjHdK0EH-FXhn2AA1p_wQYd6wur_cYCyWv_3QAAzFuUDPzMQ==");
        //            string connectionstringBuffer = "DefaultEndpointsProtocol=https;AccountName=devthingworxpw6mcest00;AccountKey=wAqnNKqmb6gpof4lr8XT20zCujC5lXgXU9hBvEAl5fwVhUHFOHxtP7jyMr3GANH2/f3qQbDC5ytN+AStVB1/eA==;EndpointSuffix=core.windows.net";
        //            string connectionstringFinal = "DefaultEndpointsProtocol=https;AccountName=devthingworxpw6mcest00;AccountKey=wAqnNKqmb6gpof4lr8XT20zCujC5lXgXU9hBvEAl5fwVhUHFOHxtP7jyMr3GANH2/f3qQbDC5ytN+AStVB1/eA==;EndpointSuffix=core.windows.net";
        //
        //            await DoSensorFloatDataTests(StagingLevel, url, connectionstringBuffer, connectionstringFinal);
        //        }

    }
}