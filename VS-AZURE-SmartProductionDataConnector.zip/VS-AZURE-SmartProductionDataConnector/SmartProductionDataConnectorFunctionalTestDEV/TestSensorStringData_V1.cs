
namespace SmartProductionDataConnectorFunctionalTestDEV
{
    [TestClass]
    public class TestSensorStringData_V1
    {
        /************************************************************************************************
         * 
         * This test uploads data via the SensorStringData_V1 function to the buffer BlobStorage 
         * an checks if file is in BlobStorage
         * 
         * After 5 Min content must be in final BlobStorage --> GlobalSettings_V1.BLOB_CONTAINER
         * 
         ************************************************************************************************/

        [TestMethod]
        public async Task DoSensorStringDataTestsWEEUDEV()
        {
            string StagingLevel = "DEV";
            Uri url = new("https://dev-thingworx-weeu-smartproduction-4rhjurm-funcapp.azurewebsites.net/api/SensorStringData_V1?code=nqR6V_Hn21gZcEHNTH9jbfXIp1V2NdV9Bw94poAAZM68AzFu_PwDyA==");
            string connectionstring = "DefaultEndpointsProtocol=https;AccountName=devthingworxpw6mcest00;AccountKey=wAqnNKqmb6gpof4lr8XT20zCujC5lXgXU9hBvEAl5fwVhUHFOHxtP7jyMr3GANH2/f3qQbDC5ytN+AStVB1/eA==;EndpointSuffix=core.windows.net";
            string bufferContainer = "buffer-dev-functionaltest";

            SmartProductionDataConnectorFunctionalTest.TestSensorStringData_V1 testSensorStringData_V1 = new();
            await testSensorStringData_V1.DoSensorStringDataTests(StagingLevel, url, connectionstring, connectionstring, bufferContainer);
        }

        //        [TestMethod]
        //        public async Task DoSensorStringDataTestsSEASUDEV()
        //        {
        //            string StagingLevel = "DEV";
        //            Uri url = new("https://dev-thingworx-seas-smartproduction-dtaicl4-funcapp.azurewebsites.net/api/SensorStringData_V1?code=_OQzXJrjHdK0EH-FXhn2AA1p_wQYd6wur_cYCyWv_3QAAzFuUDPzMQ==");
        //            string connectionstringBuffer = "DefaultEndpointsProtocol=https;AccountName=devthingworxpw6mcest00;AccountKey=wAqnNKqmb6gpof4lr8XT20zCujC5lXgXU9hBvEAl5fwVhUHFOHxtP7jyMr3GANH2/f3qQbDC5ytN+AStVB1/eA==;EndpointSuffix=core.windows.net";
        //            string connectionstringFinal = "DefaultEndpointsProtocol=https;AccountName=devthingworxpw6mcest00;AccountKey=wAqnNKqmb6gpof4lr8XT20zCujC5lXgXU9hBvEAl5fwVhUHFOHxtP7jyMr3GANH2/f3qQbDC5ytN+AStVB1/eA==;EndpointSuffix=core.windows.net";
        //            string bufferContainer = "buffer-dev-functionaltest";
        //
        //            await DoSensorStringDataTests(StagingLevel, url, connectionstringBuffer, connectionstringFinal, bufferContainer);
        //        }



    }
}