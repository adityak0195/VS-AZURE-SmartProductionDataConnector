﻿
namespace SmartProductionDataConnectorFunctionalTestPRD
{
    [TestClass]
    public class TestThingworxUpload_V1
    {


        /************************************************************************************************
         * 
         * This test uploads data via the ThingworxUpload_V1 function to the 
         * final BlobStorage --> GlobalSettings_V1.BLOB_CONTAINER 
         * an checks if content is in BlobStorage
         * 
         * Same for data with DELETE IDENTIFIER
         * 
         ************************************************************************************************/



       [TestMethod]
       public async Task DoThingworxUploadTests_PROD_WEEU()
       {
           string StagingLevel = "PROD";
           Uri url_ThingworxUpload_V1 =        new("https://prd-thingworx-weeu-smartproduction-zymir4x-funcapp.azurewebsites.net/api/ThingworxUpload_V1?code=TwFBRz7RztIy8W8deoRaD1Q2bWtD9zBzpZGGNcDEZzyRAzFunPAY5w==");
           Uri url_ThingworxDeletedUpload_V1 = new("https://prd-thingworx-weeu-smartproduction-zymir4x-funcapp.azurewebsites.net/api/ThingworxDeletedUpload_V1?code=rfM_h3Q-zcC8UDI7tzbzWPbxclJnFV2ccNEbYHudbhbIAzFuNBQGOw==");
           string connectionstring = "DefaultEndpointsProtocol=https;AccountName=prdthingworxqrjxoxst00;AccountKey=mHm7uVP44GwqY1/NK5nGqVrB1cHs4u3mXsd8zlxp59mg/KEV0Y/t7oHdZWfzaS5r6ozoVJ5Ebmqa+AStWhtK0w==;EndpointSuffix=core.windows.net";

            SmartProductionDataConnectorFunctionalTest.TestThingworxUpload_V1 testThingworxUpload_V1 = new();
            await testThingworxUpload_V1.DoThingworxUploadTests(StagingLevel, url_ThingworxUpload_V1, url_ThingworxDeletedUpload_V1, connectionstring);
        }



    }
}
