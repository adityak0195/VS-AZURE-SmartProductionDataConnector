
namespace SmartProductionDataConnectorFunctionalTestPRD
{
    [TestClass]
    public class TestSensorStringData_V1
    {
        
        /************************************************************************************************
         * 
         * This test uploads data via the SensorStringData_V1 function to the buffer BlobStorage 
         * an checks if file is in BlobStorage
         * 
         * After 5 Min content must be in final BlobStorage --> GlobalSettings_V1.BLOB_CONTAINER
         * 
         ************************************************************************************************/



        [TestMethod]
        public async Task DoSensorStringDataTestsWEEUPROD()
        {
            string StagingLevel = "PROD";
            Uri url = new("https://prd-thingworx-weeu-smartproduction-zymir4x-funcapp.azurewebsites.net/api/SensorStringData_V1?code=SSNDYJ42LHsPrV1EnJdlLkEkTO1K63bixkMFswsYL-AtAzFuUXSZsw==");
            string connectionstring = "DefaultEndpointsProtocol=https;AccountName=prdthingworxqrjxoxst00;AccountKey=mHm7uVP44GwqY1/NK5nGqVrB1cHs4u3mXsd8zlxp59mg/KEV0Y/t7oHdZWfzaS5r6ozoVJ5Ebmqa+AStWhtK0w==;EndpointSuffix=core.windows.net";
            string bufferContainer = "buffer-prod-functionaltest";

            SmartProductionDataConnectorFunctionalTest.TestSensorStringData_V1 testSensorStringData_V1 = new();
            await testSensorStringData_V1.DoSensorStringDataTests(StagingLevel, url, connectionstring, connectionstring, bufferContainer);
        }


    }
}