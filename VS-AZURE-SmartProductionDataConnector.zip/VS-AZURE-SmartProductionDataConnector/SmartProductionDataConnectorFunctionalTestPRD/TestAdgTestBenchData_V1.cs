﻿
namespace SmartProductionDataConnectorFunctionalTestPRD
{
    [TestClass]
    public class TestAdgTestBenchData_V1
    {

        /************************************************************************************************
         * 
         * This test uploads data via the AdgTestBenchData_V1 function to the 
         * final BlobStorage --> GlobalSettings_V1.BLOB_CONTAINER 
         * an checks if content is in BlobStorage
         * 
         ************************************************************************************************/


        //       [TestMethod]
        //      public async Task DoAdgTestBenchDataTests_PROD_WEEU()
        //      {
        //          string StagingLevel = "PROD";
        //          Uri url_AdgTestBenchData_V1 =        new("https://prd-thingworx-weeu-smartproduction-zymir4x-funcapp.azurewebsites.net/api/AdgTestBenchData_V1?code=TwFBRz7RztIy8W8deoRaD1Q2bWtD9zBzpZGGNcDEZzyRAzFunPAY5w==");
        //          string connectionstring = "DefaultEndpointsProtocol=https;AccountName=prdthingworxqrjxoxst00;AccountKey=mHm7uVP44GwqY1/NK5nGqVrB1cHs4u3mXsd8zlxp59mg/KEV0Y/t7oHdZWfzaS5r6ozoVJ5Ebmqa+AStWhtK0w==;EndpointSuffix=core.windows.net";
        //
        //          SmartProductionDataConnectorFunctionalTest.TestAdgTestBenchData_V1 testAdgTestBenchData_V1 = new();
        //          await testAdgTestBenchData_V1.DoAdgTestBenchDataTests(StagingLevel, url_AdgTestBenchData_V1, connectionstring);
        //      }

    }
}
