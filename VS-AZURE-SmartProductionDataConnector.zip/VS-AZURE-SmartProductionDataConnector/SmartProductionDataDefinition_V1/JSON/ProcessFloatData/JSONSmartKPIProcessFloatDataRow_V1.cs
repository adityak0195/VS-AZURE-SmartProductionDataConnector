﻿using System;

namespace SmartProductionDataDefinition_V1.JSON.ProcessFloatData
{
    public class JSONSmartKPIProcessFloatDataRow_V1
    {
        public long Id;
        public long CreationTime;
        public string? Machine;
        public long ProductionTime;
        public string? ProcesDataType;
        public double? ProcesData;
        public string? SerialNumber;
        public string? PartNumber;
        public string? OrderNumber;
        public long? modification_id = -1;
        public bool? move_to_history = true;
        public long UTCCreationTime;
        public double? ProcesDataLSL;
        public double? ProcesDataUSL;
        public bool? isUpdated = true;
        public string? Unit;
        public string? description;
        public string? comment;
        public string? TrackingNumber;
        public string? ProcesDataType2;
        public string? PartNumberRevision;
        public string? Identifier;
        public string? ProcesDataPrecision;
        public string? ProcesDataTargetValueName;
        public double? ProcesDataTargetValue;
        public string? ProcesDataLowerLimitName;
        public string? ProcesDataUpperLimitName;
        public string? ProcesDataTolerancePos;
        public double? ProcesDataTolerancePosFloat;
        public string? ProcesDataToleranceNeg;
        public double? ProcesDataToleranceNegFloat;
        public string? ProcessDataTargetValueTolUnit;

        public string? Plant = "";
        public string? DELETE_IDENTIFIER = "DirectPush";
        public string? Division = "";
        public string? SourceSystem;
    }
}
