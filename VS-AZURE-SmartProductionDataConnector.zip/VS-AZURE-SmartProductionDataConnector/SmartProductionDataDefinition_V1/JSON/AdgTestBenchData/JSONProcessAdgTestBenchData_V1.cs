﻿

using Newtonsoft.Json.Linq;

namespace SmartProductionDataDefinition_V1.JSON.AdgTestBenchData
{
    public class JSONProcessAdgTestBenchData_V1
    {
        public JToken? jsonAdgTestBenchDataDatas;
        public JSONAdgTestBenchDataOutput_V1? jsonAdgTestBenchDataOutput;
    }
}
