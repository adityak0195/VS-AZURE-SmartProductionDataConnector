﻿using System.Reflection.Metadata;

namespace SmartProductionDataDefinition_V1.JSON.AdgTestBenchData
{
    public class JSONAdgTestBenchData_V1
    {
        public Boolean isProcessDataString;
        public Boolean isProcessDataDateTime;
        public Boolean isProcessDataFloat;
        public Boolean isProcessDataBlob;

        public string? ProcessDataString;
        public Blob? ProcessDataBlob;
        public string? ProcessDataStringTargetValue;
        public long? ProcessDataDateTime;
        public long? ProcessDataDateTimeTargetValue;
        public double? ProcessDataFloat;
        public double? ProcessDataFloatTargetValue;
        public string? ProcessDataTargetValueName;
        public string? ProcessDataLowerLimitName;
        public string? ProcessDataUpperLimitName;
        public double? ProcessDataToleranceNeg;
        public double? ProcessDataTolerancePos;
        public double? ProcessDataLSL;
        public double? ProcessDataUSL;
        public string? ProcessDataPrecision;
        public string? Unit;

        public string? Description;
        public string? PartNumber;
        public string? PartNumberRevision;
        public string? TrackingNumber;
        public string? OrderNumber;
        public long ProductionDateTime;
        public string? Identifier;
        public string? SerialNumber;
        public string? ProcessDataType;
        public string? ProcessDataType2;
    }
}
