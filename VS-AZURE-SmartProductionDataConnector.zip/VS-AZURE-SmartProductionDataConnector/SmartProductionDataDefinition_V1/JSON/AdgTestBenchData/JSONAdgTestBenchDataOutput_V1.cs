﻿
using System;
using SmartProductionDataDefinition_V1.JSON.Template;

namespace SmartProductionDataDefinition_V1.JSON.AdgTestBenchData
{
    public class JSONAdgTestBenchDataOutput_V1 : JSONDataOutput_V1
    {
        public JSONAdgTestBenchDataInput_V1? JSONinput;
    }
}
