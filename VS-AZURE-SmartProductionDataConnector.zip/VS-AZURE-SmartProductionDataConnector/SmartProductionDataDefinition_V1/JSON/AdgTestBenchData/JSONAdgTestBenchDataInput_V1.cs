﻿using Newtonsoft.Json.Linq;
using SmartProductionDataDefinition_V1.JSON.Template;

namespace SmartProductionDataDefinition_V1.JSON.AdgTestBenchData
{
    public class JSONAdgTestBenchDataInput_V1 : JSONDataInput_V1
    {
        public List<JSONAdgTestBenchData_V1>? rows;
    }
}
