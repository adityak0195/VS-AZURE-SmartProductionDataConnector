﻿using SmartProductionDataDefinition_V1.JSON.SensorFloatData;
using SmartProductionDataDefinition_V1.JSON.SensorStringData;
using SmartProductionDataDefinition_V1.JSON.ThingworxUpload;
using SmartProductionDataDefinition_V1.JSON.AdgTestBenchData;

namespace SmartProductionDataDefinition_V1.JSON.Template
{
    public class JSONDataOutput_V1
    {
        public string? Result;
        public Guid? Guid;

        public JSONSensorFloatDataOutput_V1 JSONSensorFloatDataOutput_V1()
        {
            return new JSONSensorFloatDataOutput_V1 { Result = Result, Guid = Guid };
        }

        public JSONSensorStringDataOutput_V1 JSONSensorStringDataOutput_V1()
        {
            return new JSONSensorStringDataOutput_V1 { Result = Result, Guid = Guid };
        }

        public JSONThingworxUploadOutput_V1 JSONThingworxUploadOutput_V1()
        {
            return new JSONThingworxUploadOutput_V1 { Result = Result, Guid = Guid };
        }

        public JSONAdgTestBenchDataOutput_V1 JSONAdgTestBenchDataOutput_V1()
        {
            return new JSONAdgTestBenchDataOutput_V1 { Result = Result, Guid = Guid };
        }
    }
}
