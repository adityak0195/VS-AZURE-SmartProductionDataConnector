﻿
using Newtonsoft.Json.Linq;

namespace SmartProductionDataDefinition_V1.JSON.Template
{
    public class TWXInfotable2JSON_V1
    {
        public class TWXInfotableData
        {
            public JToken? rows;
            public JToken? dataShape;
        }
    }
}
