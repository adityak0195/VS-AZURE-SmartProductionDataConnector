﻿using System;

namespace SmartProductionDataDefinition_V1.JSON.Template
{
    public class JSONFieldDefinitionAspect_V1
    {
        public bool isPrimaryKey;
    }
}
