﻿using SmartProductionDataDefinition_V1.JSON.SensorFloatData;

namespace SmartProductionDataDefinition_V1.JSON.Template
{
    public class JSONDataInput_V1
    {
        public string? SourceSystem;
        public string? StagingLevel;
        public string? TableName;

        public JSONSensorFloatDataInput_V1 JSONSensorFloatDataInput_V1()
        {
            return new JSONSensorFloatDataInput_V1 { SourceSystem = SourceSystem, StagingLevel = StagingLevel };
        }
    }
}
