﻿
using Newtonsoft.Json.Linq;

namespace SmartProductionDataDefinition_V1.JSON.Template
{
    public class TWXDataRow2JSON_V1 : JSONDataInput_V1
    {
            public JToken? rows;
    }
}
