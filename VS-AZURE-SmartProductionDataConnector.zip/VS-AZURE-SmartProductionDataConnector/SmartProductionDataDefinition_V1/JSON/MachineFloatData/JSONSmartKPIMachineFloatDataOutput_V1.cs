﻿
using System;
using SmartProductionDataDefinition_V1.JSON.Template;

namespace SmartProductionDataDefinition_V1.JSON.MachineFloatData
{
    public class JSONSmartKPIMachineFloatDataOutput_V1 : JSONDataOutput_V1
    {
        public JSONSmartKPIMachineFloatDataInput_V1? JSONinput;
    }
}
