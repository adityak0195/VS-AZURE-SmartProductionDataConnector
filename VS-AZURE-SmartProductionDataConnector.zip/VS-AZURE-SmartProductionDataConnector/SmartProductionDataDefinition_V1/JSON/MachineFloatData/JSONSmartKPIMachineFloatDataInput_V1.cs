﻿using SmartProductionDataDefinition_V1.JSON.Template;

namespace SmartProductionDataDefinition_V1.JSON.MachineFloatData
{
    public class JSONSmartKPIMachineFloatDataInput_V1 : JSONDataInput_V1
    {
        public List<JSONSmartKPIMachineFloatDataRow_V1> rows = new();
    }
}
