﻿

namespace SmartProductionDataDefinition_V1.JSON.MachineFloatData
{
    public class JSONProcessMachineFloatData_V1
    {
        public List<JSONSmartKPIMachineFloatDataRow_V1> jsonSmartKPIMachineFloatDatas = new List<JSONSmartKPIMachineFloatDataRow_V1>();
        public JSONSmartKPIMachineFloatDataOutput_V1? jsonMachineFloatDataOutput;
    }
}
