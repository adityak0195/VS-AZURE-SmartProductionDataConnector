﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SmartProductionDataDefinition_V1.JSON.MachineStringData;

namespace SmartProductionDataDefinition_V1.JSON.SensorStringData
{
    public class JSONProcessSensorStringDataToSmartKPIMachineStringData_V1
    {
        public JSONSmartKPIMachineStringDataRow_V1? jsonSmartKPIMachineStringData;
        public JSONSensorStringDataOutput_V1? jsonSensorStringDataOutput;
    }
}
