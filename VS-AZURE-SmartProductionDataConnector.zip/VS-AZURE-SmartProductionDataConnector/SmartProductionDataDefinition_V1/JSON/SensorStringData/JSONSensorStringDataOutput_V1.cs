﻿
using System;
using SmartProductionDataDefinition_V1.JSON.Template;

namespace SmartProductionDataDefinition_V1.JSON.SensorStringData
{
    public class JSONSensorStringDataOutput_V1 : JSONDataOutput_V1
    {
        public JSONSensorStringDataInput_V1? JSONinput;
    }
}
