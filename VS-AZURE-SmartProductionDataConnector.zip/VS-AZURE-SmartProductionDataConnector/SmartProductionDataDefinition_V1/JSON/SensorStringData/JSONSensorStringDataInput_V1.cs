﻿using SmartProductionDataDefinition_V1.JSON.Template;

namespace SmartProductionDataDefinition_V1.JSON.SensorStringData
{
    public class JSONSensorStringDataInput_V1 : JSONDataInput_V1
    {
        public string? DeviceName;
        public string? SensorName;
        public string? Description;
        public string? Comment;
        public string? Plant;
        public string? Division;
        public string? MeassurementValue;
        public long MeassurementDateTimeJava;
    }
}
