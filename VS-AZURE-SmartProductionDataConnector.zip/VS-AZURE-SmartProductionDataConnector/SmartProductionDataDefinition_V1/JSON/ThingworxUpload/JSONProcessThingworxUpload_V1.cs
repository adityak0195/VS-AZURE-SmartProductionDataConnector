﻿

using Newtonsoft.Json.Linq;

namespace SmartProductionDataDefinition_V1.JSON.ThingworxUpload
{
    public class JSONProcessThingworxUpload_V1
    {
        public JToken? jsonThingworxUploadDatas;
        public JSONThingworxUploadOutput_V1? jsonThingworxUploadOutput;
    }
}
