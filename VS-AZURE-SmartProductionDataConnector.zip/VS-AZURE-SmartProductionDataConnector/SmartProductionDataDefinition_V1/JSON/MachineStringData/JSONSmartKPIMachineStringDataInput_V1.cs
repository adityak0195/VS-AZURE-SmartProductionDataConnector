﻿using SmartProductionDataDefinition_V1.JSON.Template;

namespace SmartProductionDataDefinition_V1.JSON.MachineStringData
{
    public class JSONSmartKPIMachineStringDataInput_V1 : JSONDataInput_V1
    {
        public List<JSONSmartKPIMachineStringDataRow_V1> rows = new();
    }
}
