﻿
using System;
using SmartProductionDataDefinition_V1.JSON.Template;

namespace SmartProductionDataDefinition_V1.JSON.MachineStringData
{
    public class JSONSmartKPIMachineStringDataOutput_V1 : JSONDataOutput_V1
    {
        public JSONSmartKPIMachineStringDataInput_V1? JSONinput;
    }
}
