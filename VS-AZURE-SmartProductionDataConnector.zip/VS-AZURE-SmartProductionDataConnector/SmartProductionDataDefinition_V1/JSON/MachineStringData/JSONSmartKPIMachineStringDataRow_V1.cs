﻿using System;

namespace SmartProductionDataDefinition_V1.JSON.MachineStringData
{
    public class JSONSmartKPIMachineStringDataRow_V1
    {
        public long? modification_id = -1;
        public bool? move_to_history = true;
        public string? Machine;
        public long UTCCreationTime;
        public string? MachineData;
        public string? Plant = "";
        public string? MachineDataType;
        public string? DELETE_IDENTIFIER = "DirectPush";
        public long CreationTime;
        public string? Division = "";
        public long Id;
        public long MachineTime;
        public string? SourceSystem;
        public string? description;
        public string? comment;
    }
}
