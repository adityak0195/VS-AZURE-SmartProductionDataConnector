﻿

namespace SmartProductionDataDefinition_V1.JSON.MachineStringData
{
    public class JSONProcessMachineStringData_V1
    {
        public List<JSONSmartKPIMachineStringDataRow_V1> jsonSmartKPIMachineStringDatas = new List<JSONSmartKPIMachineStringDataRow_V1>();
        public JSONSmartKPIMachineStringDataOutput_V1? jsonMachineStringDataOutput;
    }
}
