﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SmartProductionDataDefinition_V1.JSON.MachineFloatData;

namespace SmartProductionDataDefinition_V1.JSON.SensorFloatData
{
    public class JSONProcessSensorFloatDataToSmartKPIMachineFloatData_V1
    {
        public JSONSmartKPIMachineFloatDataRow_V1? jsonSmartKPIMachineFloatData;
        public JSONSensorFloatDataOutput_V1? jsonSensorFloatDataOutput;
    }
}
