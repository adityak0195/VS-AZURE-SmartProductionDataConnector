﻿using SmartProductionDataDefinition_V1.JSON.Template;

namespace SmartProductionDataDefinition_V1.JSON.SensorFloatData
{
    public class JSONSensorFloatDataInput_V1 : JSONDataInput_V1
    {
        public string? DeviceName;
        public string? SensorName;
        public string? Description;
        public string? Comment;
        public string? Unit;
        public string? Plant;
        public string? Division;
        public double MeassurementValue;
        public double MeassurementValueLSL;
        public double MeassurementValueUSL;
        public long MeassurementDateTimeJava;
    }
}
