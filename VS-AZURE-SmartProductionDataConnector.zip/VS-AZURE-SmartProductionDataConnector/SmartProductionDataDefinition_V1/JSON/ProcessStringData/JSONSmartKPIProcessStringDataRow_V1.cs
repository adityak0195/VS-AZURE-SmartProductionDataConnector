﻿using System;

namespace SmartProductionDataDefinition_V1.JSON.ProcessStringData
{
    public class JSONSmartKPIProcessStringDataRow_V1
    {
        public long Id;
        public long CreationTime;
        public string? Machine;
        public string? ProcesDataType;
        public string? ProcesDataType2;
        public long ProductionTime;
        public string? ProcesData;
        public string? SerialNumber;
        public string? PartNumber;
        public string? OrderNumber;
        public string? TrackingNumber;
        public string? PartNumberRevision;
        public string? Identifier;
        public string? ProcesDataTargetValue;
        public string? description;
        public string? comment;
        public long? modification_id = -1;
        public bool? move_to_history = true;
        public long UTCCreationTime;

        public string? Plant = "";
        public string? DELETE_IDENTIFIER = "DirectPush";
        public string? Division = "";
        public string? SourceSystem;
    }
}
