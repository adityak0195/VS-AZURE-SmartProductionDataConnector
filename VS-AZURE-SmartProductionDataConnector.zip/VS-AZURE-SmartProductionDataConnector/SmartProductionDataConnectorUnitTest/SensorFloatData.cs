﻿
using SmartProductionDataConnector.Logic;
using SmartProductionDataDefinition_V1.JSON.SensorFloatData;
using SmartProductionDataDefinition_V1.JSON.Template;
using System.IO;

namespace SmartProductionDataConnectorUnitTest
{
    [TestClass]
    public class SensorFloatData
    {
        string teststring1 = "xxxx";
        string teststring2 = "yyyyy";
        float testfloat1 = 123;
        float testfloat2 = 456;
        float testfloat3 = 789;
        long testlong = 123456789;

        [TestMethod]
        public void JSONDataInput_V1_Test()
        {
            JSONDataInput_V1 inputData = new() 
            {
                SourceSystem = teststring1,
                StagingLevel = teststring2
            };

            JSONSensorFloatDataInput_V1 sensorFloatData = inputData.JSONSensorFloatDataInput_V1();
            sensorFloatData.DeviceName = teststring1;
            sensorFloatData.SensorName = teststring1;
            sensorFloatData.Description = teststring1;
            sensorFloatData.Comment = teststring1;
            sensorFloatData.Unit = teststring1;
            sensorFloatData.Plant = teststring1;
            sensorFloatData.Division = teststring1;
            sensorFloatData.MeassurementValue = testfloat1;
            sensorFloatData.MeassurementValueLSL = testfloat2;
            sensorFloatData.MeassurementValueUSL = testfloat3;
            sensorFloatData.MeassurementDateTimeJava = testlong;

        Assert.AreEqual(inputData.SourceSystem, sensorFloatData.SourceSystem);
            Assert.AreEqual(inputData.StagingLevel, sensorFloatData.StagingLevel);

            Assert.IsNotNull(sensorFloatData.DeviceName);
            Assert.IsNotNull(sensorFloatData.SensorName);
            Assert.IsNotNull(sensorFloatData.Description);
            Assert.IsNotNull(sensorFloatData.Comment);
            Assert.IsNotNull(sensorFloatData.Unit);
            Assert.IsNotNull(sensorFloatData.Plant);
            Assert.IsNotNull(sensorFloatData.Division);
            Assert.IsNotNull(sensorFloatData.MeassurementValue);
            Assert.IsNotNull(sensorFloatData.MeassurementValueLSL);
            Assert.IsNotNull(sensorFloatData.MeassurementValueUSL);
            Assert.IsNotNull(sensorFloatData.MeassurementDateTimeJava);

        }

      
    }
}
