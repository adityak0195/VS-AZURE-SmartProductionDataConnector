﻿using Amazon.S3.Model;
using SmartProductionDataDefinition_V1.JSON.MachineFloatData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace SmartProductionDataConnectorUnitTest
{
    [TestClass]
    public class BasicTests
    {
        private static long GenerateNumericId( string processDataType, DateTime productionTime)
        {
            // Convert ProductionTime to 13-digit timestamp
            long javaTime = (long)(productionTime - new DateTime(1970, 1, 1)).TotalMilliseconds/10;

            // Generate 3-digit hash from Machine and ProcessDataType
            string hashInput = $"{processDataType}";
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(hashInput));
                int hashSuffix = Math.Abs(BitConverter.ToInt32(hashBytes, 0)) % 10000; // Ensures a 4-digit suffix
                long numericId = (-1 * javaTime * 10000) - hashSuffix; // 16-digit negative ID
                return numericId;
            }
        }

        [TestMethod]
        public void TestIdCreation()
        {
            // Arrange
            long javaTime = 9999999999999;  // 13-digit timestamp
            int hashSuffix = 123;  // Example 3-digit hash
            long expectedId = (-1 * javaTime * 1000) - hashSuffix;

            // Act
            long actualId = (-1 * javaTime * 1000) - hashSuffix;

            // Assert
            Assert.AreEqual(expectedId, actualId, "The generated ID does not match the expected format.");
        }

        [TestMethod]
        public void TestIdCreation_New()
        {
            // Arrange            
            string processDataType = "TestProcessData";
            DateTime productionTime = new DateTime(2025, 2, 26, 6, 47, 42, 0);

            // Act
            long generatedId = GenerateNumericId( processDataType, productionTime);

            // Assert
            Assert.IsTrue(generatedId < 0, "Generated ID should always be negative.");
            Assert.AreEqual(16, Math.Abs(generatedId).ToString().Length, "Generated ID should be 16 digits long.");
        }
    }
}
