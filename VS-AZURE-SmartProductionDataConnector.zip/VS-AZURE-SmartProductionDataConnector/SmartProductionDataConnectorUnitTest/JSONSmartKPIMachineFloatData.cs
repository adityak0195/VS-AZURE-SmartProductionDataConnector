using Newtonsoft.Json;
using SmartProductionDataDefinition_V1.JSON;

namespace SmartProductionDataConnectorUnitTest
{
    [TestClass]
    public class JSONSmartKPIMachineFloatData
    {

        /*


        [TestMethod]
        public void SmartKPIMachineFloatDataParameterTest()
        {
            string prefix = "{\"StagingLevel\": \"";
            string suffix = "\"}";

            SmartKPIMachineFloatDataTestAreEqual("DEV", null);
            SmartKPIMachineFloatDataTestAreEqual("DEV", prefix + "DEV" + suffix);
            SmartKPIMachineFloatDataTestAreEqual("DEV", prefix + "dev" + suffix);
            SmartKPIMachineFloatDataTestAreEqual("DEV", prefix + "xxxxxx" + suffix);
            SmartKPIMachineFloatDataTestAreEqual("DEV", prefix + "" + suffix);
            SmartKPIMachineFloatDataTestAreEqual("DEV", prefix + null + suffix);
            SmartKPIMachineFloatDataTestAreEqual("TEST", prefix + "TEST" + suffix);
            SmartKPIMachineFloatDataTestAreEqual("TEST", prefix + "test" + suffix);
            SmartKPIMachineFloatDataTestAreEqual("PROD", prefix + "PROD" + suffix);
            SmartKPIMachineFloatDataTestAreEqual("PROD", prefix + "prod" + suffix);

        }

        internal static void SmartKPIMachineFloatDataTestAreEqual(string expectedValue, string? valueToTest)
        {
            SmartProductionDataConnector.Logic.SmartKPIMachineFloatDataLogic_V1 smartKPIMachineFloatData =
                new(valueToTest,"");

            Assert.IsNotNull(smartKPIMachineFloatData);
            Assert.IsNotNull(smartKPIMachineFloatData.GetJsonInput());
            Assert.AreEqual(expectedValue, smartKPIMachineFloatData.GetJsonInput().StagingLevel);
        }

        [TestMethod]
        public void SensorFloatDataIsUnprocessableEntityObjectResultTest()
        {

            SmartKPIMachineFloatDataIsUnprocessableEntityObjectResultTestIsEqual(true, null);
            SmartKPIMachineFloatDataIsUnprocessableEntityObjectResultTestIsEqual(true, "");
            SmartKPIMachineFloatDataIsUnprocessableEntityObjectResultTestIsEqual(false, "xx");
        }

        internal static void SmartKPIMachineFloatDataIsUnprocessableEntityObjectResultTestIsEqual
            (Boolean expectedValue,
            string? sourceSystem)
        {
            SmartProductionDataConnector.Logic.SmartKPIMachineFloatDataLogic_V1 smartKPIMachineFloatData =
                new("{\"SourceSystem\": \"" + sourceSystem + "\"}","");

            Assert.IsNotNull(smartKPIMachineFloatData);
            Assert.IsNotNull(smartKPIMachineFloatData.GetJsonInput());
            Assert.AreEqual(expectedValue, smartKPIMachineFloatData.IsUnprocessableEntityObjectResult());
        }
        */
    }
}