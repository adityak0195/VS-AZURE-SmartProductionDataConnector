﻿using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using SmartProductionDataDefinition_V1.JSON.SensorFloatData;
using SmartProductionDataDefinition_V1.JSON.MachineFloatData;
using SmartProductionDataDefinition_V1.JSON.Template;

namespace SmartProductionDataConnectorUnitTest.SmartProductionDataDefinition_V1
{
    [TestClass]
    public class SmartProductionDataDefinitionTest
    {
        [TestMethod]
        public void JSONFieldDefinition_V1Test()
        {

            string? name = "name";
            JSONFieldDefinitionAspect_V1? aspects = new();
            string? description = "description";
            string? baseType = "baseType";
            int ordinal = 123;

            JSONFieldDefinition_V1 json = new()
            {
                name = name,
                aspects = aspects,
                description = description,
                baseType = baseType,
                ordinal = ordinal
            };

            string jsonObject = JsonConvert.SerializeObject(json);
            Assert.IsNotNull(jsonObject);
            JSONFieldDefinition_V1? json1 = JsonConvert.DeserializeObject<JSONFieldDefinition_V1>(jsonObject);
            Assert.IsNotNull(json1);
            Assert.IsNotNull(json1.aspects);
            Assert.AreEqual(description, json1.description);
            Assert.AreEqual(baseType, json1.baseType);
            Assert.AreEqual(ordinal, json1.ordinal);

        }

        [TestMethod]
        public void JSONFieldDefinitionAspect_V1Test()
        {

            Boolean isPrimaryKey = false;
            JSONFieldDefinitionAspect_V1 json = new()
            {
                isPrimaryKey = isPrimaryKey
            };

            string jsonObject = JsonConvert.SerializeObject(json);
            Assert.IsNotNull(jsonObject);
            JSONFieldDefinitionAspect_V1? json1 = JsonConvert.DeserializeObject<JSONFieldDefinitionAspect_V1>(jsonObject);
            Assert.IsNotNull(json1);
            Assert.AreEqual(isPrimaryKey, json1.isPrimaryKey);

        }

        [TestMethod]
        public void JSONProcessSensorFloatDataToSmartKPIMachineFloatData_V1Test()
        {

            JSONProcessSensorFloatDataToSmartKPIMachineFloatData_V1 json = new()
            {
                jsonSensorFloatDataOutput = new(),
                jsonSmartKPIMachineFloatData = new()
            };

            string jsonObject = JsonConvert.SerializeObject(json);
            Assert.IsNotNull(jsonObject);
            JSONProcessSensorFloatDataToSmartKPIMachineFloatData_V1? json1 = JsonConvert.DeserializeObject<JSONProcessSensorFloatDataToSmartKPIMachineFloatData_V1>(jsonObject);
            Assert.IsNotNull(json1);
            Assert.IsNotNull(json1.jsonSmartKPIMachineFloatData);
            Assert.IsNotNull(json1.jsonSensorFloatDataOutput);

        }

        [TestMethod]
        public void JSONSensorFloatDataInput_V1Test()
        {

            string? SourceSystem = "SourceSystem";
            string? StagingLevel = "StagingLevel";
            string? DeviceName = "DeviceName";
            string? SensorName = "SensorName";
            string? Description = "Description";
            string? Comment = "Comment";
            string? Unit = "Unit";
            double MeassurementValue = 123;
            double MeassurementValueLSL = 234;
            double MeassurementValueUSL = 345;
            long MeassurementDateTimeJava = 456;

            JSONSensorFloatDataInput_V1 json = new()
            {
                SourceSystem = SourceSystem,
                StagingLevel = StagingLevel,
                DeviceName = DeviceName,
                SensorName = SensorName,
                Description = Description,
                Comment = Comment,
                Unit = Unit,
                MeassurementValue = MeassurementValue,
                MeassurementValueLSL = MeassurementValueLSL,
                MeassurementValueUSL = MeassurementValueUSL,
                MeassurementDateTimeJava = MeassurementDateTimeJava
            };

            string jsonObject = JsonConvert.SerializeObject(json);
            Assert.IsNotNull(jsonObject);
            JSONSensorFloatDataInput_V1? json1 = JsonConvert.DeserializeObject<JSONSensorFloatDataInput_V1>(jsonObject);
            Assert.IsNotNull(json1);
            Assert.AreEqual(SourceSystem, json1.SourceSystem);
            Assert.AreEqual(StagingLevel, json1.StagingLevel);
            Assert.AreEqual(DeviceName, json1.DeviceName);
            Assert.AreEqual(SensorName, json1.SensorName);
            Assert.AreEqual(Description, json1.Description);
            Assert.AreEqual(Comment, json1.Comment);
            Assert.AreEqual(Unit, json1.Unit);
            Assert.AreEqual(MeassurementDateTimeJava, json1.MeassurementDateTimeJava);
            Assert.AreEqual(MeassurementValue, json1.MeassurementValue);
            Assert.AreEqual(MeassurementValueLSL, json1.MeassurementValueLSL);
            Assert.AreEqual(MeassurementValueUSL, json1.MeassurementValueUSL);

        }
        [TestMethod]
        public void JSONSensorFloatDataOutput_V1Test()
        {

            string? Result = "Result";
            JSONSensorFloatDataInput_V1? JSONinput = new();
            Guid? Guid = System.Guid.NewGuid();

            JSONSensorFloatDataOutput_V1 json = new()
            {
                Result = Result,
                JSONinput = JSONinput,
                Guid = Guid
            };

            string jsonObject = JsonConvert.SerializeObject(json);
            Assert.IsNotNull(jsonObject);
            JSONSensorFloatDataOutput_V1? json1 = JsonConvert.DeserializeObject<JSONSensorFloatDataOutput_V1>(jsonObject);
            Assert.IsNotNull(json1);
            Assert.IsNotNull(json1.JSONinput);
            Assert.AreEqual(Result, json1.Result);
            Assert.AreEqual(Guid, json1.Guid);
        }

        [TestMethod]
        public void JSONSmartKPIMachineFloatDataInput_V1Test()
        {

            string? SourceSystem = "SourceSystem";
            string? StagingLevel = "StagingLevel";
            List<JSONSmartKPIMachineFloatDataRow_V1>? SmartKPIMachineFloatData = new();

            JSONSmartKPIMachineFloatDataInput_V1 json = new()
                {
                    SourceSystem = SourceSystem,
                    StagingLevel = StagingLevel,
                    rows = SmartKPIMachineFloatData
                };

            string jsonObject = JsonConvert.SerializeObject(json);
            Assert.IsNotNull(jsonObject);
            JSONSmartKPIMachineFloatDataInput_V1? json1 = JsonConvert.DeserializeObject<JSONSmartKPIMachineFloatDataInput_V1>(jsonObject);
            Assert.IsNotNull(json1);
            Assert.IsNotNull(json1.rows);
            Assert.AreEqual(SourceSystem, json1.SourceSystem);
            Assert.AreEqual(StagingLevel, json1.StagingLevel);
        }

        [TestMethod]
        public void JSONSmartKPIMachineFloatDataOutput_V1Test()
        {

            string? Result = "Result";
            Guid? Guid = System.Guid.NewGuid();

            JSONSmartKPIMachineFloatDataOutput_V1 json = new()
                {
                    Result = Result,
                    Guid = Guid
                };

            string jsonObject = JsonConvert.SerializeObject(json);
            Assert.IsNotNull(jsonObject);
            JSONSmartKPIMachineFloatDataOutput_V1? json1 = JsonConvert.DeserializeObject<JSONSmartKPIMachineFloatDataOutput_V1>(jsonObject);
            Assert.IsNotNull(json1);
            Assert.AreEqual(Result, json1.Result);
            Assert.AreEqual(Guid, json1.Guid);
        }

        [TestMethod]
        public void JSONSmartKPIMachineFloatDataRow_V1Test()
        {

            long? modification_id = 123;
            Boolean? isUpdated = false;
            string? Unit = "Unit";
            Boolean? move_to_history = false;
            string? Machine = "Machine";
            long UTCCreationTime = 234;
            double MachineData = 345;
            double MachineDataLSL = 456;
            double MachineDataUSL = 567;
            string? Plant = "Plant";
            string? MachineDataType = "MachineDataType";
            string? DELETE_IDENTIFIER = "DELETE_IDENTIFIER";
            long CreationTime = 678;
            string? Division = "Division";
            long Id = 789;
            long MachineTime = 890;
            string? SourceSystem = "SourceSystem";
            string? description = "description";
            string? comment = "comment";

            JSONSmartKPIMachineFloatDataRow_V1 json = new()
                {
                    modification_id = modification_id,
                    isUpdated = isUpdated,
                    Unit = Unit,
                    move_to_history= move_to_history,
                    Machine = Machine,
                    UTCCreationTime= UTCCreationTime,
                    MachineData = MachineData,
                    MachineDataLSL= MachineDataLSL,
                    MachineDataType= MachineDataType,
                    MachineDataUSL = MachineDataUSL,
                    Plant= Plant,
                    description= description,
                    DELETE_IDENTIFIER  = DELETE_IDENTIFIER,
                    CreationTime = CreationTime,
                    Division = Division,
                    Id = Id,
                    comment = comment,
                    MachineTime = MachineTime,
                    SourceSystem = SourceSystem
                };

            string jsonObject = JsonConvert.SerializeObject(json);
            Assert.IsNotNull(jsonObject);
            JSONSmartKPIMachineFloatDataRow_V1? json1 = JsonConvert.DeserializeObject<JSONSmartKPIMachineFloatDataRow_V1>(jsonObject);
            Assert.IsNotNull(json1);
            Assert.AreEqual(modification_id, json1.modification_id);
            Assert.AreEqual(isUpdated, json1.isUpdated);
            Assert.AreEqual(Unit, json1.Unit);
            Assert.AreEqual(move_to_history, json1.move_to_history);
            Assert.AreEqual(Machine, json1.Machine);
            Assert.AreEqual(UTCCreationTime, json1.UTCCreationTime);
            Assert.AreEqual(MachineData, json1.MachineData);
            Assert.AreEqual(MachineDataLSL, json1.MachineDataLSL);
            Assert.AreEqual(MachineDataType, json1.MachineDataType);
            Assert.AreEqual(MachineDataUSL, json1.MachineDataUSL);
            Assert.AreEqual(Plant, json1.Plant);
            Assert.AreEqual(description, json1.description);
            Assert.AreEqual(DELETE_IDENTIFIER, json1.DELETE_IDENTIFIER);
            Assert.AreEqual(CreationTime, json1.CreationTime);
            Assert.AreEqual(Division, json1.Division);
            Assert.AreEqual(Id, json1.Id);
            Assert.AreEqual(comment, json1.comment);
            Assert.AreEqual(MachineTime, json1.MachineTime);
            Assert.AreEqual(SourceSystem, json1.SourceSystem);
        }


        [TestMethod]
        public void TWXInfotable2JSONTest()
        {

            TWXInfotable2JSON_V1.TWXInfotableData json = new();

            string jsonObject = JsonConvert.SerializeObject(json);
            Assert.IsNotNull(jsonObject);
            TWXInfotable2JSON_V1.TWXInfotableData? json1 = JsonConvert.DeserializeObject<TWXInfotable2JSON_V1.TWXInfotableData>(jsonObject);
            Assert.IsNotNull(json1);
            Assert.IsNotNull(json1.rows);
            Assert.IsNotNull(json1.dataShape);


            JToken token1 = "{xxx: \"aaa\"}";
            JToken token2 = "{yyy: \"bbb\"}";
            json.rows = token1;
            json.dataShape = token2;
            jsonObject = JsonConvert.SerializeObject(json);
            Assert.IsNotNull(jsonObject);
            json1 = JsonConvert.DeserializeObject<TWXInfotable2JSON_V1.TWXInfotableData>(jsonObject);
            Assert.IsNotNull(json1);
            Assert.AreEqual(JsonConvert.SerializeObject(token1), JsonConvert.SerializeObject(json1.rows));
            Assert.AreEqual(JsonConvert.SerializeObject(token2), JsonConvert.SerializeObject(json1.dataShape));
        }


    }
}
