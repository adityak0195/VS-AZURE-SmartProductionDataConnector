﻿using Microsoft.Extensions.FileSystemGlobbing.Internal;
using Newtonsoft.Json;
using SmartProductionDataConnector.Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartProductionDataConnectorUnitTest.Logic
{
    [TestClass]
    public class StartHourlyDBJobLogicTest
    {

        [TestMethod]
        public void TestDataDefinitionHourlyDBJobLogicJsonStructure()
        {
            string environment = "Environment";
            string dbpattern = "DBPattern";

            DataDefinitionHourlyDBJobLogic dataDefinitionHourlyDBJobLogic = new()
            {
                Environment = environment,
                DBPattern = dbpattern
            };

            string jsonObject = JsonConvert.SerializeObject(dataDefinitionHourlyDBJobLogic);
            Assert.IsNotNull(jsonObject);
            DataDefinitionHourlyDBJobLogic? dataDefinitionHourlyDBJobLogic1 = JsonConvert.DeserializeObject<DataDefinitionHourlyDBJobLogic>(jsonObject);
            Assert.IsNotNull(dataDefinitionHourlyDBJobLogic1);
            Assert.AreEqual(environment, dataDefinitionHourlyDBJobLogic1.Environment);
            Assert.AreEqual(dbpattern, dataDefinitionHourlyDBJobLogic1.DBPattern);

        }
    }
}
