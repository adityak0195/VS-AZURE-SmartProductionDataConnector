﻿using SmartProductionDataConnector.Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartProductionDataConnectorUnitTest.Logic
{
    [TestClass]
    public class Security
    {
        [TestMethod]
        public void EncryptionDecryptionTest()
        {
            string someCharacters = "1234567890abcdefghijklmnopqrstuvwqyzöäüABCDEFGHIJKLMNOPQRSTUVWXYZÖÄÜ!\"§$%&/()=?´´\\+*#'-_.:,;<>^°@";
            string content = "content:" + someCharacters;
            string key = "key:" + someCharacters;

            Assert.AreEqual(content, Security_V1.DecryptString(Security_V1.EncryptString(content, key),key));
        }
    }
}
