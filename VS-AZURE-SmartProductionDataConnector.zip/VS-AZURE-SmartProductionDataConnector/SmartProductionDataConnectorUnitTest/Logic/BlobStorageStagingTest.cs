﻿using SmartProductionDataConnector.Logic;


namespace SmartProductionDataConnectorUnitTest.Logic
{
    [TestClass]
    public class BlobStorageStagingTest
    {

        [TestMethod]
        public void Test()
        {
            Assert.IsNotNull(BlobStorageStagingLevel.DEV);
            Assert.IsNotNull(BlobStorageStagingLevel.PROD);
            Assert.IsNotNull(BlobStorageStagingLevel.TEST);

            Assert.AreEqual("DEV", BlobStorageStagingLevel.DEV);
            Assert.AreEqual("PROD", BlobStorageStagingLevel.PROD);
            Assert.AreEqual("TEST", BlobStorageStagingLevel.TEST);

        }
    }
}
