﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HELPER_CopyDataFrom_datalake_2_dc00X_V1
{
    internal class test
    {
        // find all images

    }
}
