﻿
// See https://aka.ms/new-console-template for more information
using SmartProductionDataConnector.Logic;

////****************************************SETUP****************************************
int segmentSize = 1000;
Boolean doOnlyOneCycle = false;
int timeLimitMin = 0;

//string sourceTESTStorageAccountName = "idlthingworxhot";
//string sourceTESTContainerName = "smartproduction";
//string sourceTESTSasToken = "sp=racwdlmeop&st=2023-02-16T08:11:49Z&se=2024-02-01T16:11:49Z&spr=https&sv=2021-06-08&sr=c&sig=%2FfYr4%2BGwT%2Bx3hzoH6VAiVY6YLSBn11U5SyKYYGzYvXE%3D";
//string sourceTESTPath = BlobStorageStagingLevel.TEST;
//
//string targetTESTStorageAccountName = "devthingworxpw6mcest00";
//string targetTESTContainerName = "smartproductiondataupload-v3";
//string targetTESTSasToken = "sp=racwdl&st=2023-07-19T08:41:13Z&se=2023-11-30T17:41:13Z&spr=https&sv=2022-11-02&sr=c&sig=rWoir%2B%2B8nm7NeUSWC3ffOu7H9Z1UkA1P21zwFT8rlQY%3D";


string sourcePRODStorageAccountName = "idlthingworxhot";
string sourcePRODContainerName = "smartproduction";
string sourcePRODSasToken = "sp=racwdlme&st=2024-01-02T07:04:16Z&se=2024-06-30T10:00:00Z&spr=https&sv=2022-11-02&sr=c&sig=9YrUNo6UxNdMwqWNT1M%2F3Aq5EgG%2FHjeMUgAexwYy7gE%3D";
string sourcePRODPath = "PROD";

string targetPRODStorageAccountName = "prdthingworxqrjxoxst00";
string targetPRODContainerName = "smartproductiondataupload-v3";
string targetPRODSasToken = "sp=rawl&st=2024-01-02T06:58:28Z&se=2024-06-30T10:00:00Z&spr=https&sv=2022-11-02&sr=c&sig=9JW%2FYZdr0nHwJ9CpajGGYAv7vILrSu72immQD7NZsH8%3D";


////****************************************SETUP****************************************

////TEST
//Console.WriteLine("*****TEST*****");
//SmartProductionDataConnector.TimerFunctions.HELPER_CopyDataFrom_datalake_2_dc00X_Worker.moveDataWithStructureChange(
//sourceTESTStorageAccountName,
//sourceTESTContainerName,
//sourceTESTSasToken,
//sourceTESTPath,
//targetTESTStorageAccountName,
//targetTESTContainerName,
//targetTESTSasToken,
//segmentSize,
//doOnlyOneCycle,
//timeLimitMin);


//PROD
//Console.WriteLine("*****PROD*****");
//SmartProductionDataConnector.TimerFunctions.HELPER_CopyDataFrom_datalake_2_dc00X_Worker.moveDataWithStructureChange(
//sourcePRODStorageAccountName,
//sourcePRODContainerName,
//sourcePRODSasToken,
//sourcePRODPath,
//targetPRODStorageAccountName,
//targetPRODContainerName,
//targetPRODSasToken,
//segmentSize,
//doOnlyOneCycle,
//timeLimitMin);
