﻿using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using SmartProductionDataConnector.Logic;
using System;
using System.Threading.Tasks;

namespace SmartProductionDataConnector.BlobFunctions
{

    public class AdgTestBenchDataStringObserver_V1
    {

        [FunctionName("AdgTestBenchDataStringObserver_V1")]
        public async Task RunAsync([TimerTrigger("0 3/5 * * * *")] TimerInfo myTimer, ILogger log)
        {
            log.LogInformation($"***START AdgTestBenchDataStringObserver_V1 C# at: {DateTime.Now}");
            if (Environment.ExpandEnvironmentVariables("%WEBSITE_SITE_NAME%") == GlobalSettings_V1.DEV_FUNCTION_APP_WEEU)
            {
                //DEV
                await DataBufferObserverLogic_V1.DoProcessingAdgTestBenchDataStringAsync(BlobStorageStagingLevel.DEV, log);
                await DataBufferObserverLogic_V1.DoProcessingAdgTestBenchDataStringAsync(BlobStorageStagingLevel.TEST, log);
            }
            else if (Environment.ExpandEnvironmentVariables("%WEBSITE_SITE_NAME%") == GlobalSettings_V1.PRD_FUNCTION_APP_WEEU)
            {
                //PROD  
                await DataBufferObserverLogic_V1.DoProcessingAdgTestBenchDataStringAsync(BlobStorageStagingLevel.PROD, log);
            }
            log.LogInformation($"***END C# at: {DateTime.Now}");
        }
    }
}
