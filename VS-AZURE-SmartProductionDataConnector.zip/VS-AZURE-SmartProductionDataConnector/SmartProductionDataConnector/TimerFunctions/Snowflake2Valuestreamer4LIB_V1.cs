﻿using Microsoft.Azure.WebJobs;
using System;
using Microsoft.Extensions.Logging;
using SmartProductionDataConnector.Logic;

namespace SmartProductionDataConnector.TimerFunctions
{
    internal class Snowflake2Valuestreamer4LIB_V1
    {
        [FunctionName("Snowflake2Valuestreamer4LIB_V1")]
        public static void Run([TimerTrigger("0 0 * * * *")] TimerInfo myTimer, ILogger log)
        //for testing "0 */5 * * * *"
        //normal run "0 0 * * * *"
        {
            log.LogInformation($"***START Snowflake2Valuestreamer4LIB_V1 C# at: {DateTime.Now}");
            log.LogInformation($"***Running Environment: {Environment.ExpandEnvironmentVariables("%WEBSITE_SITE_NAME%")}");

            Logic.DataDefinitionTwx2ValueStreamer dataDefinition = new()
            {
                Key = Environment.GetEnvironmentVariable("Security-V1-DecryptKey"),
                Plant = "LIB",
                SourceSystem = "smartproductionLIB.corp.knorr-bremse.com"
            };



            if (Environment.ExpandEnvironmentVariables("%WEBSITE_SITE_NAME%") == GlobalSettings_V1.DEV_FUNCTION_APP_WEEU)
            {
                //DEV
                log.LogInformation("***DEV Environment");
                dataDefinition.Environment = BlobStorageStagingLevel.DEV;
                dataDefinition.PointerDB = "twx_lib_test_ext";
                dataDefinition.kpiNames.Add(new Logic.DataDefinitionTwx2ValueStreamerKpi() { twxKpiName = "", vsKpiName = "no test environment defined", vsKpiValueName = "ACTUAL OEE" });
                dataDefinition.machineNames.Add(new Logic.DataDefinitionTwx2ValueStreamerMachine() { twxMachineName = "", vsMachineName = "no test environment defined" });
                //dataDefinition.kpiNames.Add(new Logic.DataDefinitionTwx2ValueStreamerKpi() { twxKpiName = "RQ", vsKpiName = "Rate of Quality", vsKpiValueName = "RQ Actual" });
                //dataDefinition.machineNames.Add(new Logic.DataDefinitionTwx2ValueStreamerMachine() { twxMachineName = "KBLIBOBC-3MachineThing", vsMachineName = "L1 (OBC3)" });
                Logic.Snowflake2ValuestreamerLogic_V1.DoProcessing(log, dataDefinition);
            }
            else if (Environment.ExpandEnvironmentVariables("%WEBSITE_SITE_NAME%") == GlobalSettings_V1.PRD_FUNCTION_APP_WEEU) 
            {
                //PROD
                log.LogInformation("***PROD Environment");
                dataDefinition.Environment = BlobStorageStagingLevel.PROD;
                dataDefinition.PointerDB = "twx_lib_prod_ext";
                dataDefinition.kpiNames.Add(new Logic.DataDefinitionTwx2ValueStreamerKpi() { twxKpiName = "CVS DLP1: Parts Actual", vsKpiName = "Delivery", vsKpiValueName = "Actual Productiion (Pcs)" });
                dataDefinition.kpiNames.Add(new Logic.DataDefinitionTwx2ValueStreamerKpi() { twxKpiName = "CVS DLP1: Calculated Target", vsKpiName = "Delivery", vsKpiValueName = "Target of Production (DLP1)" });
                dataDefinition.kpiNames.Add(new Logic.DataDefinitionTwx2ValueStreamerKpi() { twxKpiName = "CVS: OEE (Version 2)", vsKpiName = "OEE", vsKpiValueName = "ACTUAL OEE" });
                dataDefinition.kpiNames.Add(new Logic.DataDefinitionTwx2ValueStreamerKpi() { twxKpiName = "RQ", vsKpiName = "Rate of Quality", vsKpiValueName = "RQ Actual" });
                dataDefinition.kpiNames.Add(new Logic.DataDefinitionTwx2ValueStreamerKpi() { twxKpiName = "OutputNIO", vsKpiName = "NOK Pieces", vsKpiValueName = "Actual NOK Pcs" });
                dataDefinition.kpiNames.Add(new Logic.DataDefinitionTwx2ValueStreamerKpi() { twxKpiName = "CVS: Changeovers", vsKpiName = "Change-Over Count", vsKpiValueName = "Count of changeovers" });
                dataDefinition.kpiNames.Add(new Logic.DataDefinitionTwx2ValueStreamerKpi() { twxKpiName = "CVS: Average Changeover time from operator screen [min]", vsKpiName = "Change-Over Duration", vsKpiValueName = "Actual average C/O" });
                dataDefinition.kpiNames.Add(new Logic.DataDefinitionTwx2ValueStreamerKpi() { twxKpiName = "CVS: Downtime losses [min]", vsKpiName = "Downtime Losses", vsKpiValueName = "Losses duration" });
                dataDefinition.machineNames.Add(new Logic.DataDefinitionTwx2ValueStreamerMachine() { twxMachineName = "KBLIBOBC-3MachineThing", vsMachineName = "L1 (OBC3)" });
                dataDefinition.machineNames.Add(new Logic.DataDefinitionTwx2ValueStreamerMachine() { twxMachineName = "KBLIBOBC-4MachineThing", vsMachineName = "L1 (OBC4)" });
                dataDefinition.machineNames.Add(new Logic.DataDefinitionTwx2ValueStreamerMachine() { twxMachineName = "KBLIBAoHMachineThing", vsMachineName = "L1 (AoH)" });
                dataDefinition.machineNames.Add(new Logic.DataDefinitionTwx2ValueStreamerMachine() { twxMachineName = "KBLIBBSMachineThing", vsMachineName = "L1 (BS)" });
                dataDefinition.machineNames.Add(new Logic.DataDefinitionTwx2ValueStreamerMachine() { twxMachineName = "KBLIBDPAMachineThing", vsMachineName = "L1 (DPA)" });
                dataDefinition.machineNames.Add(new Logic.DataDefinitionTwx2ValueStreamerMachine() { twxMachineName = "KBLIBNG3MachineThing", vsMachineName = "L1 (NG3)" });
                dataDefinition.machineNames.Add(new Logic.DataDefinitionTwx2ValueStreamerMachine() { twxMachineName = "KBLIBNG4MachineThing", vsMachineName = "L1 (NG4)" });
                dataDefinition.machineNames.Add(new Logic.DataDefinitionTwx2ValueStreamerMachine() { twxMachineName = "KBLIBOBC-1MachineThing", vsMachineName = "L1 (OBC1)" });
                dataDefinition.machineNames.Add(new Logic.DataDefinitionTwx2ValueStreamerMachine() { twxMachineName = "KBLIBFP09-Lanico2MachineThing", vsMachineName = "L1 (FP09)" });
                dataDefinition.machineNames.Add(new Logic.DataDefinitionTwx2ValueStreamerMachine() { twxMachineName = "KBLIBFP08-Bayonet2PromoticStationThing", vsMachineName = "L1 (FP08)" });
                dataDefinition.machineNames.Add(new Logic.DataDefinitionTwx2ValueStreamerMachine() { twxMachineName = "KBLIBFP-BayonetMachineThing", vsMachineName = "L1 (FP05)" });
                dataDefinition.machineNames.Add(new Logic.DataDefinitionTwx2ValueStreamerMachine() { twxMachineName = "KBLIBFP-LanicoMachineThing", vsMachineName = "L1 (FP07-LANICO)" });
                dataDefinition.machineNames.Add(new Logic.DataDefinitionTwx2ValueStreamerMachine() { twxMachineName = "KBLIBADBMachineThing", vsMachineName = "L1 (ADB)" });
                dataDefinition.machineNames.Add(new Logic.DataDefinitionTwx2ValueStreamerMachine() { twxMachineName = "KBLIBVGMachineThing", vsMachineName = "L1 (VG)" });
                dataDefinition.machineNames.Add(new Logic.DataDefinitionTwx2ValueStreamerMachine() { twxMachineName = "KBLIBFP10-BayonetPromoticStationThing", vsMachineName = "L1 (FP10)" });
                Logic.Snowflake2ValuestreamerLogic_V1.DoProcessing(log, dataDefinition);
            }

            else
            {
                //UNKNOWN
                log.LogError($"***Unknown Environment: {Environment.ExpandEnvironmentVariables("%WEBSITE_SITE_NAME%")}");
            }
            log.LogInformation($"***END C# at: {DateTime.Now}");
        }
    }
}
