using System;
using Azure.Storage.Blobs.Models;
using Azure.Storage.Blobs;
using Azure;
using System.Collections.Generic;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Threading;
using SmartProductionDataConnector.Logic;

namespace SmartProductionDataConnector.TimerFunctions
{
    public class HELPER_CopyDataFrom_datalake_2_dc00X_V1
    {
        [FunctionName("HELPER_CopyDataFrom_datalake_2_dc00X_V1")]
        public static void Run([TimerTrigger("0 30 * * * *")]TimerInfo myTimer, ILogger log)
        {
            log.LogInformation($"***START HELPER_CopyDataFrom_datalake_2_dc00X_V1 C# at: {DateTime.Now}");
            log.LogInformation($"***Running Environment: {Environment.ExpandEnvironmentVariables("%WEBSITE_SITE_NAME%")}");


            int segmentSize = 10;
            Boolean doOnlyOneCycle = false;
            int timeLimitMin = 59;





            if (Environment.ExpandEnvironmentVariables("%WEBSITE_SITE_NAME%") == GlobalSettings_V1.DEV_FUNCTION_APP_WEEU)
            {
                //DEV
                log.LogInformation("***DEV Environment");

                string sourceTESTStorageAccountName = "idlthingworxhot";
                string sourceTESTContainerName = "smartproduction";
                string sourceTESTSasToken = "sp=racwdlmeop&st=2023-02-16T08:11:49Z&se=2024-02-01T16:11:49Z&spr=https&sv=2021-06-08&sr=c&sig=%2FfYr4%2BGwT%2Bx3hzoH6VAiVY6YLSBn11U5SyKYYGzYvXE%3D";

                string targetTESTStorageAccountName = "devthingworxpw6mcest00";
                string targetTESTContainerName = GlobalSettings_V1.BLOB_CONTAINER;
                string targetTESTSasToken = "sp=racwdl&st=2023-07-11T11:46:46Z&se=2024-06-01T19:46:46Z&spr=https&sv=2022-11-02&sr=c&sig=fnWaE8NJNbwIgDHgUTD87q%2Ffzfd6Jy8Xk8fFHzRPsh0%3D";

                Thread thread1 = new Thread(() => HELPER_CopyDataFrom_datalake_2_dc00X_Worker.moveDataWithStructureChange(
                    sourceTESTStorageAccountName,
                    sourceTESTContainerName,
                    sourceTESTSasToken,
                    BlobStorageStagingLevel.TEST,
                    targetTESTStorageAccountName,
                    targetTESTContainerName,
                    targetTESTSasToken,
                    segmentSize,
                    doOnlyOneCycle,
                    timeLimitMin))
                {
                    Name = "thread1",
                    IsBackground = true
                };
                //thread1.Start();

                Thread thread2 = new Thread(() => HELPER_CopyDataFrom_datalake_2_dc00X_Worker.moveDataWithStructureChange(
                    sourceTESTStorageAccountName,
                    sourceTESTContainerName,
                    sourceTESTSasToken,
                    BlobStorageStagingLevel.DEV,
                    targetTESTStorageAccountName,
                    targetTESTContainerName,
                    targetTESTSasToken,
                    segmentSize,
                    doOnlyOneCycle,
                    timeLimitMin))
                {
                    Name = "thread2",
                    IsBackground = true
                };
                //thread2.Start();

            }
            else if (Environment.ExpandEnvironmentVariables("%WEBSITE_SITE_NAME%") == GlobalSettings_V1.PRD_FUNCTION_APP_WEEU)
            {
                //PROD
                log.LogInformation("***PROD Environment");
            }
            else
            {
                //UNKNOWN
                log.LogError($"***Unknown Environment: {Environment.ExpandEnvironmentVariables("%WEBSITE_SITE_NAME%")}");
            }
            log.LogInformation($"***END C# at: {DateTime.Now}");
        }
    }















    public class HELPER_CopyDataFrom_datalake_2_dc00X_Worker
    {
        public static void moveDataWithStructureChange(
            string sourceStorageAccountName,
            string sourceContainerName,
            string sourceSasToken,
            string sourcePath,
            string targetStorageAccountName,
            string targetContainerName,
            string targetSasToken,
            int segmentSize,
            Boolean doOnlyOneCycle,
            int timeLimitMin)
        {


            string sourceBlobUri = "https://" + sourceStorageAccountName + ".blob.core.windows.net";
            string targetBlobUri = "https://" + targetStorageAccountName + ".blob.core.windows.net";

            DateTime startTime = DateTime.Now;

            BlobServiceClient blobSourceServiceClient = new BlobServiceClient
            (new Uri($"{sourceBlobUri}?{sourceSasToken}"), null);
            BlobServiceClient blobTargetServiceClient = new BlobServiceClient
            (new Uri($"{targetBlobUri}?{targetSasToken}"), null);

            BlobContainerClient blobSourceContainerClient = blobSourceServiceClient.GetBlobContainerClient(sourceContainerName);
            BlobContainerClient blobTargetContainerClient = blobTargetServiceClient.GetBlobContainerClient(targetContainerName);




            // Call the listing operation and return pages of the specified size.
            var resultSegment = blobSourceContainerClient.GetBlobs(BlobTraits.None, BlobStates.None, sourcePath)
                .AsPages(default, segmentSize);

            // Enumerate the blobs returned for each page.
            foreach (Page<BlobItem> blobPage in resultSegment)
            {
                foreach (BlobItem blobItem in blobPage.Values)
                {
                    Console.WriteLine("**********************************************************");
                    if (blobItem == null)
                    {
                        Console.WriteLine("NULL");
                    }
                    else if (blobItem.Name.ToLower().Contains("/debug/") || blobItem.Name.ToLower().Contains("/error/") || blobItem.Name.ToLower().EndsWith("test.json"))
                    {
                        Console.WriteLine("debug is excluded Blob name: {0}", blobItem.Name);
                    }
                    else if (blobItem.Name.ToLower().EndsWith(".json"))
                    {
                        Console.WriteLine("Blob name: {0}", blobItem.Name);

                        //reading source data
                        BlobDownloadResult sourceContent = blobSourceContainerClient.GetBlobClient(blobItem.Name).DownloadContent();
                        string sourceContentString = sourceContent.Content.ToString();
                        SourceJSONData sourceJsonData = JsonConvert.DeserializeObject<SourceJSONData>(sourceContentString);

                        //parsing creation date
                        string javaDate = blobItem.Name.Substring(blobItem.Name.IndexOf("_inc") - 13, 13);
                        DateTime javaDateTime = new DateTime(1970, 1, 1).AddMilliseconds(double.Parse(javaDate));

                        //creating new file name
                        string oldDir = blobItem.Name.Substring(0, blobItem.Name.IndexOf(".corp.knorr-bremse.com") + 22);
                        string oldFile = blobItem.Name.Substring(blobItem.Name.IndexOf(".corp.knorr-bremse.com") + 23, blobItem.Name.Length - blobItem.Name.IndexOf(".corp.knorr-bremse.com") - 23);
                        string sourceSystem = oldDir.Substring(oldDir.LastIndexOf("/") + 1, oldDir.Length - oldDir.LastIndexOf("/") - 1);
                        string dataType = oldDir.Substring(oldDir.IndexOf("/")+1, oldDir.LastIndexOf("/") - oldDir.IndexOf("/")-1);
                        string stagingLevel = oldDir.Substring(0, oldDir.IndexOf("/"));

                        if (sourceSystem == "smartproduction.corp.knorr-bremse.com")
                        {
                            sourceSystem = "smartproductionMUC.corp.knorr-bremse.com";
                        }

                        if (!blobItem.Name.ToLower().Contains("_directpush_")
                            && blobItem.Name.ToLower().Contains("_inc")
                            && blobItem.Name.ToLower().Contains(".corp.knorr-bremse.com"))
                        {
                            Console.WriteLine("(1)");

                                string newBlobName =
                                    stagingLevel +
                                    "/" +
                                    GlobalSettings_V1.GetDivision(sourceSystem) +
                                    "/" +
                                    dataType +
                                    "/" +
                                    javaDateTime.Year.ToString() +
                                    "/" +
                                    javaDateTime.Month.ToString() +
                                    "/" +
                                    javaDateTime.Day.ToString() +
                                    "/" +
                                    sourceSystem +
                                    "/" +
                                    oldFile;

                                //create local copy
                                BlobClient blobClient1 = blobSourceContainerClient.GetBlobClient("MOVED/" + blobItem.Name);
                                blobClient1.Upload(sourceContent.Content, overwrite: true);

                                //writing to target
                                BlobClient blobClient2 = blobTargetContainerClient.GetBlobClient(newBlobName);
                                blobClient2.Upload(BinaryData.FromString(JsonConvert.SerializeObject(sourceJsonData.rows, Formatting.Indented)), overwrite: true);

                                //delete source
                                blobSourceContainerClient.GetBlobClient(blobItem.Name).Delete();

                                Console.WriteLine("Moved");


                            //Console.WriteLine(jsonData.rows);
                        }
                        else if (blobItem.Name.ToLower().Contains("_directpush_v1_")
                            && blobItem.Name.ToLower().Contains("_inc")
                            && !blobItem.Name.ToLower().Contains("/20")
                            && blobItem.Name.ToLower().Contains(".corp.knorr-bremse.com"))
                        {
                            Console.WriteLine("(2)");

                                long javaTime = (long)(new DateTime(javaDateTime.Year, javaDateTime.Month, javaDateTime.Day, javaDateTime.Hour,(int)(javaDateTime.Minute/5)*5,0) - new DateTime(1970, 1, 1)).TotalMilliseconds;
                                string newfile = javaTime.ToString() + oldFile.Substring(13, oldFile.ToLower().IndexOf("directpush_v1")) + ".json";

                                string newBlobName =
                                    stagingLevel +
                                    "/" +
                                    GlobalSettings_V1.GetDivision(sourceSystem) +
                                    "/" +
                                    dataType +
                                    "/" +
                                    javaDateTime.Year.ToString() +
                                    "/" +
                                    javaDateTime.Month.ToString() +
                                    "/" +
                                    javaDateTime.Day.ToString() +
                                    "/" +
                                    sourceSystem +
                                    "/" +
                                    newfile;
                                Console.WriteLine(newBlobName);

                                //create local copy
                                BlobClient blobClient1 = blobSourceContainerClient.GetBlobClient("MOVED_DIRECTPUSH/" + blobItem.Name);
                                blobClient1.Upload(sourceContent.Content, overwrite: true);

                                //check if file exists on target side
                                BlobClient blobClient2 = blobTargetContainerClient.GetBlobClient(newBlobName);
                                if (blobClient2.Exists())
                                {
                                    Console.WriteLine("Already exists");
                                    BlobDownloadResult targetContent = blobClient2.DownloadContent();
#pragma warning disable CS8632
                                    string? targetContentString = targetContent.Content.ToString();
                                    List<JToken>? targetJsonData = JsonConvert.DeserializeObject<List<JToken>>(targetContentString);
#pragma warning restore CS8632
                                    targetJsonData.AddRange(sourceJsonData.rows);

                                    //writing to target
                                    blobClient2.Upload(BinaryData.FromString(JsonConvert.SerializeObject(targetJsonData, Formatting.Indented)), overwrite: true);
                                    Console.WriteLine("Moved");

                                }
                                else
                                {
                                    //writing to target
                                    blobClient2.Upload(BinaryData.FromString(JsonConvert.SerializeObject(sourceJsonData.rows, Formatting.Indented)), overwrite: true);
                                }

                                //delete source
                                blobSourceContainerClient.GetBlobClient(blobItem.Name).Delete();


                        }
                        else
                        {
                            Console.WriteLine(">>>>>>>>>>>>>>> Unhandled Blob name: {0}", blobItem.Name);
                        }
                    }
                }

                Console.WriteLine();
                if (doOnlyOneCycle || (startTime.AddMinutes(timeLimitMin) < DateTime.Now) && timeLimitMin > 0)
                {
                    break;
                }
            }

            Console.WriteLine("*****READY*****");
            Console.ReadLine();
        }
    }
#pragma warning disable CS8632
    public class SourceJSONData
    {
        public JToken? rows;
        public JToken? dataShape;
    }
#pragma warning restore CS8632
}
