﻿using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using SmartProductionDataConnector.Logic;
using System;
using System.Threading.Tasks;

namespace SmartProductionDataConnector.BlobFunctions
{

    public class AdgTestBenchDataDateTimeObserver_V1
    {

        [FunctionName("AdgTestBenchDataDateTimeObserver_V1")]
        public async Task RunAsync([TimerTrigger("0 1/5 * * * *")] TimerInfo myTimer, ILogger log)
        {
            log.LogInformation($"***START AdgTestBenchDataDateTimeObserver_V1 C# at: {DateTime.Now}");
            if (Environment.ExpandEnvironmentVariables("%WEBSITE_SITE_NAME%") == GlobalSettings_V1.DEV_FUNCTION_APP_WEEU)
            {
                //DEV
                await DataBufferObserverLogic_V1.DoProcessingAdgTestBenchDataDateTimeAsync(BlobStorageStagingLevel.DEV, log);
                await DataBufferObserverLogic_V1.DoProcessingAdgTestBenchDataDateTimeAsync(BlobStorageStagingLevel.TEST, log);
            }
            else if (Environment.ExpandEnvironmentVariables("%WEBSITE_SITE_NAME%") == GlobalSettings_V1.PRD_FUNCTION_APP_WEEU)
            {
                //PROD
                await DataBufferObserverLogic_V1.DoProcessingAdgTestBenchDataDateTimeAsync(BlobStorageStagingLevel.PROD, log);
            }
            log.LogInformation($"***END C# at: {DateTime.Now}");
        }
    }
}
