using System;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using SmartProductionDataConnector.Logic;

namespace SmartProductionDataConnector.TimerFunctions
{
    public class StartHourlyDBJob_V1
    {
        [FunctionName("StartHourlyDBJob_V1")]
        public static void Run([TimerTrigger("0 30 * * * *")]TimerInfo myTimer, ILogger log)
        {
            log.LogInformation($"***START StartHourlyDBJob_V1 C# at: {DateTime.Now}");
            log.LogInformation($"***Running Environment: {Environment.ExpandEnvironmentVariables("%WEBSITE_SITE_NAME%")}");
 
            Logic.DataDefinitionHourlyDBJobLogic dataDefinition = new();

 

            if (DateTime.Now.Hour == 17 &&
                (Environment.ExpandEnvironmentVariables("%WEBSITE_SITE_NAME%") == GlobalSettings_V1.DEV_FUNCTION_APP_WEEU ||
                Environment.ExpandEnvironmentVariables("%WEBSITE_SITE_NAME%") == GlobalSettings_V1.DEV_FUNCTION_APP_SEAS ||
                Environment.ExpandEnvironmentVariables("%WEBSITE_SITE_NAME%") == GlobalSettings_V1.DEV_FUNCTION_APP_EUS2
               ))
            {
                //DEV
                log.LogInformation("***DEV Environment");
                dataDefinition.Environment = BlobStorageStagingLevel.DEV;
                dataDefinition.DBPattern = "twx_%_ext";
                StartHourlyDBJobLogic_V1.DoProcessing(log, dataDefinition);
            }
            else if (
                Environment.ExpandEnvironmentVariables("%WEBSITE_SITE_NAME%") == GlobalSettings_V1.PRD_FUNCTION_APP_WEEU ||
                Environment.ExpandEnvironmentVariables("%WEBSITE_SITE_NAME%") == GlobalSettings_V1.PRD_FUNCTION_APP_SEAS ||
                Environment.ExpandEnvironmentVariables("%WEBSITE_SITE_NAME%") == GlobalSettings_V1.PRD_FUNCTION_APP_EUS2
               )
            {
                //PROD
                log.LogInformation("***PROD Environment");
                dataDefinition.Environment = BlobStorageStagingLevel.PROD;
                dataDefinition.DBPattern = "twx_%_prod_ext";
                StartHourlyDBJobLogic_V1.DoProcessing(log, dataDefinition);
            }
            else
            {
                //UNKNOWN
                log.LogError($"***Unknown Environment: {Environment.ExpandEnvironmentVariables("%WEBSITE_SITE_NAME%")}");
            }
            log.LogInformation($"***END C# at: {DateTime.Now}");
        }
    }
}
