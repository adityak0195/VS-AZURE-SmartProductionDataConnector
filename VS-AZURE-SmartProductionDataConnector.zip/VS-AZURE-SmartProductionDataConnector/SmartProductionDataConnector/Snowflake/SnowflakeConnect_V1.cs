﻿using SmartProductionDataConnector.Logic;
using Snowflake.Data.Client;
using Microsoft.Extensions.Logging;
using System;
using System.Data;

namespace SmartProductionDataConnector.Snowflake
{
    internal class SnowflakeConnect_V1
    {
        private SnowflakeDbConnection snowflakeDbConnection;
        private readonly string role;
        private readonly string privateKeyContent;

        internal SnowflakeConnect_V1(ILogger log, string key, string role)
        {
            privateKeyContent = Logic.Security_V1.DecryptString(GlobalSettings_V1.SNOWFLAKE_KEY, key);
            this.role = role;

            Connect();
            log.LogInformation("Connected to Snowflake");

        }

        private void Connect()
        {
            snowflakeDbConnection = new SnowflakeDbConnection
            {
                ConnectionString =
                    "host=" + GlobalSettings_V1.SNOWFLAKE_HOST + ";" +
                    "warehouse=" + GlobalSettings_V1.SNOWFLAKE_WAREHOUSE + ";" +
                    "db=" + GlobalSettings_V1.SNOWFLAKE_DB + ";" +
                    "schema=" + GlobalSettings_V1.SNOWFLAKE_SCHEMA + ";" +
                    "account=" + GlobalSettings_V1.SNOWFLAKE_ACCOUNT + ";" +
                    "authenticator=snowflake_jwt;" +
                    "user=" + GlobalSettings_V1.SNOWFLAKE_USER + ";" +
                    "private_key=" + privateKeyContent + ";" +
                    "role=" + role
            };
        }

        internal IDbConnection GetConnection()
        {

            return snowflakeDbConnection;
        }

    }
}
