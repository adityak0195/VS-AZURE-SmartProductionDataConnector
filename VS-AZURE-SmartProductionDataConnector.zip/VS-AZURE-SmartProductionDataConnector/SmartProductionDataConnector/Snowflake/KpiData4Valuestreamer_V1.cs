﻿using SmartProductionDataConnector.Logic;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;

namespace SmartProductionDataConnector.Snowflake
{
    internal class KpiData4Valuestreamer_V1 : IDisposable
    {
        private readonly IDbConnection conn;
        private ILogger log;

        public KpiData4Valuestreamer_V1(ILogger log, string key)
        {
            this.log = log;
            conn = new SnowflakeConnect_V1(log, key, GlobalSettings_V1.SNOWFLAKE_ROLE_PROD_M_DIGI_MANUFACTURING_READER).GetConnection();
            conn.Open();
        }


        public List<OeeData> GetData(string sourcesystem, string machine, string kpiname, string startId)
        {
            List<OeeData> result = new();
            IDbCommand cmd = conn.CreateCommand();
            cmd.CommandText =
                "select top 1000 Id, date_part(year, kpidatetimeend)||'-'||right('00'||date_part(month, kpidatetimeend),2)||'-'||right('00'||date_part(day, kpidatetimeend),2), kpifloatvalue " +
                "from "+GlobalSettings_V1.SNOWFLAKE_DB + "."+GlobalSettings_V1.SNOWFLAKE_SCHEMA + ".smartkpi_values " +
                "where delete_identifier != 'DELETED' " +
                "and sourcesystem = '"+ sourcesystem + "' " +
                "and MACHINE = '"+ machine + "' " +
                "and kpiname = '"+ kpiname + "' " +
                "and id > "+ startId + " " +
                "and kpitimebase = 'day' " +
                "order by id; ";

            using (IDataReader reader = cmd.ExecuteReader())
            {
                // while there is another record present
                while (reader.Read())
                {
                    result.Add(new OeeData() { Id = reader.GetString(0), kpiDate = reader.GetString(1), kpiValue = reader.GetFloat(2) });
                }
            }

            log.LogInformation("Selecting Snowflake data: "+result.Count+" data sets for machine "+machine+" and KPI "+kpiname+" found");
            return result;
        }

        public void Dispose()
        {
            try
            {
                conn?.Close();
                conn?.Dispose();
                log.LogInformation("KpiData4Valuestreamer_V1 disposed");
            }
            catch { }
        }

    }

    internal class OeeData
    {
        public string Id;
        public string kpiDate;
        public float kpiValue;
    }
}
