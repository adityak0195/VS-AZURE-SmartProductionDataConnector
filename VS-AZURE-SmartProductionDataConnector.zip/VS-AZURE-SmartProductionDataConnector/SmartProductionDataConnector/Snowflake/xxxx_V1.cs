﻿using System;
using System.Data;
using SmartProductionDataConnector.Logic;
using Microsoft.Extensions.Logging;
using SmartProductionDataDefinition_V1.JSON.MachineFloatData;

namespace SmartProductionDataConnector.Snowflake
{
    internal class xxxx_V1 : IDisposable
    {
        private readonly IDbConnection conn;

        public xxxx_V1(ILogger log)
        {
            conn = new SnowflakeConnect_V1(log, Environment.GetEnvironmentVariable("Snowflake"), GlobalSettings_V1.SNOWFLAKE_ROLE_PROD_M_DIGI_MANUFACTURING_WRITER).GetConnection();
            conn.Open();
        }

        public int InsertData(System.Collections.Generic.List<JSONSmartKPIMachineFloatDataRow_V1> jsonData)
        {
            int insertedRows = 0;
            for (int i = 0;i < jsonData.Count; i++)
            {
                IDbCommand cmd = conn.CreateCommand();
                cmd.CommandText = "insert into PROD.M_DIGI_MANUFACTURING.SMARTKPI_MACHINEFLOATDATA_DIRECT_PUSH " +
                    "(ID, " +
                    "SOURCESYSTEM , " +
                    "DELETE_IDENTIFIER , " +
                    "MACHINE , " +
                    "MACHINEDATA , " +
                    "MACHINEDATATYPE , " +
                    "MACHINETIME , " +
                    "UTCCREATIONTIME , " +
                    "MACHINEDATALSL , " +
                    "MACHINEDATAUSL , " +
                    "UNIT , " +
                    "DESCRIPTION , " +
                    "COMMENT) " +
                    "select "+
                    jsonData[i].Id+","+
                    "'"+ jsonData[i].SourceSystem + "',"+
                    "'"+ jsonData[i].DELETE_IDENTIFIER + "',"+
                    "'"+ jsonData[i].Machine + "',"+
                    jsonData[i].MachineData+"," +
                    "'"+ jsonData[i].MachineDataType + "',"+
                    "dateadd(ms, "+ jsonData[i].MachineTime + ", date_from_parts(1970, 1, 1))," +
                    "dateadd(ms, "+ jsonData[i].UTCCreationTime + ", date_from_parts(1970, 1, 1))," +
                    jsonData[i].MachineDataLSL+"," +
                    jsonData[i].MachineDataUSL+"," +
                    "'"+ jsonData[i].Unit + "',"+
                    "'"+ jsonData[i].description + "',"+
                    "'"+ jsonData[i].comment + "'";
                insertedRows += cmd.ExecuteNonQuery();
            }

            return insertedRows;

        }

        public int DeleteData()
        {

            IDbCommand cmd = conn.CreateCommand();
            cmd.CommandText = "delete from PROD.M_DIGI_MANUFACTURING.SMARTKPI_MACHINEFLOATDATA_DIRECT_PUSH " +
                "where machinetime <  dateadd(day,-1,current_timestamp()) ";
            return cmd.ExecuteNonQuery();
        }

        public void Dispose()
        {
            try
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
            catch { }
        }
    }
}
