﻿using Microsoft.Data.SqlClient;
using SmartProductionDataConnector.Logic;
using System;
using System.Collections.Generic;
using System.Threading;
using Microsoft.Extensions.Logging;

namespace SmartProductionDataConnector.MSSQL
{
    public class RunProcedureOnFilteredDBs : IDisposable
    {
        private readonly string host;
        private readonly string user;
        private readonly string pw;
        private readonly SqlConnection connectionMaster;
        public RunProcedureOnFilteredDBs()
        {
            GlobalSettings_V1 globalSettings = new();
            host = globalSettings.MSSQL_HOST;
            user = globalSettings.MSSQL_ADMIN_USER;
            pw = globalSettings.MSSQL_ADMIN_PW;

            connectionMaster = new SqlConnection(
                    "Data Source=" + host + "; " +
                    "Initial Catalog = master; " +
                    "User ID=" + user + "; " +
                    "Password=" + pw + "");

            connectionMaster.Open();
        }

        public void RunDeleteArchivedDataOnAllDbsWithPattern(ILogger log, string DBPattern) 
        { 
            List<string> dbs = GetDBs(DBPattern);
            foreach (string db in dbs)
            {
                new Thread(() => ExecCronJobForDeleteArchivedData(log, db))
                {
                    Name = "ExecCronJobForDeleteArchivedData_" + db,
                    IsBackground = true
                }.Start();
            }
        }


        public void ExecCronJobForDeleteArchivedData(ILogger log, string db)
        {
            try
            {
                log.LogInformation("***START ExecCronJob for " + db + " at: " + DateTime.Now.ToString());
                using (SqlConnection connection = new(
                        "Data Source=" + host + "; " +
                        "Initial Catalog = " + db + "; " +
                        "User ID=" + user + "; " +
                        "Password=" + pw + ""))
                {
                    connection.Open();
                    string sqlQuery = "exec DeleteArchivedData @isInfoOnly = 2;";
                    SqlCommand command = new(sqlQuery, connection)
                    {
                        CommandTimeout = 60 * 59
                    };
                    command.ExecuteNonQuery();
                };
                log.LogInformation("***End ExecCronJob for " + db + " at: " + DateTime.Now.ToString());
            } catch (Exception ex)
            {
                log.LogError("***End ExecCronJob for " + db + " at: " + DateTime.Now.ToString() + " with error " + ex.Message);
            }
        }

        public List<string> GetDBs(string DBPattern)
        {
            string sqlQuery =
                "select name from sys.databases where name like '" + DBPattern + "';";
            SqlCommand command = new(sqlQuery, connectionMaster);

            List<string> result = new();

            using (SqlDataReader reader = command.ExecuteReader())
            {
                // while there is another record present
                while (reader.Read())
                {
                    result.Add((string)reader[0]);
                }
            }

            return result;
        }

        public void Dispose()
        {
            try
            {
                connectionMaster?.Close();
            }
            catch { }
        }
    }
}

