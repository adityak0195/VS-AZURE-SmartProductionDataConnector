﻿using Microsoft.Data.SqlClient;
using SmartProductionDataConnector.Logic;
using Microsoft.Extensions.Logging;
using System;

namespace SmartProductionDataConnector.MSSQL
{
    public class SmartKPIKepwareConnectorPointer : IDisposable
    {
        private ILogger log;

        private readonly SqlConnection connection;
        public SmartKPIKepwareConnectorPointer(ILogger log, string database)
        {
            this.log = log;
            string host;
            string user;
            string pw;
            GlobalSettings_V1 globalSettings = new();
            host = globalSettings.MSSQL_HOST;
            user = globalSettings.MSSQL_ADMIN_USER;
            pw = globalSettings.MSSQL_ADMIN_PW;

            connection = new SqlConnection(
                    "Data Source=" + host + "; " +
                    "Initial Catalog = " + database + "; " +
                    "User ID=" + user + "; " +
                    "Password=" + pw + "");

            connection.Open();
            log.LogInformation("Connected to DB " + host + "-->" + database + "-->" + user);
        }

        public long GetPointer(string identifier)
        {
            string sqlQuery =
                "insert into smartKPIKepwareConnectorPointer(Machine, UpdatedId) " +
                "select '"+identifier+"', 0 where not exists(SELECT UpdatedId FROM smartKPIKepwareConnectorPointer where Machine = '"+identifier+"')";
            SqlCommand command = new(sqlQuery, connection);
            command.ExecuteNonQuery();


            sqlQuery =
                "SELECT UpdatedId FROM smartKPIKepwareConnectorPointer where Machine = '"+ identifier + "' " +
                "union " +
                "select 0 where not exists (SELECT UpdatedId FROM smartKPIKepwareConnectorPointer where Machine = '"+ identifier + "')";
            command = new SqlCommand(sqlQuery, connection);

            long UpdatedId = 0;

            using (SqlDataReader reader = command.ExecuteReader())
            {
                // while there is another record present
                if (reader.Read())
                {
                    UpdatedId = (long) reader[0];
                }
            }

            log.LogInformation($"smartKPIKepwareConnectorPointer Updated id: {UpdatedId}");

            return UpdatedId;
        }

        public long SetPointer(string identifier, string value)
        {


            string sqlQuery =
                "update smartKPIKepwareConnectorPointer set UpdatedId = " + value + " where Machine = '" + identifier + "'";
            SqlCommand command = new(sqlQuery, connection);

            long UpdatedId = 0;

            using (SqlDataReader reader = command.ExecuteReader())
            {
                // while there is another record present
                if (reader.Read())
                {
                    UpdatedId = (long)reader[0];
                }
            }

            log.LogInformation($"smartKPIKepwareConnectorPointer Updated id: {value}");
            return UpdatedId;
        }

        public void Dispose()
        {
            try
            {
                connection?.Close();
            }
            catch { }
        }
    }
}
