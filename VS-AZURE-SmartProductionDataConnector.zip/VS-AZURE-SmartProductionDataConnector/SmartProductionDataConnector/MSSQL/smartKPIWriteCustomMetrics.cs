﻿using Microsoft.Data.SqlClient;
using SmartProductionDataConnector.Logic;
using Microsoft.Extensions.Logging;
using System;
using ThirdParty.Json.LitJson;

namespace SmartProductionDataConnector.MSSQL
{
    public class smartKPIWriteCustomMetrics : IDisposable
    {
        private ILogger log;

        private readonly SqlConnection connection;
        public smartKPIWriteCustomMetrics(ILogger log)
        {
            string database = "azure_custommetrics";
            this.log = log;
            string host;
            string user;
            string pw;
            GlobalSettings_V1 globalSettings = new();
            host = globalSettings.MSSQL_HOST;
            user = globalSettings.MSSQL_ADMIN_USER;
            pw = globalSettings.MSSQL_ADMIN_PW;

            connection = new SqlConnection(
                    "Data Source=" + host + "; " +
                    "Initial Catalog = " + database + "; " +
                    "User ID=" + user + "; " +
                    "Password=" + pw + "");

            connection.Open();
            log.LogInformation("Connected to DB " + host + "-->" + database + "-->" + user);
        }


        public void WriteMetric(string container, string stage, string functionname, string identifier, float value)
        {

            string environment = Environment.ExpandEnvironmentVariables("%WEBSITE_SITE_NAME%");
            string sqlQuery =
                "insert into function_monitor (storagecontainer, environment, stage, functionname, identifier, value) values ('"+container+"', '" + environment + "', '"+ stage + "','"+ functionname + "', '"+ identifier + "', "+ value + ")";
            SqlCommand command = new(sqlQuery, connection)
            {
                CommandTimeout = 5
            };
            command.ExecuteNonQuery();

            log.LogMetric(identifier + " " + container, value);

        }

        public void Dispose()
        {
            try
            {
                connection?.Close();
            }
            catch { }
        }
    }
}
