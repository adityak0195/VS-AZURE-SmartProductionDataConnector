using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using SmartProductionDataConnector.Logic;


namespace SmartProductionDataConnector.HTTPFunctions
{
    
    public static class ThingworxDeletedUpload_V1
    {
        [FunctionName("ThingworxDeletedUpload_V1")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation($"***START ThingworxDeletedUpload_V1 C# at: {DateTime.Now}");
            try
            {

                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                //log.LogInformation($"requestBody: {req.Host} {requestBody}");

                ThingworxUploadLogic_V1 thingworxUpload = new(requestBody, log, false, true, GlobalSettings_V1.BLOB_CONNECTION_FINAL);

                if (thingworxUpload.IsUnprocessableEntityObjectResult())
                {
                    log.LogWarning($"***END UnprocessableEntityObjectResult C# at: {DateTime.Now}");
                    return new UnprocessableEntityObjectResult(thingworxUpload.GetUnprocessableEntityObjectResult());
                }
                else
                {
                    log.LogInformation($"***END OkObjectResult C# at: {DateTime.Now}");
                    return new OkObjectResult(thingworxUpload.GetOkObjectResult());
                }
            }
            catch (Exception e)
            {
                log.LogError($"***END BadRequestObjectResult C# at: {DateTime.Now}");
                return new BadRequestObjectResult(ThingworxUploadLogic_V1.GetBaseBadRequestObjectResult("Error: " + e.Message));
            }
        }
    }
}
