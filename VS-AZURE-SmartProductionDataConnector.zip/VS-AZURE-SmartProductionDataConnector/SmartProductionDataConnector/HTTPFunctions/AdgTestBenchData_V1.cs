using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using SmartProductionDataConnector.Logic;

namespace SmartProductionDataConnector.HTTPFunctions
{
    /************************************************************************************************
     * 
     * This function uploads sensor data to the buffer BlobStorage
     * 
     ************************************************************************************************/

    public static class AdgTestBenchData_V1
    {
        [FunctionName("AdgTestBenchData_V1")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation($"***START AdgTestBenchData_V1 C# at: {DateTime.Now}");
            try
            {
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                //log.LogInformation($"requestBody: {req.Host} {requestBody}");

                AdgTestBenchDataLogic_V1 adgTestBenchData = new(requestBody, log, true, false, GlobalSettings_V1.BLOB_CONNECTION_BUFFER);

                if (adgTestBenchData.IsUnprocessableEntityObjectResult())
                {
                    log.LogWarning($"***END UnprocessableEntityObjectResult C# at: {DateTime.Now}");
                    return new UnprocessableEntityObjectResult(adgTestBenchData.GetUnprocessableEntityObjectResult());
                }
                else
                {
                    log.LogInformation($"***END OkObjectResult C# at: {DateTime.Now}");
                    return new OkObjectResult(adgTestBenchData.GetOkObjectResult());
                }
            } catch (Exception e)
            {
                log.LogError($"***END BadRequestObjectResult C# at: {DateTime.Now}");
                return new BadRequestObjectResult(AdgTestBenchDataLogic_V1.GetBaseBadRequestObjectResult("Error: " + e.Message));
            }
        }
    }
}
