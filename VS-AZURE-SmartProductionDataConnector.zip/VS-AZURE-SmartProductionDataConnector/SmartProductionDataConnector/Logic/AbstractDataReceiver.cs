﻿using System;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Text.RegularExpressions;
using Azure.Storage.Blobs;
using SmartProductionDataDefinition_V1.JSON.Template;
using System.Reflection.Metadata.Ecma335;

namespace SmartProductionDataConnector.Logic
{
    internal abstract class AbstractDataReceiver<Tin, Tout> where Tin : JSONDataInput_V1 where Tout : JSONDataOutput_V1, new()
    {
        internal Guid Guid;
        internal DateTime Now;
        internal string BlobContainer;
        internal ILogger log;
        internal Tin JsonInput;
        internal Boolean UseDataBuffer;
        internal Boolean IsDeletedData;
        internal string blobConnection;

        protected AbstractDataReceiver(string requestBody, ILogger log, Boolean UseDataBuffer, Boolean IsDeletedData, string blobConnection) {
            this.Guid = Guid.NewGuid();
            this.log = log;
            this.UseDataBuffer = UseDataBuffer;
            this.IsDeletedData = IsDeletedData;
            this.blobConnection = blobConnection;
            Now = DateTime.UtcNow;


            if (requestBody != null)
            {
                JsonInput = JsonConvert.DeserializeObject<Tin>(requestBody);
                JsonInput.StagingLevel = JsonInput.StagingLevel.ToUpper();
                if (JsonInput.StagingLevel == "")
                {
                    JsonInput.StagingLevel = BlobStorageStagingLevel.PROD;
                }
            }

            if (UseDataBuffer)
            {
                BlobContainer = "buffer-" + JsonInput.StagingLevel.ToLower() + "-" + Regex.Replace(JsonInput.SourceSystem.ToLower(), "[^a-zA-Z0-9]", "-");
            }
            else
            {
                BlobContainer = GlobalSettings_V1.BLOB_CONTAINER;
            }
        }

        internal void DeleteFromReceiverBlobStorage(string connection, string container, string fileName)
        {
            BlobStorage_V1.DeleteFromReceiverBlobStorage(connection, container, fileName, log);
        }

        internal Tin GetJsonInput()
        {
            return JsonInput;
        }

        internal Boolean IsBaseUnprocessableBaseEntityObjectResult()
        {
            return JsonInput.SourceSystem == null
                || JsonInput.StagingLevel == null
                || JsonInput.SourceSystem == ""
                || (JsonInput.StagingLevel != BlobStorageStagingLevel.DEV && JsonInput.StagingLevel != BlobStorageStagingLevel.TEST && JsonInput.StagingLevel != BlobStorageStagingLevel.PROD)
                || ((Environment.ExpandEnvironmentVariables("%WEBSITE_SITE_NAME%") == GlobalSettings_V1.DEV_FUNCTION_APP_WEEU) && JsonInput.StagingLevel == BlobStorageStagingLevel.PROD)
                || ((Environment.ExpandEnvironmentVariables("%WEBSITE_SITE_NAME%") == GlobalSettings_V1.PRD_FUNCTION_APP_WEEU) && JsonInput.StagingLevel != BlobStorageStagingLevel.PROD);
        }

        internal string PrepareOutput(string datatype)
        {

            BlobContainerClient blobContainer = new(Environment.GetEnvironmentVariable(blobConnection), BlobContainer);
            blobContainer.CreateIfNotExists();
            string filename;
            if (UseDataBuffer)
            {
                filename = datatype + "/" + ((long)(Now - new DateTime(1970, 1, 1)).TotalMilliseconds).ToString() + "-" + this.Guid.ToString() + ".json";
            }
            else
            {
                filename = CreateOutputFileName(datatype);
            }

            return filename;
        }

        internal JSONDataOutput_V1 GetBaseOkObjectResult(string datatype)
        {
            BlobStorage_V1.WriteToCommonBlobStorage(blobConnection, BlobContainer, PrepareOutput(datatype), JsonInput, log);
            return new JSONDataOutput_V1(){Result = "OK", Guid = Guid  };
        }

        internal JSONDataOutput_V1 GetBaseOkObjectResult(string datatype, string content)
        {
            BlobStorage_V1.WriteToCommonBlobStorage(blobConnection, BlobContainer, PrepareOutput(datatype), content, log);
            return new JSONDataOutput_V1() { Result = "OK", Guid = Guid };
        }


        internal static Tout GetBaseBadRequestObjectResult(string text)
        {
            return new Tout()
            {
                Result = text
            };
        }

        internal JSONDataOutput_V1 GetBaseUnprocessableEntityObjectResult()
        {
            string errorText = "Key parameters (DeviceName, SensorName, SourceSystem, MeassurementDateTimeJava) may not be null or empty";

            JSONDataOutput_V1 jsonDataOutput = new()
            {
                Result = errorText,
                Guid = this.Guid
            };
            log.LogError(jsonDataOutput.ToString());
            return jsonDataOutput;
        }

        internal string CreateFileNameWithoutPath(string targetDataType)
        {
            
            return CreateFileNameWithoutPath(targetDataType, Now, IsDeletedData, UseDataBuffer, Guid);
        }

        internal static string CreateFileNameWithoutPath(string targetDataType, DateTime dateTime, Boolean isDeletedData, Boolean useDataBuffer, Guid guid)
        {
            string filename = ((long)(dateTime - new DateTime(1970, 1, 1)).TotalMilliseconds).ToString() + "_incremental_";
            if (isDeletedData)
            {
                filename += "DELETE_IDENTIFIER_";
            }
            filename += targetDataType;

            if (useDataBuffer)
            {
                filename += "_DirectPush_" + GlobalSettings_V1.VERSION + "_" + guid.ToString();
            }
            filename += ".json";
            return filename;
        }

        internal string CreateOutputFileName(string targetDataType)
        {
            return CreateOutputFileName(JsonInput.StagingLevel, JsonInput.SourceSystem, Now, targetDataType, IsDeletedData, UseDataBuffer, Guid);
        }

        internal static string CreateOutputFileName(string stagingLevel, string sourceSystem, DateTime dateTime, string targetDataType, Boolean isDeletedData, Boolean useDataBuffer, Guid guid)
        {
            string filenameTarget = "";
            filenameTarget += stagingLevel + "/";
            filenameTarget += GlobalSettings_V1.GetDivision(sourceSystem) + "/";
            filenameTarget += targetDataType + "/";
            filenameTarget += dateTime.Year + "/";
            filenameTarget += dateTime.Month + "/";
            filenameTarget += dateTime.Day + "/";
            filenameTarget += sourceSystem + "/";
            filenameTarget += CreateFileNameWithoutPath(targetDataType, dateTime, isDeletedData, useDataBuffer, guid);

            return filenameTarget;
        }

    }
}
