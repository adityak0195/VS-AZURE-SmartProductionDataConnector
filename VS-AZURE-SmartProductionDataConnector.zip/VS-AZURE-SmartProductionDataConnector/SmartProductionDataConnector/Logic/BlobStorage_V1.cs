﻿using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using Newtonsoft.Json;
using Org.BouncyCastle.Ocsp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace SmartProductionDataConnector.Logic
{
    public class BlobStorageStagingLevel
    {
        public const string DEV = "DEV";
        public const string PROD = "PROD";
        public const string TEST = "TEST";
    }

    public class BlobStorage_V1
    {
        public static async Task<List<string>> ListContainers(string connection, ILogger log)
        {
            log.LogInformation($"ListContainers {connection}");
            return await ListContainers(CloudStorageAccount.Parse(Environment.GetEnvironmentVariable(connection)), log);
        }
        public static async Task<List<string>> ListContainers(CloudStorageAccount storageAccount, ILogger log)
        {
            List<string> containers = new ();

            var blobClient = storageAccount.CreateCloudBlobClient();
            BlobContinuationToken continuationToken = null;
            do
            {
                // List containers beginning with the specified prefix, returning segments of 5 results each. 
                // Note that passing in null for the maxResults parameter returns the maximum number of results (up to 5000).
                // Requesting the container's metadata as part of the listing operation populates the metadata, 
                // so it's not necessary to call FetchAttributes() to read the metadata.
                ContainerResultSegment resultSegment = await blobClient.ListContainersSegmentedAsync(
                    null, ContainerListingDetails.Metadata, 5, continuationToken, null, null);

                // Enumerate the containers returned.
                foreach (var container in resultSegment.Results)
                {
                    containers.Add(container.Name);
                }

                // Get the continuation token.
                continuationToken = resultSegment.ContinuationToken;

            } while (continuationToken != null);
            return containers;
        }

        public static async Task<List<string>> ListBlobs(string connection, string container, string prefix, ILogger log)
        {
            return await ListBlobs(CloudStorageAccount.Parse(Environment.GetEnvironmentVariable(connection)), container, prefix, log);
        }
        public static async Task<List<string>> ListBlobs(string connection, string container, string prefix, int numberOfResult, ILogger log)
        {
            return await ListBlobs(CloudStorageAccount.Parse(Environment.GetEnvironmentVariable(connection)), container, prefix, numberOfResult, log);
        }

        public static async Task<List<string>> ListBlobs(CloudStorageAccount storageAccount, string container, string prefix, ILogger log)
        {
            log.LogInformation($"ListBlobs {container}");
            List<string> blobs = new();

            var blobClient = storageAccount.CreateCloudBlobClient();
            var blobContainer = blobClient.GetContainerReference(container);


            BlobContinuationToken continuationToken = null;
            do
            {
                // List containers beginning with the specified prefix, returning segments of 5 results each. 
                // Note that passing in null for the maxResults parameter returns the maximum number of results (up to 5000).
                // Requesting the container's metadata as part of the listing operation populates the metadata, 
                // so it's not necessary to call FetchAttributes() to read the metadata.
                BlobResultSegment resultSegment = await blobContainer.ListBlobsSegmentedAsync(prefix, continuationToken);

                // Enumerate the containers returned.
                foreach (var blob in resultSegment.Results)
                {
                    string uri = blob.Uri.ToString();
                    string name = uri[(uri.IndexOf(container) + container.Length + 1)..];
                    blobs.Add(name);
                }

                // Get the continuation token.
                continuationToken = resultSegment.ContinuationToken;

            } while (continuationToken != null);
            return blobs;
        }

        public static async Task<List<string>> ListBlobs(CloudStorageAccount storageAccount, string container, string prefix, int numberOfResults, ILogger log)
        {
            log.LogInformation($"ListBlobs {container}");
            List<string> blobs = new();

            var blobClient = storageAccount.CreateCloudBlobClient();
            var blobContainer = blobClient.GetContainerReference(container);


            BlobContinuationToken continuationToken = null;
            int counter = 0;
            do
            {
                // List containers beginning with the specified prefix, returning segments of 5 results each. 
                // Note that passing in null for the maxResults parameter returns the maximum number of results (up to 5000).
                // Requesting the container's metadata as part of the listing operation populates the metadata, 
                // so it's not necessary to call FetchAttributes() to read the metadata.
                //BlobResultSegment resultSegment = await blobContainer.ListBlobsSegmentedAsync(prefix, continuationToken);
                BlobResultSegment resultSegment = await blobContainer.ListBlobsSegmentedAsync(prefix, false, BlobListingDetails.Metadata, 5, continuationToken, null, null);

                // Enumerate the containers returned.
                foreach (var blob in resultSegment.Results)
                {
                    string uri = blob.Uri.ToString();
                    string name = uri[(uri.IndexOf(container) + container.Length + 1)..];
                    blobs.Add(name);
                    counter++;
                }

                // Get the continuation token.
                continuationToken = resultSegment.ContinuationToken;

            } while (continuationToken != null && counter < numberOfResults);
            return blobs;
        }
        public static async Task<string> ReadBlob(string connection, string container, string name, ILogger log)
        {
            //log.LogInformation($"ReadBlob {name}");
            string content = null;

            BlobServiceClient blobServiceClient;
            if (connection.Contains("AccountKey="))
            {
                blobServiceClient = new(connection);
            }
            else
            {
                blobServiceClient = new(Environment.GetEnvironmentVariable(connection));
            }

            BlobContainerClient containerClient = blobServiceClient.GetBlobContainerClient(container);
            BlobClient blobClient = containerClient.GetBlobClient(name);
            if (await blobClient.ExistsAsync())
            {
                var response = await blobClient.DownloadAsync();
                using var streamReader = new StreamReader(response.Value.Content);
                content = await streamReader.ReadToEndAsync();
            }
            return content;
        }
        public static void DeleteFromReceiverBlobStorage(string connection, string container, string fileName, ILogger log)
        {
            //log.LogInformation($"DeleteFromReceiverBlobStorage {fileName}, container {container}");
            var storageAccountSource = CloudStorageAccount.Parse(Environment.GetEnvironmentVariable(connection));
            var blobClientSource = storageAccountSource.CreateCloudBlobClient();
            var containerSource = blobClientSource.GetContainerReference(container);
            var blobSource = containerSource.GetBlockBlobReference(fileName);
            blobSource.DeleteAsync().Wait();
        }

        public static void WriteToCommonBlobStorage(string targetConnection, string targetContainer, string targetFileName, object content, ILogger log)
        {
            WriteToCommonBlobStorage(targetConnection, targetContainer, targetFileName, JsonConvert.SerializeObject(content, Formatting.Indented), log);
        }

        public static void WriteToCommonBlobStorage(string targetConnection, string targetContainer, string targetFileName, string content, ILogger log)
        {
            if (content != "[]")
            {
                log.LogInformation($"WriteToCommonBlobStorage {targetFileName}");
                var storageAccountTarget = CloudStorageAccount.Parse(Environment.GetEnvironmentVariable(targetConnection));
                var blobClientTarget = storageAccountTarget.CreateCloudBlobClient();
                var containerTarget = blobClientTarget.GetContainerReference(targetContainer);
                var blobTarget = containerTarget.GetBlockBlobReference(targetFileName);
                blobTarget.Properties.ContentType = "text/json";

                blobTarget.UploadTextAsync(content).Wait();
            } 
            else
            {
                log.LogInformation($"WriteToCommonBlobStorage {targetFileName} skipped --> empty");
            }
        }
    }
}
