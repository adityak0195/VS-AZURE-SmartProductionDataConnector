﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartProductionDataConnector.Logic
{
    public class GlobalSettings_V1
    {
        internal const string VERSION = "V1";
        internal const string DEV_FUNCTION_APP_WEEU = "dev-thingworx-weeu-smartproduction-4rhjurm-funcapp";
        internal const string PRD_FUNCTION_APP_WEEU = "prd-thingworx-weeu-smartproduction-zymir4x-funcapp";
        internal const string DEV_FUNCTION_APP_SEAS = "dev-thingworx-seas-smartproduction-dtaicl4-funcapp";
        internal const string PRD_FUNCTION_APP_SEAS = "prd-thingworx-seas-smartproduction-h2o57js-funcapp";
        internal const string DEV_FUNCTION_APP_EUS2 = "dev-thingworx-eus2-smartproduction-wuhohhf-funcapp";
        internal const string PRD_FUNCTION_APP_EUS2 = "prd-thingworx-eus2-smartproduction-63eiyu4-funcapp";
        public const string BLOB_CONNECTION_FINAL = "SmartProductionBlobStorage"; //Connection defined in Function Configuration!!
        public const string BLOB_CONNECTION_BUFFER = "BufferBlobStorage"; //Connection defined in Function Configuration!!
        public const string BLOB_CONTAINER = "smartproductiondataupload-v3";

        internal const string SNOWFLAKE_HOST = "hs05738.west-europe.azure.snowflakecomputing.com";
        internal const string SNOWFLAKE_DB = "CORP_PROD_M_DB";
        internal const string SNOWFLAKE_USER = "SVC.MUC.THINGWORX@KNORR-BREMSE.COM";
        internal const string SNOWFLAKE_WAREHOUSE = "CORP_PROD_ANALYTICS_WH";
        internal const string SNOWFLAKE_SCHEMA = "CVS_SMARTPRODUCTION";
        internal const string SNOWFLAKE_ROLE_PROD_M_DIGI_MANUFACTURING_WRITER = null;
        internal const string SNOWFLAKE_ROLE_PROD_M_DIGI_MANUFACTURING_READER = "CORP_PROD_CVS_SMARTPRODUCTION_GLOBAL_FR";
        internal const string SNOWFLAKE_ACCOUNT = "hs05738";
        internal const string SNOWFLAKE_KEY = "05-08-C5-99-2D-4A-8C-8E-31-56-D5-1D-BD-BB-86-35-4D-52-8A-9B-5A-36-1C-6C-36-1A-24-18-2F-EF-4B-21-19-AE-2D-25-72-8E-50-30-13-3A-2C-DE-66-A6-FD-79-06-11-F0-08-8F-7B-D2-87-F5-E8-90-42-E8-0E-6B-49-48-C9-2D-2B-02-08-9C-EC-A3-D9-7E-42-CC-A9-BD-4E-CC-28-FB-84-DF-A0-C1-48-D0-F7-64-F6-EA-F6-E2-D3-0B-BE-98-83-1C-32-1F-73-24-11-98-63-57-51-7F-66-6A-6F-72-7A-F7-73-A5-B5-C3-25-ED-6D-F2-ED-14-6B-72-78-C2-9E-2E-43-94-98-49-66-5B-42-D6-79-B8-F1-E5-59-BC-44-CE-D3-E3-E5-53-46-F5-A8-B4-51-82-5C-1E-F6-C8-FB-03-7E-D9-86-9B-0F-E2-10-A8-84-C1-A9-DA-D8-CC-90-6D-00-6B-83-A7-EA-46-F5-58-6D-0C-FC-89-1A-E2-3A-96-E8-89-AE-48-79-AD-69-0F-51-C0-AF-B3-77-DB-AC-54-A6-35-64-2E-4D-89-A2-11-69-AA-0E-7A-05-5A-4C-C4-38-5F-D6-58-A1-E2-25-43-1A-B0-FA-09-C3-31-30-23-E3-3A-34-CE-90-FD-7A-50-BE-FB-90-1D-C2-99-2B-07-A6-F1-3D-D1-DC-38-3E-DA-B6-0A-97-A2-C2-F1-B9-03-80-FC-6D-D8-74-EA-EA-E2-91-E6-7A-38-C1-8C-6D-0C-49-45-28-41-0A-D8-30-D3-8A-4A-EA-F9-2A-0B-3B-D6-1A-A6-08-91-37-51-77-42-26-29-F6-4F-EB-0B-99-73-37-9B-09-02-7E-41-9F-A5-E4-A2-C9-6D-37-B1-B4-FB-E8-C6-C3-4D-CC-DB-52-78-76-99-45-C1-93-CF-5C-F0-D6-47-58-4F-FC-04-72-14-E8-D5-49-36-AA-13-8F-AF-A4-C0-77-3B-15-FE-B7-D2-14-32-ED-FF-86-05-71-C3-02-3F-09-CD-8B-26-55-2D-B3-E3-F2-E2-B5-0B-91-AD-A0-66-F8-0E-29-72-E5-4F-C2-CC-9F-60-2A-41-15-88-90-F7-0F-33-F0-19-37-10-19-3C-F6-A6-0F-28-5E-4F-0C-C6-87-17-AB-E6-49-2E-31-E6-48-B2-EA-09-42-FD-90-C9-A5-DC-48-E0-D6-B0-95-41-E4-00-38-DC-85-AD-F0-0B-4B-3C-13-C4-95-6B-6D-4B-06-0B-B7-13-C3-F6-A5-13-A5-73-7F-23-D9-61-C0-DA-65-9E-7C-61-23-F5-4A-72-5C-0B-ED-F1-D2-DE-2B-4A-A1-FD-46-BD-68-89-87-1A-04-C0-5E-65-69-B5-ED-72-88-62-26-50-D0-EE-15-F3-E0-9B-C3-60-2B-71-6F-D1-64-63-BE-5C-ED-53-0B-07-78-7B-7B-E6-52-E1-4D-01-8D-3C-56-6D-E1-33-2C-27-61-36-FB-EC-24-A1-A8-88-E0-83-6E-93-B3-10-67-B9-63-4A-4C-77-A9-35-1B-2B-01-21-15-EA-D2-D7-74-A9-29-3C-75-79-CF-6B-1D-66-1B-85-9C-61-F8-9D-39-B0-95-1F-D4-1D-6B-F5-72-80-3D-82-E4-6F-43-84-84-02-EC-D8-26-9E-1C-52-0E-D1-56-75-66-16-9E-27-49-43-76-3A-47-A3-B0-DD-19-D1-60-6E-2B-9B-CA-24-68-66-C1-2A-15-09-76-C4-94-52-B9-E2-9F-0B-59-7E-32-9A-B0-84-A6-14-F9-D7-3F-17-CF-D6-82-7C-75-AA-90-46-78-C4-93-A1-D4-EF-18-2E-F8-DB-9D-D8-91-E7-57-17-85-FD-A7-47-6F-F8-7C-24-23-3B-1A-A4-ED-C3-3B-18-90-41-47-20-4F-CE-2F-DB-07-CF-E1-4D-F3-FA-8B-69-3B-F4-85-5A-30-29-F6-F9-D2-EE-B8-9F-30-CD-01-F6-82-8E-55-A1-48-DB-0D-CA-C1-F4-10-C8-45-4D-6D-99-30-FD-1D-F6-BF-27-0B-D9-A0-FB-1C-60-D1-AD-DD-E6-EF-4A-81-9B-44-DF-B9-36-0A-6A-21-2A-56-CB-15-C9-C8-C1-08-45-90-15-33-A6-78-28-72-55-E9-3B-71-F0-D9-42-D3-0B-EE-CC-F2-1A-18-8F-CE-42-74-C8-D8-E9-4F-FF-B7-D8-8A-6A-9A-75-D5-5C-20-4B-4B-B8-61-81-5A-F1-3D-6C-8D-DA-88-1C-76-C4-CC-45-31-53-AA-B1-CE-79-B5-C2-0E-11-FB-EB-B2-13-32-4C-DA-15-28-3C-11-09-5D-BB-2D-5B-25-FB-28-81-CE-C1-C6-65-1C-F8-48-FC-A5-3E-18-F7-50-24-D0-3F-FB-C4-5A-2D-87-22-A5-96-B2-6F-94-03-21-E5-3C-9B-70-D9-1F-39-1E-38-8C-04-38-0C-6D-90-B6-6D-93-CB-F7-91-1E-66-F3-D2-40-D5-D8-A3-EC-51-BF-02-69-DF-AC-97-28-B9-97-1F-E1-27-85-2E-E1-D0-6F-34-B9-69-1D-51-6B-FB-86-20-66-1B-48-F9-23-37-42-6E-E6-16-80-92-CE-DC-4D-99-71-46-BD-4A-90-70-26-44-90-01-6A-2C-59-23-91-16-33-C5-51-42-91-26-53-22-07-52-9E-07-AA-1A-B4-C7-A2-9B-C9-C8-82-72-B7-D5-3A-78-8A-74-47-4A-E7-30-D7-A7-EF-07-56-2A-30-3B-6E-25-4B-F5-1A-5E-5E-90-BD-A9-5E-3D-47-26-AB-97-74-7D-4F-78-9E-9B-12-E3-A3-74-F2-F5-58-3A-F5-56-DA-8C-E8-05-70-FF-8F-C2-25-67-D6-13-EA-66-1E-31-73-7A-33-B0-9E-D0-BE-81-AC-91-CB-8E-17-8C-6C-6E-47-50-CC-11-23-7D-60-F0-46-AE-0D-B8-6E-57-69-6E-FA-CE-22-B0-C5-9E-7F-29-8C-3F-E3-0E-AE-41-00-61-EC-E1-32-03-8A-6B-20-0D-57-F8-C5-FA-90-A2-BA-EC-63-40-FE-D4-06-C9-5B-5D-55-34-27-D3-DA-C0-6E-BD-92-0B-D3-EA-6F-4C-2D-3F-EA-81-74-17-0F-ED-DA-1E-78-B4-9B-D4-C1-41-CE-02-7B-64-B9-3C-59-76-76-42-F9-E4-0F-F3-69-A2-10-C8-4F-BA-CE-E1-55-75-B9-ED-97-C5-54-FD-25-3E-9D-2B-1E-FB-01-D8-30-15-97-7A-28-C3-D5-F7-89-57-93-63-9A-11-4D-FA-0C-AB-BB-01-5B-2A-80-19-A5-F9-A8-65-A2-C6-C2-55-D2-AB-2D-71-BF-35-88-5E-A9-10-D3-29-DB-62-67-28-37-EC-F8-61-99-85-75-8E-BB-E6-CC-F1-89-D8-F7-E4-7A-7A-6F-0D-08-03-B4-3A-74-DF-68-AA-48-55-7C-73-74-1C-5B-F8-E7-39-6E-B2-D7-83-54-C1-95-84-6A-08-AD-EE-A2-FF-96-EF-6E-6C-63-EF-50-BF-42-B1-21-8B-4D-61-EE-22-BE-5D-2D-02-0A-43-CE-AE-9B-11-A0-01-55-B0-3F-B5-30-8B-49-B1-4B-79-9E-FD-F9-CA-A8-FE-48-FC-6A-BF-44-EA-2B-9B-70-38-25-1A-15-39-92-FD-DF-10-76-A4-B8-69-2D-C4-CB-74-78-C5-CB-9E-3C-F2-11-9A-8E-C9-82-51-45-FA-08-26-6E-AF-44-45-C3-E0-7D-72-5B-80-B5-E9-B9-DA-8D-F0-1B-EB-42-31-42-63-81-6A-3B-2D-D5-DA-C8-B5-C1-35-F9-16-70-76-08-15-F4-DA-F6-68-CC-2A-BD-8B-44-5E-71-A1-8A-0D-77-90-91-8F-CA-49-22-AA-7D-1C-A9-59-55-17-85-00-90-11-03-85-F2-8C-ED-F5-BA-78-5D-AF-39-8F-ED-68-0E-A0-52-F7-F5-30-D7-28-21-66-7E-AA-99-09-E8-CD-BB-C6-CA-E1-F3-CB-E3-44-7B-1C-42-C0-46-9D-32-DC-64-F8-02-93-CD-99-B3-16-20-06-38-BC-A2-61-68-AA-62-71-88-D7-39-5B-27-4D-87-C2-E7-33-08-AA-76-1A-97-DC-D7-35-FB-EF-F4-AB-51-10-05-D1-40-E0-D1-52-31-96-45-87-5B-29-5A-FD-CA-BE-0D-1B-90-3B-2B-E1-1D-26-EF-36-FA-F7-C3-97-C6-B3-30-8A-84-22-E5-C5-58-D4-43-D3-0F-D1-C2-5D-D9-AE-32-61-E5-21-48-EB-74-C1-86-84-47-27-39-E5-A9-89-DA-A6-1B-18-D9-0E-CF-9C-46-FB-74-7F-77-40-AC-E2-9C-0F-7B-94-12-3B-E2-2D-3A-1E-84-FB-D3-74-13-79-D0-A5-8E-8B-92-40-CB-27-36-AA-76-9D-2C-96-3A-14-44-CF-84-EF-0E-3C-23-23-4C-47-FA-EC-60";

        internal string MSSQL_HOST;
        internal string MSSQL_ADMIN_USER;
        internal string MSSQL_ADMIN_PW;

        public GlobalSettings_V1()
        {
            MSSQL_HOST = Environment.GetEnvironmentVariable("AZURE_MSSQL_HOST");
            MSSQL_ADMIN_USER = Environment.GetEnvironmentVariable("AZURE_MSSQL_ADMIN_USER");
            MSSQL_ADMIN_PW = Environment.GetEnvironmentVariable("AZURE_MSSQL_ADMIN_PW");
        }

        public Boolean CheckParameters()
        {
            Boolean result = true;

            result = result && VERSION != null;
            result = result && BLOB_CONTAINER != null;
            result = result && BLOB_CONNECTION_BUFFER != null;
            result = result && BLOB_CONNECTION_FINAL != null;
            result = result && BLOB_CONTAINER != null;
            result = result && SNOWFLAKE_HOST != null;
            result = result && SNOWFLAKE_DB != null;
            result = result && SNOWFLAKE_USER != null;
            result = result && SNOWFLAKE_WAREHOUSE != null;
            result = result && SNOWFLAKE_SCHEMA != null;
            result = result && SNOWFLAKE_ROLE_PROD_M_DIGI_MANUFACTURING_READER != null;
            result = result && SNOWFLAKE_ACCOUNT != null;   
            result = result && SNOWFLAKE_KEY != null;

            result = result && MSSQL_HOST != null;
            result = result && MSSQL_ADMIN_USER != null;
            result = result && MSSQL_ADMIN_PW != null;
            result = result && MSSQL_ADMIN_PW != null;

            result = result && BlobStorageStagingLevel.DEV != null;
            result = result && BlobStorageStagingLevel.PROD != null;
            result = result && BlobStorageStagingLevel.TEST != null;            
            return result;
        }

        public static string GetDivision(string sourceSystem)
        {
            sourceSystem = sourceSystem.ToLower();

            string divisionRVS = "RVS";
            string divisionCVS = "CVS";
            string divisionGlobal = "GLOBAL";
            string divisionUnknown = "UNKNOWN";
            string divisionTest = "FUNCTIONALTEST";

            if
                (
                    sourceSystem.StartsWith("smartproductioncvs") ||
                    sourceSystem.StartsWith("smartproductionlis") ||
                    sourceSystem.StartsWith("smartproductionkec") ||
                    sourceSystem.StartsWith("smartproductionald") ||
                    sourceSystem.StartsWith("smartproductionber") ||
                    sourceSystem.StartsWith("smartproductionpun") ||
                    sourceSystem.StartsWith("smartproductionbwg") ||
                    sourceSystem.StartsWith("smartproductiondrt") ||
                    sourceSystem.StartsWith("smartproductionlib")
                )
            {
                return divisionCVS;
            }
            else if
                (
                    sourceSystem.StartsWith("smartproductionrvs") ||
                    sourceSystem.StartsWith("smartproductionbud") ||
                    sourceSystem.StartsWith("smartproductionbrq") ||
                    sourceSystem.StartsWith("smartproductionmlk") ||
                    sourceSystem.StartsWith("smartproductionpna") ||
                    sourceSystem.StartsWith("smartproductionkba") ||
                    sourceSystem.StartsWith("smartproductionkbb") ||
                    sourceSystem.StartsWith("smartproductionsmp") ||
                    sourceSystem.StartsWith("smartproductionszh") ||
                    sourceSystem.StartsWith("smartproductionart") ||
                    sourceSystem.StartsWith("navigateart") ||
                    sourceSystem.StartsWith("smartproductionmil")
                )
            {
                return divisionRVS;
            }
            else if
                (
                    sourceSystem.StartsWith("smartproductionmuc")
                )
            {
                return divisionGlobal;
            }
            else if
                (
                    sourceSystem == "FUNCTIONALTEST_V1".ToLower()
                )
            {
                return divisionTest;
            }
            else
            {
                return divisionUnknown;
            }

        }

    }
}
