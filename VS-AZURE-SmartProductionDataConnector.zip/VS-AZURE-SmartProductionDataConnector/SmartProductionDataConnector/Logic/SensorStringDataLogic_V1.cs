﻿using SmartProductionDataConnector.Snowflake;
using System;
using Microsoft.Extensions.Logging;
using SmartProductionDataDefinition_V1.JSON.Template;
using SmartProductionDataDefinition_V1.JSON.SensorStringData;
using SmartProductionDataDefinition_V1.JSON.MachineStringData;
using Amazon.S3.Model;
using System.Text;
using System.Security.Cryptography;

namespace SmartProductionDataConnector.Logic
{
    internal class SensorStringDataLogic_V1 : AbstractDataReceiver<JSONSensorStringDataInput_V1, JSONDataOutput_V1>
    {


        internal SensorStringDataLogic_V1(string requestBody, ILogger log, Boolean UseDataBuffer, Boolean IsDeletedData, String blobConnection) : base (requestBody, log, UseDataBuffer, IsDeletedData, blobConnection)
        {
        }

        private long GenerateNumericId(string ProcessDataType, DateTime ProductionTime)
        {
            // Generate the first 13 digits from the Unix timestamp in milliseconds
            long javaTime = (long)(ProductionTime - new DateTime(1970, 1, 1)).TotalMilliseconds/10;

            // Generate 3-digit hash suffix from Machine and ProcessDataType
            long processTypeHash = GenerateProcessTypeHash(ProcessDataType);
           

            // Construct the 16-digit ID
            long id = (-1 * javaTime * 10000) - processTypeHash;

            return id; // Ensure negative value
        }

        private long GenerateProcessTypeHash(string ProcessDataType)
        {
            string input = $"{ProcessDataType}";

            // Compute multiple hash-based values
            return ComputeSHA256Hash(input) % 10000; // 4-digit from SHA256      

        }

        static long ComputeSHA256Hash(string input)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(input));
                return BitConverter.ToInt64(hashBytes, 0) & 0x7FFFFFFFFFFFFFFF; // Ensure positive
            }
        }

        internal JSONSmartKPIMachineStringDataRow_V1 ConvertInputToSmartKPIMachineStringData()
        {
            long javaTime = (long)(Now - new DateTime(1970, 1, 1)).TotalMilliseconds;
            DateTime measurementDateTime = new DateTime(1970, 1, 1).AddMilliseconds(JsonInput.MeassurementDateTimeJava);
            JSONSmartKPIMachineStringDataRow_V1 jsonSmartKPIMachineStringDataRow = new()
            {
                Machine = JsonInput.DeviceName,
                UTCCreationTime = javaTime,
                MachineData = JsonInput.MeassurementValue,
                MachineDataType = JsonInput.SensorName,
                CreationTime = javaTime,
                MachineTime = JsonInput.MeassurementDateTimeJava,
                SourceSystem = JsonInput.SourceSystem,
                description = JsonInput.Description,
                comment = JsonInput.Comment,
                Plant = JsonInput.Plant,
                Division = JsonInput.Division,
                Id = GenerateNumericId( JsonInput.SensorName, measurementDateTime) // Updated ID generation
            };

            return jsonSmartKPIMachineStringDataRow;
        }




        internal JSONProcessSensorStringDataToSmartKPIMachineStringData_V1 ProcessSensorStringDataToSmartKPIMachineStringData()
        {
            JSONProcessSensorStringDataToSmartKPIMachineStringData_V1 result = new()
            {
                jsonSmartKPIMachineStringData = new(),
                jsonSensorStringDataOutput = new()
            };

            string filenameTarget = CreateOutputFileName("smartKPIMachineStringData");
            result.jsonSmartKPIMachineStringData = ConvertInputToSmartKPIMachineStringData();

            result.jsonSensorStringDataOutput = new JSONSensorStringDataOutput_V1()
            {
                Result = filenameTarget,
                JSONinput = JsonInput,
                Guid = this.Guid
            };

            return result;
        }


        internal Boolean IsUnprocessableEntityObjectResult()
        {
            return IsBaseUnprocessableBaseEntityObjectResult()
                || JsonInput.DeviceName == null 
                || JsonInput.SensorName == null 
                || JsonInput.DeviceName == "" 
                || JsonInput.SensorName == "" 
                || JsonInput.MeassurementDateTimeJava <= 0;
        }

        internal JSONSensorStringDataOutput_V1 GetOkObjectResult()
        {
            JSONSensorStringDataOutput_V1 jsonSensorStringDataOutput = GetBaseOkObjectResult("sensorstringdata").JSONSensorStringDataOutput_V1();
            jsonSensorStringDataOutput.JSONinput = JsonInput;
            return jsonSensorStringDataOutput;
        }


        internal JSONSensorStringDataOutput_V1 GetUnprocessableEntityObjectResult()
        {
            JSONSensorStringDataOutput_V1 jsonSensorStringDataOutput = GetBaseUnprocessableEntityObjectResult().JSONSensorStringDataOutput_V1();
            jsonSensorStringDataOutput.JSONinput = JsonInput;
            return jsonSensorStringDataOutput;
        }

    }
}
