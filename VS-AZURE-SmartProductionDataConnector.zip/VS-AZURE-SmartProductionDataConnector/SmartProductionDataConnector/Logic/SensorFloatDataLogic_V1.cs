﻿using SmartProductionDataConnector.Snowflake;
using System;
using Microsoft.Extensions.Logging;
using SmartProductionDataDefinition_V1.JSON.Template;
using SmartProductionDataDefinition_V1.JSON.SensorFloatData;
using SmartProductionDataDefinition_V1.JSON.MachineFloatData;
using Amazon.S3.Model;
using System.Text;
using System.Security.Cryptography;

namespace SmartProductionDataConnector.Logic
{
    internal class SensorFloatDataLogic_V1 : AbstractDataReceiver<JSONSensorFloatDataInput_V1, JSONDataOutput_V1>
    {


        internal SensorFloatDataLogic_V1(string requestBody, ILogger log, Boolean UseDataBuffer, Boolean IsDeletedData, String blobConnection) : base (requestBody, log, UseDataBuffer, IsDeletedData, blobConnection)
        {
        }

        private long GenerateNumericId( string ProcessDataType, DateTime ProductionTime)
        {
            // Generate the first 12 digits from the Unix timestamp in milliseconds
            long javaTime = (long)(ProductionTime - new DateTime(1970, 1, 1)).TotalMilliseconds/10;

            // Generate 4-digit hash suffix from Machine and ProcessDataType
            long processTypeHash = GenerateProcessTypeHash(ProcessDataType);
             // Ensure it's a 3-digit number

            // Construct the 16-digit ID
            long id = (-1 * javaTime * 10000) - processTypeHash;

            return id; // Ensure negative value
        }

        private long GenerateProcessTypeHash(string ProcessDataType)
        {
            string input = $"{ProcessDataType}";

            // Compute multiple hash-based values
            return ComputeSHA256Hash(input) % 10000; // 4-digit from SHA256      

        }

        static long ComputeSHA256Hash(string input)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(input));
                return BitConverter.ToInt64(hashBytes, 0) & 0x7FFFFFFFFFFFFFFF; // Ensure positive
            }
        }

        internal JSONSmartKPIMachineFloatDataRow_V1 ConvertInputToSmartKPIMachineFloatData()
        {
            long javaTime = (long)(Now - new DateTime(1970, 1, 1)).TotalMilliseconds;
            DateTime measurementDateTime = new DateTime(1970, 1, 1).AddMilliseconds(JsonInput.MeassurementDateTimeJava);
            JSONSmartKPIMachineFloatDataRow_V1 jsonSmartKPIMachineFloatDataRow = new()
            {
                Machine = JsonInput.DeviceName,
                Unit = JsonInput.Unit,
                UTCCreationTime = javaTime,
                MachineData = JsonInput.MeassurementValue,
                MachineDataLSL = JsonInput.MeassurementValueLSL,
                MachineDataUSL = JsonInput.MeassurementValueUSL,
                MachineDataType = JsonInput.SensorName,
                CreationTime = javaTime,
                MachineTime = JsonInput.MeassurementDateTimeJava,
                SourceSystem = JsonInput.SourceSystem,
                description = JsonInput.Description,
                comment = JsonInput.Comment,
                Plant = JsonInput.Plant,
                Division = JsonInput.Division,
                Id = GenerateNumericId(JsonInput.SensorName, measurementDateTime)
            };

            return jsonSmartKPIMachineFloatDataRow;
        }




        internal JSONProcessSensorFloatDataToSmartKPIMachineFloatData_V1 ProcessSensorFloatDataToSmartKPIMachineFloatData()
        {
            JSONProcessSensorFloatDataToSmartKPIMachineFloatData_V1 result = new()
            {
                jsonSmartKPIMachineFloatData = new(),
                jsonSensorFloatDataOutput = new()
            };

            string filenameTarget = CreateOutputFileName("smartKPIMachineFloatData");
            result.jsonSmartKPIMachineFloatData = ConvertInputToSmartKPIMachineFloatData();

            result.jsonSensorFloatDataOutput = new JSONSensorFloatDataOutput_V1()
            {
                Result = filenameTarget,
                JSONinput = JsonInput,
                Guid = this.Guid
            };

            return result;
        }

        internal Boolean IsUnprocessableEntityObjectResult()
        {
            return IsBaseUnprocessableBaseEntityObjectResult()
                || JsonInput.DeviceName == null 
                || JsonInput.SensorName == null 
                || JsonInput.DeviceName == "" 
                || JsonInput.SensorName == "" 
                || JsonInput.MeassurementDateTimeJava <= 0;
        }

        internal JSONSensorFloatDataOutput_V1 GetOkObjectResult()
        {
            JSONSensorFloatDataOutput_V1 jsonSensorFloatDataOutput = GetBaseOkObjectResult("sensorfloatdata").JSONSensorFloatDataOutput_V1();
            jsonSensorFloatDataOutput.JSONinput = JsonInput;
            return jsonSensorFloatDataOutput;
        }


        internal JSONSensorFloatDataOutput_V1 GetUnprocessableEntityObjectResult()
        {
            JSONSensorFloatDataOutput_V1 jsonSensorFloatDataOutput = GetBaseUnprocessableEntityObjectResult().JSONSensorFloatDataOutput_V1();
            jsonSensorFloatDataOutput.JSONinput = JsonInput;
            return jsonSensorFloatDataOutput;
        }

    }
}
