﻿using System;
using System.Security.Cryptography;
using Microsoft.Extensions.Logging;
using SmartProductionDataDefinition_V1.JSON.Template;
using SmartProductionDataDefinition_V1.JSON.AdgTestBenchData;
using System.Collections.Generic;
using SmartProductionDataDefinition_V1.JSON.ProcessDateTimeData;
using SmartProductionDataDefinition_V1.JSON.ProcessFloatData;
using SmartProductionDataDefinition_V1.JSON.ProcessStringData;
using System.Reflection.Metadata;
using System.Text;

namespace SmartProductionDataConnector.Logic
{
    internal class AdgTestBenchDataLogic_V1 : AbstractDataReceiver<JSONAdgTestBenchDataInput_V1, JSONDataOutput_V1>
    {

        internal List<JSONSmartKPIProcessFloatDataRow_V1> floatData = null;
        internal List<JSONSmartKPIProcessStringDataRow_V1> stringData = null;
        internal List<JSONSmartKPIProcessDateTimeDataRow_V1> datetimeData = null;

        internal AdgTestBenchDataLogic_V1 (string requestBody, ILogger log, Boolean UseDataBuffer, Boolean IsDeletedData, String blobConnection) : base (requestBody, log, UseDataBuffer, IsDeletedData, blobConnection)
        {
        }

        private long GenerateNumericId( string ProcessDataType, DateTime ProductionTime)
        {
            // Generate the first 12 digits from the Unix timestamp in milliseconds
            long javaTime = (long)(ProductionTime - new DateTime(1970, 1, 1)).TotalMilliseconds/10;

            // Generate 4-digit hash suffix from ProcessDataType
            long processTypeHash = GenerateProcessTypeHash( ProcessDataType);            

            // Construct the 16-digit ID
            long id = (-1 * javaTime * 10000) - processTypeHash;// Ensure negative value

            return id; 
        }

        private long GenerateProcessTypeHash( string ProcessDataType)
        {
            string input = $"{ProcessDataType}";

            // Compute multiple hash-based values
            return ComputeSHA256Hash(input) % 10000; // 4-digit from SHA256      
            
        }

        static long ComputeSHA256Hash(string input)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(input));
                return BitConverter.ToInt64(hashBytes, 0) & 0x7FFFFFFFFFFFFFFF; // Ensure positive
            }
        }

        internal void ProcessAdgTestBenchDataDataToDataTypes()
        {
            floatData = new();
            stringData = new();
            datetimeData = new();

            foreach (JSONAdgTestBenchData_V1 row in JsonInput.rows)
            {
                long javaTime = (long)(Now - new DateTime(1970, 1, 1)).TotalMilliseconds;
                DateTime productionDateTime = new DateTime(1970, 1, 1).AddMilliseconds(row.ProductionDateTime);
                long numericId = GenerateNumericId(row.ProcessDataType, productionDateTime);

                if (row.isProcessDataDateTime)
                {
                    JSONSmartKPIProcessDateTimeDataRow_V1 newRow = new()
                    {
                        Machine = JsonInput.TableName,
                        SourceSystem = JsonInput.SourceSystem,
                        ProcesData = row.ProcessDataDateTime,
                        ProcesDataTargetValue = row.ProcessDataDateTimeTargetValue,
                        description = row.Description,
                        PartNumber = row.PartNumber,
                        PartNumberRevision = row.PartNumberRevision,
                        TrackingNumber = row.TrackingNumber,
                        OrderNumber = row.OrderNumber,
                        ProductionTime = row.ProductionDateTime,
                        Identifier = row.Identifier,
                        SerialNumber = row.SerialNumber,
                        ProcesDataType = row.ProcessDataType,
                        ProcesDataType2 = row.ProcessDataType2,
                        Id = numericId,
                        UTCCreationTime = javaTime,
                        CreationTime = javaTime
                    };
                    datetimeData.Add(newRow);
                } else if (row.isProcessDataString)
                {
                    JSONSmartKPIProcessStringDataRow_V1 newRow = new()
                    {
                        Machine = JsonInput.TableName,
                        SourceSystem = JsonInput.SourceSystem,
                        ProcesData = row.ProcessDataString,
                        ProcesDataTargetValue = row.ProcessDataStringTargetValue,
                        description = row.Description,
                        PartNumber = row.PartNumber,
                        PartNumberRevision = row.PartNumberRevision,
                        TrackingNumber = row.TrackingNumber,
                        OrderNumber = row.OrderNumber,
                        ProductionTime = row.ProductionDateTime,
                        Identifier = row.Identifier,
                        SerialNumber = row.SerialNumber,
                        ProcesDataType = row.ProcessDataType,
                        ProcesDataType2 = row.ProcessDataType2,
                        Id = numericId,
                        UTCCreationTime = javaTime,
                        CreationTime = javaTime
                    };
                    stringData.Add(newRow);
                } else if (row.isProcessDataFloat)
                {
                    JSONSmartKPIProcessFloatDataRow_V1 newRow = new()
                    {
                        Machine = JsonInput.TableName,
                        SourceSystem = JsonInput.SourceSystem,
                        ProcesData = row.ProcessDataFloat,
                        ProcesDataTargetValue = row.ProcessDataFloatTargetValue,
                        ProcesDataTargetValueName = row.ProcessDataTargetValueName,
                        ProcesDataLowerLimitName = row.ProcessDataLowerLimitName,
                        ProcesDataUpperLimitName = row.ProcessDataUpperLimitName,
                        ProcesDataToleranceNegFloat = row.ProcessDataToleranceNeg,
                        ProcesDataTolerancePosFloat = row.ProcessDataTolerancePos,
                        ProcesDataLSL = row.ProcessDataLSL,
                        ProcesDataUSL = row.ProcessDataUSL,
                        ProcesDataPrecision = row.ProcessDataPrecision,
                        Unit = row.Unit,
                        description = row.Description,
                        PartNumber = row.PartNumber,
                        PartNumberRevision = row.PartNumberRevision,
                        TrackingNumber = row.TrackingNumber,
                        OrderNumber = row.OrderNumber,
                        ProductionTime = row.ProductionDateTime,
                        Identifier = row.Identifier,
                        SerialNumber = row.SerialNumber,
                        ProcesDataType = row.ProcessDataType,
                        ProcesDataType2 = row.ProcessDataType2,
                        Id = numericId,
                        UTCCreationTime = javaTime,
                        CreationTime = javaTime
                    };
                    floatData.Add(newRow);
                }
            }
        }

        
        internal List<JSONSmartKPIProcessFloatDataRow_V1> GetFloatData ()
        {
            if (floatData == null) { ProcessAdgTestBenchDataDataToDataTypes(); }
            return floatData;
        }

        internal List<JSONSmartKPIProcessStringDataRow_V1> GetStringData()
        {
            if (stringData == null) { ProcessAdgTestBenchDataDataToDataTypes(); }
            return stringData;
        }

        internal List<JSONSmartKPIProcessDateTimeDataRow_V1> GetDateTimeData()
        {
            if (datetimeData == null) { ProcessAdgTestBenchDataDataToDataTypes(); }
            return datetimeData;
        }

        internal Boolean IsUnprocessableEntityObjectResult()
        {
            return IsBaseUnprocessableBaseEntityObjectResult()
                || JsonInput == null
                || JsonInput.rows == null
                || JsonInput.SourceSystem == null
                || JsonInput.StagingLevel == null
                || JsonInput.TableName == null;
        }

        internal JSONAdgTestBenchDataOutput_V1 GetOkObjectResult()
        {
            JSONAdgTestBenchDataOutput_V1 jsonAdgTestBenchDataOutput = GetBaseOkObjectResult("adgtestbenchdata").JSONAdgTestBenchDataOutput_V1();
            jsonAdgTestBenchDataOutput.JSONinput = JsonInput;
            return jsonAdgTestBenchDataOutput;
        }


        internal JSONAdgTestBenchDataOutput_V1 GetUnprocessableEntityObjectResult()
        {
            JSONAdgTestBenchDataOutput_V1 jsonAdgTestBenchDataOutput = GetBaseUnprocessableEntityObjectResult().JSONAdgTestBenchDataOutput_V1();
            jsonAdgTestBenchDataOutput.JSONinput = JsonInput;
            return jsonAdgTestBenchDataOutput;
        }


    }
}
