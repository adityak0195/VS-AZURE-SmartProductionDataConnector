﻿using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using SmartProductionDataDefinition_V1.JSON.Template;
using SmartProductionDataDefinition_V1.JSON.ThingworxUpload;
using System;

namespace SmartProductionDataConnector.Logic
{
    internal class ThingworxUploadLogic_V1 : AbstractDataReceiver<JSONThingworxUploadInput_V1, JSONDataOutput_V1>
    {

        internal ThingworxUploadLogic_V1(string requestBody, ILogger log, Boolean UseDataBuffer, Boolean IsDeletedData, String blobConnection) : base(requestBody, log, UseDataBuffer, IsDeletedData, blobConnection)
        {
        }


        internal Boolean IsUnprocessableEntityObjectResult()
        {
            return IsBaseUnprocessableBaseEntityObjectResult()
                || JsonInput == null
                || JsonInput.rows == null
                || JsonInput.SourceSystem == null
                || JsonInput.StagingLevel == null
                || JsonInput.TableName == null;
        }

        internal JSONThingworxUploadOutput_V1 GetOkObjectResult()
        {
            JSONThingworxUploadOutput_V1 jsonThingworxUploadOutput = GetBaseOkObjectResult(JsonInput.TableName, JsonConvert.SerializeObject(JsonInput.rows, Formatting.Indented)).JSONThingworxUploadOutput_V1();
            jsonThingworxUploadOutput.JSONinput = JsonInput;
            return jsonThingworxUploadOutput;
        }


        internal JSONThingworxUploadOutput_V1 GetUnprocessableEntityObjectResult()
        {
            JSONThingworxUploadOutput_V1 jsonThingworxUploadOutput = GetBaseUnprocessableEntityObjectResult().JSONThingworxUploadOutput_V1();
            jsonThingworxUploadOutput.JSONinput = JsonInput;
            return jsonThingworxUploadOutput;
        }

    }
}
