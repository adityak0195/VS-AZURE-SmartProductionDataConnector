﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using Microsoft.Extensions.Logging;
using System.IO;
using System.Threading.Tasks;
using Newtonsoft.Json;
using SmartProductionDataDefinition_V1.JSON.MachineFloatData;
using SmartProductionDataDefinition_V1.JSON.Template;

namespace SmartProductionDataConnector.Logic
{
    internal class TWX_ExportInfoTable2BlobStorage_V1
    {
        internal TWXInfotable2JSON_V1.TWXInfotableData JsonInput;
        internal DateTime Now;
        internal Guid Guid;
        internal string StagingLevel;
        internal string SourceSystem;
        internal string DataType;


        public TWX_ExportInfoTable2BlobStorage_V1(string requestBody, string host, string dataType)
        {
            Now = DateTime.UtcNow;
            this.Guid = Guid.NewGuid();
            DataType = dataType;

            if (requestBody != null)
            {
                JsonInput = JsonConvert.DeserializeObject<TWXInfotable2JSON_V1.TWXInfotableData>(requestBody);
            }
            JsonInput ??= new();

            if (host.ToLower().StartsWith("localhost") || host.ToLower().StartsWith("smartproductiondataconnectordev"))
            {
                StagingLevel = BlobStorageStagingLevel.DEV;
            }
            else if (host.ToLower().StartsWith("smartproductiondataconnectortest"))
            {
                StagingLevel = BlobStorageStagingLevel.TEST;
            }
            else if (host.ToLower().StartsWith("smartproductiondataconnectorxxx"))
            {
                StagingLevel = BlobStorageStagingLevel.PROD;
            }
            if (StagingLevel == null || !(StagingLevel.ToUpper() == BlobStorageStagingLevel.TEST || StagingLevel.ToUpper() == BlobStorageStagingLevel.PROD))
            {
                StagingLevel = BlobStorageStagingLevel.DEV;
            }

        }

        public TWXInfotable2JSON_V1.TWXInfotableData GetJsonInput()
        {
            return JsonInput;
        }

        public Boolean IsUnprocessableEntityObjectResult()
        {
            return SourceSystem == null ||
                    SourceSystem == "";
        }

        internal string CreateOutputFileName()
        {
            string filenameTarget = StagingLevel + "/";
            filenameTarget += "smartKPIMachineFloatData/";
            filenameTarget += SourceSystem + "/";
            filenameTarget += CreateFileNameWithoutPath();

            return filenameTarget;
        }

        internal string CreateFileNameWithoutPath()
        {
            return ((long)(Now - new DateTime(1970, 1, 1)).TotalMilliseconds).ToString() + "_incremental_smartKPIMachineFloatData_DirectPush_" + GlobalSettings_V1.VERSION + "_" + this.Guid.ToString() + ".json";
        }

        public JSONSmartKPIMachineFloatDataOutput_V1 GetOkObjectResult(ILogger log)
        {
            //BlobStorage_V1.WriteToCommonBlobStorage(GlobalSettings_V1.BLOB_TARGET_CONNECTION, GlobalSettings_V1.BLOB_TARGET_CONTAINER, CreateOutputFileName(), JsonInput.SmartKPIMachineFloatData, log);

            JSONSmartKPIMachineFloatDataOutput_V1 jsonOutput = new()
            {
                Result = "OK",
                Guid = this.Guid
            };
            return jsonOutput;

        }

        public JSONSmartKPIMachineFloatDataOutput_V1 GetUnprocessableEntityObjectResult()
        {
            return new JSONSmartKPIMachineFloatDataOutput_V1()
            {
                Result = "Key parameters (SourceSystem) may not be null or empty",
                Guid = this.Guid
            };
        }

        public static JSONSmartKPIMachineFloatDataOutput_V1 GetBadRequestObjectResult(string text)
        {
            return new JSONSmartKPIMachineFloatDataOutput_V1()
            {
                Result = text
            };
        }

        internal static async Task<IActionResult> ProcessData(HttpRequest req, ILogger log, string dataType)
        {
            try
            {
                log.LogInformation($"***START TWX_ExportInfoTable2BlobStorage_V1 C# at: {DateTime.Now}");
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                string requestHost = req.Host.ToString();
                log.LogInformation($"***Host: {requestHost}");

                TWX_ExportInfoTable2BlobStorage_V1 TWXExportData = new(requestBody, requestHost, dataType);

                if (TWXExportData.IsUnprocessableEntityObjectResult())
                {
                    log.LogWarning($"***END UnprocessableEntityObjectResult C# at: {DateTime.Now}");
                    return new UnprocessableEntityObjectResult(TWXExportData.GetUnprocessableEntityObjectResult());
                }
                else
                {
                    log.LogInformation($"***END OkObjectResult C# at: {DateTime.Now}");
                    return new OkObjectResult(TWXExportData.GetOkObjectResult(log));
                }
            }
            catch (Exception e)
            {
                log.LogError($"***END BadRequestObjectResult C# at: {DateTime.Now}");
                return new BadRequestObjectResult(ThingworxUploadLogic_V1.GetBaseBadRequestObjectResult("Error: " + e.Message));
            }
        }

    }
}
