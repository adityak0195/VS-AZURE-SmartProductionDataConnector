﻿using Microsoft.Extensions.Logging;

namespace SmartProductionDataConnector.Logic
{
    internal class StartHourlyDBJobLogic_V1
    {
        public static void DoProcessing(ILogger log, DataDefinitionHourlyDBJobLogic dataDefinitionHourlyDBJobLogic)
        {
            MSSQL.RunProcedureOnFilteredDBs runProcedureOnFilteredDBs = new();
            runProcedureOnFilteredDBs.RunDeleteArchivedDataOnAllDbsWithPattern(log, dataDefinitionHourlyDBJobLogic.DBPattern);
        }
    }

    public class DataDefinitionHourlyDBJobLogic
    {
        public string Environment;
        public string DBPattern;
    }
}
