﻿using Microsoft.Extensions.Logging;
using SmartProductionDataDefinition_V1.JSON.MachineFloatData;
using SmartProductionDataDefinition_V1.JSON.SensorFloatData;
using SmartProductionDataDefinition_V1.JSON.MachineStringData;
using SmartProductionDataDefinition_V1.JSON.SensorStringData;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using SmartProductionDataDefinition_V1.JSON.ProcessFloatData;
using SmartProductionDataDefinition_V1.JSON.ProcessStringData;
using SmartProductionDataDefinition_V1.JSON.ProcessDateTimeData;
using Amazon.S3.Model;
using Newtonsoft.Json;
using static log4net.Appender.RollingFileAppender;
using SmartProductionDataDefinition_V1.JSON.AdgTestBenchData;
using SmartProductionDataDefinition_V1.JSON.Template;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Threading;
using SmartProductionDataConnector.MSSQL;
using System.Runtime.CompilerServices;
using Microsoft.Identity.Client;

namespace SmartProductionDataConnector.Logic
{
    public class DataBufferObserverLogic_V1
    {
        internal static readonly string processFloatDataFolder = "processfloatdata";
        internal static readonly string processStringDataFolder = "processstringdata";
        internal static readonly string processDateTimeDataFolder = "processdatetimedata";
        internal static readonly string processAdgTestBenchDataFolder = "adgtestbenchdata";
        internal static readonly string processSensorFloatDataFolder = "sensorfloatdata";
        internal static readonly string processSensorStringDataFolder = "sensorstringdata";

        public static string GetProcessFloatDataFolder()
        {
            return processFloatDataFolder;
        }
        public static string GetProcessStringDataFolder()
        {
            return processStringDataFolder;
        }
        public static string GetProcessDateTimeDataFolder()
        {
            return processDateTimeDataFolder;
        }
        public static string GetProcessAdgTestBenchDataFolder()
        {
            return processAdgTestBenchDataFolder;
        }
        public static string GetProcessSensorFloatDataFolder()
        {
            return processSensorFloatDataFolder;
        }
        public static string GetProcessSensorStringDataFolder()
        {
            return processSensorStringDataFolder;
        }

        internal static async Task DoContainerProcessingAdgTestBenchDataAsync(string staginglevel, string container, ILogger log)
        {
            string functionname = "AdgTestBenchDataObserver_V1";
            smartKPIWriteCustomMetrics metrics = new(log);
            string datatype = processAdgTestBenchDataFolder;
            int counter = 0;
            DateTime startDate = DateTime.Now;
            log.LogInformation($"Start container {container}");
            List<string> blobs = await BlobStorage_V1.ListBlobs(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, datatype + "/",1000, log);
            metrics.WriteMetric(container, staginglevel, functionname, "Blobs read for processing", blobs.Count);
            foreach (string blob in blobs)
            {
                //log.LogInformation($"Start blob {blob}");
                try
                {
                    string content = await BlobStorage_V1.ReadBlob(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, blob, log);
                    AdgTestBenchDataLogic_V1 adgTestBenchDataLogic = new(content, log, true, false, GlobalSettings_V1.BLOB_CONNECTION_BUFFER);
                    counter++;

                    try
                    {
                        BlobStorage_V1.WriteToCommonBlobStorage(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, blob.Replace(datatype, processFloatDataFolder), adgTestBenchDataLogic.GetFloatData(), log);
                        BlobStorage_V1.WriteToCommonBlobStorage(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, blob.Replace(datatype, processStringDataFolder), adgTestBenchDataLogic.GetStringData(), log);
                        BlobStorage_V1.WriteToCommonBlobStorage(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, blob.Replace(datatype, processDateTimeDataFolder), adgTestBenchDataLogic.GetDateTimeData(), log);
                    }
                    catch (Exception e)
                    {
                        log.LogError($"E1 blob {blob}: {e.Message}");
                        BlobStorage_V1.WriteToCommonBlobStorage(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, "error/" + blob, adgTestBenchDataLogic.JsonInput, log);
                    }
                    adgTestBenchDataLogic.DeleteFromReceiverBlobStorage(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, blob);

                    TimeSpan span = DateTime.Now.Subtract(startDate);
                    if (span.TotalSeconds > 270) 
                    {
                        break;
                    }
                }
                catch (Exception e)
                {
                    log.LogError($"E2: {e.Message}");
                }
            }
            metrics.WriteMetric(container, staginglevel, functionname, "Blobs processed", counter);
        }


        public static async Task DoProcessingAdgTestBenchDataAsync(string staginglevel, ILogger log)
        {
            try
            {

                List<string> containers = await BlobStorage_V1.ListContainers(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, log);

                foreach (string container in containers)
                {
                    if (container.StartsWith("buffer-" + staginglevel.ToLower() + "-"))
                    {
                        new Thread(async () => await DoContainerProcessingAdgTestBenchDataAsync(staginglevel, container, log))
                        {
                            Name = "DoContainerProcessingAdgTestBenchDataAsync_" + container,
                            IsBackground = true
                        }.Start();
                    }
                }
            }
            catch (Exception e)
            {
                log.LogError($"E3: {e.Message}");
            }
        }

        internal static async Task DoProcessingFloatDataAsync(string staginglevel, ILogger log)
        {
            string functionname = "SensorFloatDataObserver_V1";
            smartKPIWriteCustomMetrics metrics = new(log);
            DateTime startDate = DateTime.Now;
            string datatype = processSensorFloatDataFolder;
            try
            {

                List<string> containers = await BlobStorage_V1.ListContainers(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, log);
                int counter = 0;

                foreach (string container in containers)
                {
                    if (container.StartsWith("buffer-" + staginglevel.ToLower() + "-"))
                    {
                        string filenameTarget = null;
                        log.LogInformation($"Start container {container}");
                        List<string> blobs = await BlobStorage_V1.ListBlobs(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, datatype + "/", 10000, log);
                        List<JSONSmartKPIMachineFloatDataRow_V1> jsonData = new();
                        foreach (string blob in blobs)
                        {
                            //log.LogInformation($"Start blob {blob}");
                            try
                            {
                                string content = await BlobStorage_V1.ReadBlob(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, blob, log);
                                SensorFloatDataLogic_V1 sensorFloatDataLogic = new(content, log, true, false, GlobalSettings_V1.BLOB_CONNECTION_BUFFER);

                                try
                                {
                                    JSONProcessSensorFloatDataToSmartKPIMachineFloatData_V1 fullData = sensorFloatDataLogic.ProcessSensorFloatDataToSmartKPIMachineFloatData();
                                    jsonData.Add(fullData.jsonSmartKPIMachineFloatData);
                                    counter++;
                                    filenameTarget = fullData.jsonSensorFloatDataOutput.Result;
                                }
                                catch (Exception e)
                                {
                                    log.LogError($"E1 blob {blob}: {e.Message}");
                                    BlobStorage_V1.WriteToCommonBlobStorage(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, "error/" + blob, sensorFloatDataLogic.JsonInput, log);
                                }
                                sensorFloatDataLogic.DeleteFromReceiverBlobStorage(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, blob);
                                //TimeSpan span = DateTime.Now.Subtract(startDate);
                                //if (span.TotalSeconds > 270)
                                //{
                                //    break;
                                //}
                            }
                            catch (Exception e)
                            {
                                log.LogError($"E2: {e.Message}");
                            }
                        }
                        if (filenameTarget != null)
                        {
                            BlobStorage_V1.WriteToCommonBlobStorage(GlobalSettings_V1.BLOB_CONNECTION_FINAL, GlobalSettings_V1.BLOB_CONTAINER, filenameTarget, jsonData, log);
                            log.LogInformation($"filenameTarget {filenameTarget}");
                            metrics.WriteMetric(container, staginglevel, functionname, "Blobs processed", blobs.Count);
                            metrics.WriteMetric(container, staginglevel, functionname, "Datasets processed", counter);
                        }
                        counter = 0;
                    }
                }
            }
            catch (Exception e)
            {
                log.LogError($"E3: {e.Message}");
            }
        }

        internal static async Task DoProcessingStringDataAsync(string staginglevel, ILogger log)
        {
            string functionname = "SensorStringDataObserver_V1";
            smartKPIWriteCustomMetrics metrics = new(log);
            DateTime startDate = DateTime.Now;
            string datatype = processSensorStringDataFolder;
            try
            {

                List<string> containers = await BlobStorage_V1.ListContainers(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, log);
                int counter = 0;

                foreach (string container in containers)
                {
                    if (container.StartsWith("buffer-" + staginglevel.ToLower() + "-"))
                    {
                        string filenameTarget = null;
                        log.LogInformation($"Start container {container}");
                        List<string> blobs = await BlobStorage_V1.ListBlobs(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, datatype + "/", 10000, log);
                        List<JSONSmartKPIMachineStringDataRow_V1> jsonData = new();
                        foreach (string blob in blobs)
                        {
                            //log.LogInformation($"Start blob {blob}");
                            try
                            {
                                string content = await BlobStorage_V1.ReadBlob(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, blob, log);
                                SensorStringDataLogic_V1 sensorStringDataLogic = new(content, log, true, false, GlobalSettings_V1.BLOB_CONNECTION_BUFFER);

                                try
                                {
                                    JSONProcessSensorStringDataToSmartKPIMachineStringData_V1 fullData = sensorStringDataLogic.ProcessSensorStringDataToSmartKPIMachineStringData();
                                    jsonData.Add(fullData.jsonSmartKPIMachineStringData);
                                    counter++;
                                    filenameTarget = fullData.jsonSensorStringDataOutput.Result;
                                }
                                catch (Exception e)
                                {
                                    log.LogError($"E1 blob {blob}: {e.Message}");
                                    BlobStorage_V1.WriteToCommonBlobStorage(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, "error/" + blob, sensorStringDataLogic.JsonInput, log);
                                }
                                sensorStringDataLogic.DeleteFromReceiverBlobStorage(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, blob);
                                //TimeSpan span = DateTime.Now.Subtract(startDate);
                                //if (span.TotalSeconds > 270)
                                //{
                                //    break;
                                //}
                            }
                            catch (Exception e)
                            {
                                log.LogError($"E2: {e.Message}");
                            }
                        }
                        if (filenameTarget != null)
                        {
                            BlobStorage_V1.WriteToCommonBlobStorage(GlobalSettings_V1.BLOB_CONNECTION_FINAL, GlobalSettings_V1.BLOB_CONTAINER, filenameTarget, jsonData, log);
                            log.LogInformation($"filenameTarget {filenameTarget}");
                            metrics.WriteMetric(container, staginglevel, functionname, "Blobs processed", blobs.Count);
                            metrics.WriteMetric(container, staginglevel, functionname, "Datasets processed", counter);
                        }
                        counter = 0;
                    }
                }
            }
            catch (Exception e)
            {
                log.LogError($"E3: {e.Message}");
            }
        }


        internal static async Task DoProcessingAdgTestBenchDataFloatAsync(string staginglevel, ILogger log)
        {
            string functionname = "AdgTestBenchDataFloatObserver_V1";
            smartKPIWriteCustomMetrics metrics = new(log);
            DateTime startDate = DateTime.Now;
            string datatype = processFloatDataFolder;
            try
            {

                List<string> containers = await BlobStorage_V1.ListContainers(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, log);
                int counter = 0;

                foreach (string container in containers)
                {
                    if (container.StartsWith("buffer-" + staginglevel.ToLower() + "-"))
                    {
                        string filenameTarget = null;
                        log.LogInformation($"Start container {container}");
                        List<string> blobs = await BlobStorage_V1.ListBlobs(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, datatype + "/", 10000, log);
                        List<JSONSmartKPIProcessFloatDataRow_V1> jsonData = new();
                        foreach (string blob in blobs)
                        {
                            //log.LogInformation($"Start blob {blob}");
                            try
                            {
                                filenameTarget = null;
                                string content = await BlobStorage_V1.ReadBlob(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, blob, log);
                                List<JSONSmartKPIProcessFloatDataRow_V1> jsonBuffer = JsonConvert.DeserializeObject<List<JSONSmartKPIProcessFloatDataRow_V1>>(content);
                                try
                                {

                                    foreach (JSONSmartKPIProcessFloatDataRow_V1 row in jsonBuffer)
                                    {
                                        filenameTarget ??= AbstractDataReceiver<JSONAdgTestBenchDataInput_V1, JSONDataOutput_V1>.CreateOutputFileName(staginglevel, row.SourceSystem, DateTime.UtcNow, "smartKPIProcessFloatData", false, true, Guid.NewGuid());
                                        jsonData.Add(row);
                                        counter++;
                                    }
                                }
                                catch (Exception e)
                                {
                                    log.LogError($"E1 blob {blob}: {e.Message}");
                                    BlobStorage_V1.WriteToCommonBlobStorage(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, "error/" + blob, jsonBuffer, log);
                                }
                                BlobStorage_V1.DeleteFromReceiverBlobStorage(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, blob, log);
                                //TimeSpan span = DateTime.Now.Subtract(startDate);
                                //if (span.TotalSeconds > 270)
                                //{
                                //    break;
                                //}
                            }
                            catch (Exception e)
                            {
                                log.LogError($"E2: {e.Message}");
                            }
                        }
                        if (filenameTarget != null)
                        {
                            BlobStorage_V1.WriteToCommonBlobStorage(GlobalSettings_V1.BLOB_CONNECTION_FINAL, GlobalSettings_V1.BLOB_CONTAINER, filenameTarget, jsonData, log);
                            log.LogInformation($"filenameTarget {filenameTarget}");
                            metrics.WriteMetric(container, staginglevel, functionname, "Blobs processed", blobs.Count);
                            metrics.WriteMetric(container, staginglevel, functionname, "Datasets processed", counter);
                        }
                        counter = 0;
                    }
                }
            }
            catch (Exception e)
            {
                log.LogError($"E3: {e.Message}");
            }
        }

        internal static async Task DoProcessingAdgTestBenchDataStringAsync(string staginglevel, ILogger log)
        {
            string functionname = "AdgTestBenchDataStringObserver_V1";
            smartKPIWriteCustomMetrics metrics = new(log);
            DateTime startDate = DateTime.Now;
            string datatype = processStringDataFolder;
            try
            {

                List<string> containers = await BlobStorage_V1.ListContainers(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, log);
                int counter = 0;

                foreach (string container in containers)
                {
                    if (container.StartsWith("buffer-" + staginglevel.ToLower() + "-"))
                    {
                        string filenameTarget = null;
                        log.LogInformation($"Start container {container}");
                        List<string> blobs = await BlobStorage_V1.ListBlobs(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, datatype + "/", 10000, log);
                        List<JSONSmartKPIProcessStringDataRow_V1> jsonData = new();
                        foreach (string blob in blobs)
                        {
                            //log.LogInformation($"Start blob {blob}");
                            try
                            {
                                filenameTarget = null;
                                string content = await BlobStorage_V1.ReadBlob(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, blob, log);
                                List<JSONSmartKPIProcessStringDataRow_V1> jsonBuffer = JsonConvert.DeserializeObject<List<JSONSmartKPIProcessStringDataRow_V1>>(content);
                                try
                                {

                                    foreach (JSONSmartKPIProcessStringDataRow_V1 row in jsonBuffer)
                                    {
                                        filenameTarget ??= AbstractDataReceiver<JSONAdgTestBenchDataInput_V1, JSONDataOutput_V1>.CreateOutputFileName(staginglevel, row.SourceSystem, DateTime.UtcNow, "smartKPIProcessStringData", false, true, Guid.NewGuid());
                                        jsonData.Add(row);
                                        counter++;
                                    }
                                }
                                catch (Exception e)
                                {
                                    log.LogError($"E1 blob {blob}: {e.Message}");
                                    BlobStorage_V1.WriteToCommonBlobStorage(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, "error/" + blob, jsonBuffer, log);
                                }
                                BlobStorage_V1.DeleteFromReceiverBlobStorage(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, blob, log);
                                //TimeSpan span = DateTime.Now.Subtract(startDate);
                                //if (span.TotalSeconds > 270)
                                //{
                                //    break;
                                //}
                            }
                            catch (Exception e)
                            {
                                log.LogError($"E2: {e.Message}");
                            }
                        }
                        if (filenameTarget != null)
                        {
                            BlobStorage_V1.WriteToCommonBlobStorage(GlobalSettings_V1.BLOB_CONNECTION_FINAL, GlobalSettings_V1.BLOB_CONTAINER, filenameTarget, jsonData, log);
                            log.LogInformation($"filenameTarget {filenameTarget}");
                            metrics.WriteMetric(container, staginglevel, functionname, "Blobs processed", blobs.Count);
                            metrics.WriteMetric(container, staginglevel, functionname, "Datasets processed", counter);
                        }
                        counter = 0;
                    }
                }
            }
            catch (Exception e)
            {
                log.LogError($"E3: {e.Message}");
            }
        }

        internal static async Task DoProcessingAdgTestBenchDataDateTimeAsync(string staginglevel, ILogger log)
        {
            string functionname = "AdgTestBenchDataDateTimeObserver_V1";
            smartKPIWriteCustomMetrics metrics = new(log);
            DateTime startDate = DateTime.Now;
            string datatype = processDateTimeDataFolder;
            try
            {
                List<string> containers = await BlobStorage_V1.ListContainers(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, log);
                int counter = 0;

                foreach (string container in containers)
                {
                    if (container.StartsWith("buffer-" + staginglevel.ToLower() + "-"))
                    {
                        string filenameTarget = null;
                        log.LogInformation($"Start container {container}");
                        List<string> blobs = await BlobStorage_V1.ListBlobs(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, datatype + "/", 10000, log);
                        List<JSONSmartKPIProcessDateTimeDataRow_V1> jsonData = new();
                        foreach (string blob in blobs)
                        {
                            //log.LogInformation($"Start blob {blob}");
                            try
                            {
                                filenameTarget = null;
                                string content = await BlobStorage_V1.ReadBlob(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, blob, log);
                                List<JSONSmartKPIProcessDateTimeDataRow_V1> jsonBuffer = JsonConvert.DeserializeObject<List<JSONSmartKPIProcessDateTimeDataRow_V1>>(content);
                                try
                                {

                                    foreach (JSONSmartKPIProcessDateTimeDataRow_V1 row in jsonBuffer)
                                    {
                                        filenameTarget ??= AbstractDataReceiver<JSONAdgTestBenchDataInput_V1, JSONDataOutput_V1>.CreateOutputFileName(staginglevel, row.SourceSystem, DateTime.UtcNow, "smartKPIProcessDateTimeData", false, true, Guid.NewGuid());
                                        jsonData.Add(row);
                                        counter++;
                                    }
                                }
                                catch (Exception e)
                                {
                                    log.LogError($"E1 blob {blob}: {e.Message}");
                                    BlobStorage_V1.WriteToCommonBlobStorage(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, "error/" + blob, jsonBuffer, log);
                                }
                                BlobStorage_V1.DeleteFromReceiverBlobStorage(GlobalSettings_V1.BLOB_CONNECTION_BUFFER, container, blob, log);
                                //TimeSpan span = DateTime.Now.Subtract(startDate);
                                //if (span.TotalSeconds > 270)
                                //{
                                //    break;
                                //}
                            }
                            catch (Exception e)
                            {
                                log.LogError($"E2: {e.Message}");
                            }
                        }
                        if (filenameTarget != null)
                        {
                            BlobStorage_V1.WriteToCommonBlobStorage(GlobalSettings_V1.BLOB_CONNECTION_FINAL, GlobalSettings_V1.BLOB_CONTAINER, filenameTarget, jsonData, log);
                            log.LogInformation($"filenameTarget {filenameTarget}");
                            metrics.WriteMetric(container, staginglevel, functionname, "Blobs processed", blobs.Count);
                            metrics.WriteMetric(container, staginglevel, functionname, "Datasets processed", counter);
                        }
                        counter = 0;
                    }
                }
            }
            catch (Exception e)
            {
                log.LogError($"E3: {e.Message}");
            }
        }
    }
}
