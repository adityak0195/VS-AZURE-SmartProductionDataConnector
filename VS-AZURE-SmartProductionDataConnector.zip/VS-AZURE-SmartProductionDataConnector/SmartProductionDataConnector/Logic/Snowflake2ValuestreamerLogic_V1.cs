﻿using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Net.Http;
using System;
using System.Text;
using Newtonsoft.Json;

namespace SmartProductionDataConnector.Logic
{
    public class Snowflake2ValuestreamerLogic_V1
    {
        private const string URL = "https://api-knorr-bremse.valuestreamer.de/api/exchange/";
        private const string ValuestreamerCredentials = "BA-66-A7-35-CF-C8-2F-B9-7C-0F-49-9D-FE-39-B1-DE-D1-B7-8B-D1-21-3A-AE-8D-2D-81-C8-2B-21-56-FF-4C-38-6A-51-4B-1F-4C-1B-C6-AA-62-95-35-6C-F7-76-18";

        public static void DoProcessing(ILogger log, DataDefinitionTwx2ValueStreamer dataDefinitionTwx2ValueStreamer)
        {
            try
            {
                using Snowflake.KpiData4Valuestreamer_V1 sfDataDB = new(log, dataDefinitionTwx2ValueStreamer.Key);
                using MSSQL.SmartKPIKepwareConnectorPointer pointerDB = new(log, dataDefinitionTwx2ValueStreamer.PointerDB);
                List<ValueStreamerKPI> valueStreamerKPIs = GetKPIs(log, dataDefinitionTwx2ValueStreamer);
                foreach (ValueStreamerKPI kpi in valueStreamerKPIs)
                {
                    foreach (DataDefinitionTwx2ValueStreamerKpi kpiDefinition in dataDefinitionTwx2ValueStreamer.kpiNames)
                    {
                        if (kpiDefinition.vsKpiName == kpi.name)
                        {
                            log.LogInformation("Fetching Details for " + kpi.name + " (" + kpi.id + ")");
                            string vsKpiId = kpi.id;
                            string vsKpiValueId = "";
                            ValueStreamerKPIDetails valueStreamerKpiDetails = GetKPIDetails(log, kpi.id, dataDefinitionTwx2ValueStreamer);
                            Boolean isKpiValueInteger = valueStreamerKpiDetails.kpiValueIsInteger;
                            foreach (ValueStreamerKPIDetailsKpiValue valueStreamerKPIDetailsKpiValue in valueStreamerKpiDetails.kpiValues)
                            {
                                foreach (DataDefinitionTwx2ValueStreamerKpi kpiDefinition1 in dataDefinitionTwx2ValueStreamer.kpiNames)
                                {
                                    if (kpiDefinition1.vsKpiValueName == valueStreamerKPIDetailsKpiValue.name)
                                    {
                                        vsKpiValueId = valueStreamerKPIDetailsKpiValue.id;
                                        log.LogInformation("Setting Values for " + valueStreamerKPIDetailsKpiValue.name + " (" + valueStreamerKPIDetailsKpiValue.id + ")");
                                    }
                                }
                            }
                            foreach (ValueStreamerKPIDetailsTeam valueStreamerKPIDetailsTeam in valueStreamerKpiDetails.recordingTeams)
                            {
                                string vsKpiMachineId = "";
                                foreach (DataDefinitionTwx2ValueStreamerMachine machineDefinition in dataDefinitionTwx2ValueStreamer.machineNames)
                                {
                                    if (machineDefinition.vsMachineName == valueStreamerKPIDetailsTeam.name)
                                    {
                                        string pointerName = "SF2ValuestreamerV1-" + machineDefinition.twxMachineName + "-" + kpiDefinition.twxKpiName;
                                        vsKpiMachineId = valueStreamerKPIDetailsTeam.id;
                                        log.LogInformation("Setting Values for " + valueStreamerKPIDetailsTeam.name + " (" + valueStreamerKPIDetailsTeam.id + ")");
                                        long pointer = pointerDB.GetPointer(pointerName);
                                        List<Snowflake.OeeData> oeeDatas;
                                        oeeDatas = sfDataDB.GetData(dataDefinitionTwx2ValueStreamer.SourceSystem, machineDefinition.twxMachineName, kpiDefinition.twxKpiName, pointer.ToString());
                                        int counter = 0;
                                        foreach (Snowflake.OeeData oeeData in oeeDatas)
                                        {
                                            string json;
                                            if (isKpiValueInteger)
                                            {
                                                ValueStreamerSetIntKPIs valueStreamerSetKPIs = new();
                                                valueStreamerSetKPIs.values.Add(new ValueStreamerSetIntKPI() { kpiValueId = vsKpiValueId, value = (int)oeeData.kpiValue });
                                                json = JsonConvert.SerializeObject(valueStreamerSetKPIs);
                                            }
                                            else
                                            {
                                                ValueStreamerSetFloatKPIs valueStreamerSetKPIs = new();
                                                valueStreamerSetKPIs.values.Add(new ValueStreamerSetFloatKPI() { kpiValueId = vsKpiValueId, value = oeeData.kpiValue });
                                                json = JsonConvert.SerializeObject(valueStreamerSetKPIs);
                                            }


                                            StringContent stringContent = new(json, Encoding.UTF8, "application/vs.v2.0+json");
                                            ValueStreamerSetKPIRespose response = SetKPIs(log, dataDefinitionTwx2ValueStreamer, stringContent, oeeData.kpiDate, vsKpiMachineId, vsKpiId);
                                            if (response.httpResponseMessage.IsSuccessStatusCode)
                                            {
                                                pointerDB.SetPointer(pointerName, oeeData.Id);
                                                counter++;
                                            }
                                        }
                                        log.LogInformation("Processed Data Rows: " + counter.ToString()); ;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception e)  
            {
                log.LogError("Error in DoProcessing: " + e.Message);
            }
        }

        private static List<ValueStreamerKPI> GetKPIs(ILogger log, DataDefinitionTwx2ValueStreamer dataDefinitionTwx2ValueStreamer)
        {
            List<ValueStreamerKPI> valueStreamerKPIs = new();

            using (HttpClient client = new())
            {
                var byteArray = Encoding.ASCII.GetBytes(Security_V1.DecryptString(ValuestreamerCredentials, dataDefinitionTwx2ValueStreamer.Key));
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

                HttpResponseMessage response = client.GetAsync(URL + "kpi").Result;

               if (response.IsSuccessStatusCode)
               {
                   valueStreamerKPIs = JsonConvert.DeserializeObject<List<ValueStreamerKPI>>(response.Content.ReadAsStringAsync().Result);
               }
               else
               {
                    log.LogError("Snowflake2ValuestreamerLogic_V1.GetKPIs: {0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
               }
            }

            return valueStreamerKPIs;
        }

        private static ValueStreamerSetKPIRespose SetKPIs(ILogger log, DataDefinitionTwx2ValueStreamer dataDefinitionTwx2ValueStreamer, StringContent stringContent, string date, string teamid, string kpiid)
        {
            ValueStreamerSetKPIRespose valueStreamerSetKPIRespose = new();

            using (HttpClient client = new())
            {
                var byteArray = Encoding.ASCII.GetBytes(Security_V1.DecryptString(ValuestreamerCredentials, dataDefinitionTwx2ValueStreamer.Key));
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/vs.v2.0+json"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

                HttpResponseMessage response = client.PutAsync(URL + "kpi-data/"+date+"/"+teamid+"/"+kpiid, stringContent).Result;

                if (response.IsSuccessStatusCode)
                {
                    valueStreamerSetKPIRespose = JsonConvert.DeserializeObject<ValueStreamerSetKPIRespose>(response.Content.ReadAsStringAsync().Result);
                }
                else
                {
                    log.LogError("Snowflake2ValuestreamerLogic_V1.SetKPIs: {0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
                }
                valueStreamerSetKPIRespose.httpResponseMessage = response;
            }

            return valueStreamerSetKPIRespose;
        }

        private static ValueStreamerKPIDetails GetKPIDetails(ILogger log, string ident, DataDefinitionTwx2ValueStreamer dataDefinitionTwx2ValueStreamer)
        {
            ValueStreamerKPIDetails valueStreamerKpiDetails = new();

            using (HttpClient client = new())
            {
                var byteArray = Encoding.ASCII.GetBytes(Security_V1.DecryptString(ValuestreamerCredentials, dataDefinitionTwx2ValueStreamer.Key));
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

                HttpResponseMessage response = client.GetAsync(URL + "kpi/" + ident).Result;

                if (response.IsSuccessStatusCode)
                {
                    valueStreamerKpiDetails = JsonConvert.DeserializeObject<ValueStreamerKPIDetails>(response.Content.ReadAsStringAsync().Result);
                }
                else
                {
                    log.LogError("Snowflake2ValuestreamerLogic_V1.GetKPIDetails: {0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
                }
            }

            return valueStreamerKpiDetails;
        }
    }

#pragma warning disable CS0649
    public class ValueStreamerKPI
    {
        public string id;
        public string name;
    }
    public class ValueStreamerKPIDetailsKpiValue
    {
        public string id;
        public string name;
        public int orderId;
    }

    public class ValueStreamerSetKPIRespose
    {
        public ValueStreamerSetKPIResposeMeta meta;
        public List<ValueStreamerSetFloatKPI> values = new();
        public HttpResponseMessage httpResponseMessage;
    }

    public class ValueStreamerSetKPIResposeMeta
    {
        public string kpiId;
        public string teamId;
        public string subTileId;
        public string date;
    }

    public class ValueStreamerSetIntKPI
    {
        public string kpiValueId;
        public int value;
    }
    public class ValueStreamerSetIntKPIs
    {
        public List<ValueStreamerSetIntKPI> values = new();
    }

    public class ValueStreamerSetFloatKPI
    {
        public string kpiValueId;
        public float value;
    }
    public class ValueStreamerSetFloatKPIs
    {
        public List<ValueStreamerSetFloatKPI> values = new();
    }

    public class ValueStreamerKPIDetailsTeam
    {
        public string id;
        public string name;
        public Boolean subTileRecording;
    }

    public class ValueStreamerKPIDetails
    {
        public string id;
        public string name;
        public Boolean kpiValueIsInteger;
        public string kpiValueTimeReference;
        public string targetValueType;
        public string targetValueScope;
        public List<ValueStreamerKPIDetailsKpiValue> kpiValues = new();
        public List<ValueStreamerKPIDetailsTeam> recordingTeams = new();
    }

    public class DataDefinitionTwx2ValueStreamerKpi
    {
        public string twxKpiName;
        public string vsKpiName;
        public string vsKpiValueName;
    }
    public class DataDefinitionTwx2ValueStreamerMachine
    {
        public string twxMachineName;
        public string vsMachineName;
    }


    public class DataDefinitionTwx2ValueStreamer
    {
        public string Key;
        public string Environment;
        public string PointerDB;
        public string Plant;
        public string SourceSystem;
        public List<DataDefinitionTwx2ValueStreamerMachine> machineNames = new();
        public List<DataDefinitionTwx2ValueStreamerKpi> kpiNames = new();
    }
#pragma warning restore CS0649
}
