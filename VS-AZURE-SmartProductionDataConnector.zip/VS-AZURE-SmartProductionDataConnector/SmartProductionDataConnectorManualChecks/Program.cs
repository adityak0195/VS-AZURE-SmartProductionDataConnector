﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.WindowsAzure.Storage.Auth;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartProductionDataConnectorManualChecks
{
    internal class Program
    {
        static void Main(string[] args)
        {
            getFilesWithId("PROD", "smartKPIValues", "smartproductionBUD.corp.knorr-bremse.com", "1003861559");
        }


        static void getFilesWithId(string stagingLevel, string tablename, string location, string id)
        {
            string storageAccountName = "idlthingworxhot";
            string containerName = "smartproduction";
            string sasToken = "?sv=2021-06-08&ss=b&srt=sco&sp=rl&se=2032-11-30T19:29:01Z&st=2022-11-30T11:29:01Z&spr=https&sig=lmiSlF4p6VeQGgU6%2FzE%2FP2Tb7sKLE8WMGxQz1grhqT0%3D";

            string dir = stagingLevel + "/" + tablename;

            StorageCredentials creds;
            CloudBlobContainer cloudBlobContainer;
            creds = new StorageCredentials(sasToken);

            cloudBlobContainer = new CloudBlobContainer(new Uri("https://" + storageAccountName + ".blob.core.windows.net/" + containerName), creds);
            //var blobs = cloudBlobContainer.ListBlobs(prefix: dir, useFlatBlobListing: true);

            var blobs = cloudBlobContainer
                .GetDirectoryReference(stagingLevel)
                .GetDirectoryReference(tablename)
                .GetDirectoryReference(location)
                .ListBlobs(useFlatBlobListing: true).OfType<CloudBlockBlob>().ToList();
            Console.WriteLine("Total files found in directory: " + blobs.Count.ToString());

            foreach (var blob in blobs)
            {
                var response = blob.DownloadTextAsync().GetAwaiter().GetResult();
                if (response.IndexOf("\"Id\":" + id + ",") > 0 || response.IndexOf("\"Id\":" + id + "}") > 0)
                {
                    Console.WriteLine("*****************************");
                    Console.WriteLine(blob.Name);
                }
            }

            Console.WriteLine("*****************************");
            Console.WriteLine("Done");



            Console.ReadKey();
        }
    }
}
