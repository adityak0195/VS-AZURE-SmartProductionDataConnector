﻿using log4net;
using Microsoft.Extensions.Logging;
using SmartProductionDataConnector.Logic;


// See https://aka.ms/new-console-template for more information
Console.WriteLine("Start ADGTestBenchDataObserver!");

using ILoggerFactory loggerFactory =
    LoggerFactory.Create(builder =>
        builder.AddConsole());

ILogger log = loggerFactory.CreateLogger("test");

await DataBufferObserverLogic_V1.DoProcessingAdgTestBenchDataAsync(BlobStorageStagingLevel.DEV, log);

Console.ReadLine();

