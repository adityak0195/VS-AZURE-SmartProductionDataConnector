﻿using Microsoft.Extensions.Logging;
using Microsoft.WindowsAzure.Storage;
using Newtonsoft.Json;
using SmartProductionDataConnector.Logic;
using SmartProductionDataDefinition_V1.JSON.ThingworxUpload;
using System.Text;
using Newtonsoft.Json.Linq;
using Microsoft.AspNetCore.Mvc;

namespace SmartProductionDataConnectorFunctionalTest
{
    [TestClass]
    public class TestThingworxUpload_V1
    {
        internal static string SourceSystem = "FUNCTIONALTEST_V1";
        internal static string Machine = "testmachine";
        internal static string TableName = "smartKPIMachineFloatData";


        /************************************************************************************************
         * 
         * This test uploads data via the ThingworxUpload_V1 function to the 
         * final BlobStorage --> GlobalSettings_V1.BLOB_CONTAINER 
         * an checks if content is in BlobStorage
         * 
         * Same for data with DELETE IDENTIFIER
         * 
         ************************************************************************************************/





        public async Task DoThingworxUploadTests(string StagingLevel, Uri url_ThingworxUpload_V1, Uri url_ThingworxDeletedUpload_V1, string connectionstring)
        {
            


            long time = Convert.ToInt64((DateTime.Now - new DateTime(1970, 1, 1)).TotalMilliseconds);
            string timestamp = time.ToString();
            JSONThingworxUploadInput_V1 testData = new()
            {
                SourceSystem = SourceSystem,
                StagingLevel = StagingLevel,
                TableName = TableName
            };
            string datarow = 
            "[{"
            + "    \"Machine\": \""+Machine+"\","
            + "    \"MachineTime\": "+time+""
            + "}]";
            testData.rows= JsonConvert.DeserializeObject<JToken>(datarow);

            string body = JsonConvert.SerializeObject(testData, Formatting.Indented);


            Console.WriteLine(DateTime.Now.ToString()+": "+"SourceSystem = " + SourceSystem);
            Console.WriteLine(DateTime.Now.ToString()+": "+"StagingLevel = " + StagingLevel);
            Console.WriteLine(DateTime.Now.ToString()+": "+"Machine = " + Machine);
            Console.WriteLine(DateTime.Now.ToString()+": "+"TableName = " + TableName);
            Console.WriteLine(DateTime.Now.ToString()+": "+"timestamp = " + timestamp);
            Console.WriteLine(DateTime.Now.ToString()+": "+"body = " + body);

            await ThingworxDataHTTPCallWithoutError(body, url_ThingworxUpload_V1);
            await DoesThingworxDataBlobFileExists(timestamp, StagingLevel, connectionstring);

            await ThingworxDeletedDataHTTPCallWithoutError(body, url_ThingworxDeletedUpload_V1);
            await DoesThingworxDeletedDataBlobFileExists(timestamp, StagingLevel, connectionstring);
        }

        private static async Task ThingworxDataHTTPCallWithoutError(string body, Uri url)
        {
            Console.WriteLine(DateTime.Now.ToString()+": "+"ThingworxDataHTTPCallWithoutError");
            HttpContent httpContent = new StringContent(body, Encoding.UTF8, "application/json");
            string Result = await Task.Run(() => PostURI(url, httpContent));
            Console.WriteLine(DateTime.Now.ToString()+": "+"--> " + Result);
            Assert.AreEqual("OK", Result);
        }

        private static async Task DoesThingworxDataBlobFileExists(string timestamp, string StagingLevel, string connectionstring)
        {
            Console.WriteLine(DateTime.Now.ToString()+": "+"DoesThingworxDataBlobFileExists");
            Console.WriteLine(DateTime.Now.ToString()+": "+"Wait 5 Seconds");
            await Task.Delay(5000);
            Console.WriteLine(DateTime.Now.ToString()+": "+"Countinue...");
            using ILoggerFactory loggerFactory =
                LoggerFactory.Create(builder =>
                    builder.AddConsole());

            ILogger log = loggerFactory.CreateLogger("test");

            int counter = 0;
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(connectionstring);

            List<string> containers = await BlobStorage_V1.ListContainers(storageAccount, log);
            Console.WriteLine(DateTime.Now.ToString()+": "+"Found " + containers.Count + " containers");

            foreach (string container in containers)
            {
                Console.WriteLine(DateTime.Now.ToString()+": "+$"Container {container}");
                if (container == GlobalSettings_V1.BLOB_CONTAINER)
                {
                    Console.WriteLine(DateTime.Now.ToString()+": "+$"Checking container {container}");
                    string dir = StagingLevel + "/FUNCTIONALTEST/"+TableName+"/"+ DateTime.Now.Year+"/"+ DateTime.Now.Month+"/"+ DateTime.Now.Day+"/"+ SourceSystem+"/";
                    List<string> blobs = await BlobStorage_V1.ListBlobs(storageAccount, container, dir, log);
                    foreach (string blob in blobs)
                    {
                        string content = await BlobStorage_V1.ReadBlob(connectionstring, container, blob, log);
                        Console.WriteLine(DateTime.Now.ToString()+": "+$"Check blob {blob}");
                        if (blob.EndsWith("_incremental_"+TableName+".json") && content.Contains("\"MachineTime\": " + timestamp) && content.Contains("\"Machine\": \"" + Machine + "\"") && content.StartsWith("["))
                        {
                            Console.WriteLine(DateTime.Now.ToString()+": "+"OK, blob found");
                            counter++;
                            break;
                        }
                    }
                }
            }
            Assert.AreEqual(1, counter);
        }




        private static async Task ThingworxDeletedDataHTTPCallWithoutError(string body, Uri url)
        {
            Console.WriteLine(DateTime.Now.ToString()+": "+"ThingworxDeletedDataHTTPCallWithoutError");
            HttpContent httpContent = new StringContent(body, Encoding.UTF8, "application/json");
            string Result = await Task.Run(() => PostURI(url, httpContent));
            Console.WriteLine(DateTime.Now.ToString()+": "+"--> " + Result);
            Assert.AreEqual("OK", Result);
        }

        private static async Task DoesThingworxDeletedDataBlobFileExists(string timestamp, string StagingLevel, string connectionstring)
        {
            Console.WriteLine(DateTime.Now.ToString()+": "+"DoesThingworxDeletedDataBlobFileExists");
            Console.WriteLine(DateTime.Now.ToString()+": "+"Wait 5 Seconds");
            await Task.Delay(5000);
            Console.WriteLine(DateTime.Now.ToString()+": "+"Countinue...");
            using ILoggerFactory loggerFactory =
                LoggerFactory.Create(builder =>
                    builder.AddConsole());

            ILogger log = loggerFactory.CreateLogger("test");

            int counter = 0;
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(connectionstring);

            List<string> containers = await BlobStorage_V1.ListContainers(storageAccount, log);
            Console.WriteLine(DateTime.Now.ToString()+": "+"Found " + containers.Count + " containers");

            foreach (string container in containers)
            {
                if (container == GlobalSettings_V1.BLOB_CONTAINER)
                {
                    Console.WriteLine(DateTime.Now.ToString()+": "+$"Checking container {container}");
                    string dir = StagingLevel + "/FUNCTIONALTEST/" + TableName + "/" + DateTime.Now.Year + "/" + DateTime.Now.Month + "/" + DateTime.Now.Day + "/" + SourceSystem + "/";
                    List<string> blobs = await BlobStorage_V1.ListBlobs(storageAccount, container, dir, log);
                    foreach (string blob in blobs)
                    {
                        string content = await BlobStorage_V1.ReadBlob(connectionstring, container, blob, log);
                        Console.WriteLine(DateTime.Now.ToString()+": "+$"Check blob {blob}");
                        if (
                            blob.EndsWith("_incremental_DELETE_IDENTIFIER_" + TableName + ".json") && 
                            content.Contains("\"MachineTime\": " + timestamp) && 
                            content.Contains("\"Machine\": \"" + Machine + "\"") && 
                            content.StartsWith("["))
                        {
                            Console.WriteLine(DateTime.Now.ToString()+": "+"OK, blob found");
                            counter++;
                            break;
                        }
                    }
                }
            }
            Assert.AreEqual(1, counter);
        }














        static async Task<string> PostURI(Uri u, HttpContent c)
        {
            Console.WriteLine(DateTime.Now.ToString()+": "+"URI: "+u.ToString());
            var response = string.Empty;
            using (var client = new HttpClient())
            {
                HttpResponseMessage result = await client.PostAsync(u, c);
                if (result.IsSuccessStatusCode)
                {
                    response = result.StatusCode.ToString();
                }
            }
            return response;
        }
    }
}
