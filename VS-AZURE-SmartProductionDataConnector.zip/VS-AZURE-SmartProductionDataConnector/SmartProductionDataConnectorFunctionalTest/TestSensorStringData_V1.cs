using SmartProductionDataConnector.Logic;
using System.Text;
using Microsoft.Extensions.Logging;
using Microsoft.WindowsAzure.Storage;
using SmartProductionDataDefinition_V1.JSON.MachineStringData;

namespace SmartProductionDataConnectorFunctionalTest
{
    [TestClass]
    public class TestSensorStringData_V1
    {
        internal static string SourceSystem = "FUNCTIONALTEST_V1";
        internal static string Machine = "testmachine";
        internal static string TableName = "smartKPIMachineStringData";

        internal static int timefordelay = 0;

        /************************************************************************************************
         * 
         * This test uploads data via the SensorStringData_V1 function to the buffer BlobStorage 
         * an checks if file is in BlobStorage
         * 
         * After 5 Min content must be in final BlobStorage --> GlobalSettings_V1.BLOB_CONTAINER
         * 
         ************************************************************************************************/






        public async Task DoSensorStringDataTests(string StagingLevel, Uri url, string connectionstringBuffer, string connectionstringFinal, string bufferContainer)
        {


            timefordelay = 0;
            long time = Convert.ToInt64((DateTime.Now - new DateTime(1970, 1, 1)).TotalMilliseconds);
            string timestamp = time.ToString();
            string body = "{" +
                "\"StagingLevel\": \""+ StagingLevel + "\", " +
                "\"SourceSystem\": \""+SourceSystem+"\", " +
                "\"DeviceName\": \""+ Machine + "\", " +
                "\"SensorName\": \"TEST\", " +
                "\"Description\": \"d\", " +
                "\"Comment\": \"c\", " +
                "\"Plant\": \"p\", " +
                "\"Division\": \"di\", " +
                "\"MeassurementValue\": \"TEST\", " +
                "\"MeassurementDateTimeJava\": " + timestamp +
                "}";

            Console.WriteLine(DateTime.Now.ToString()+": "+"SourceSystem = " + SourceSystem);
            Console.WriteLine(DateTime.Now.ToString()+": "+"StagingLevel = " + StagingLevel);
            Console.WriteLine(DateTime.Now.ToString()+": "+"Machine = " + Machine);
            Console.WriteLine(DateTime.Now.ToString()+": "+"TableName = " + TableName);
            Console.WriteLine(DateTime.Now.ToString()+": "+"timestamp = " + timestamp);
            Console.WriteLine(DateTime.Now.ToString()+": "+"body = " + body);

            await SensorStringDataHTTPCallWithoutError(body, url);
            await SensorStringDataHTTPCallWithoutError(body, url);
            await DoesBufferBlobFileExists(timestamp, connectionstringBuffer, bufferContainer);
            await DoesBlobFileExists(timestamp, StagingLevel, connectionstringFinal);
        }


        private static async Task SensorStringDataHTTPCallWithoutError(string body, Uri url)
        {
            Console.WriteLine(DateTime.Now.ToString()+": "+"SensorStringDataHTTPCallWithoutError");
            timefordelay = DateTime.Now.Minute;
            while (timefordelay >= 10)
            {
                timefordelay -= 10;
            }
            if (timefordelay == 4 || timefordelay == 9) 
            {
                Console.WriteLine(DateTime.Now.ToString()+": "+"Wait 65 Seconds");
                await Task.Delay(65000);
            }

            HttpContent httpContent = new StringContent(body, Encoding.UTF8, "application/json");
            string Result = await Task.Run(() => PostURI(url, httpContent));
            Console.WriteLine(DateTime.Now.ToString()+": "+"--> " + Result);
            Assert.AreEqual("OK", Result);

            timefordelay = DateTime.Now.Minute;
        }

        private static async Task DoesBufferBlobFileExists(string timestamp, string connectionstring, string bufferContainer)
        {
            Console.WriteLine(DateTime.Now.ToString()+": "+"DoesBufferBlobFileExists");
            Console.WriteLine(DateTime.Now.ToString()+": "+"Wait 5 Seconds");
            await Task.Delay(5000);
            Console.WriteLine(DateTime.Now.ToString()+": "+"Countinue...");
            using ILoggerFactory loggerFactory =
                LoggerFactory.Create(builder =>
                    builder.AddConsole());

            ILogger log = loggerFactory.CreateLogger("test");

            int counter = 0;
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(connectionstring);

            List<string> containers = await BlobStorage_V1.ListContainers(storageAccount, log);
            Console.WriteLine(DateTime.Now.ToString()+": "+"Found "+containers.Count+" containers");

            foreach (string container in containers)
            {
                Console.WriteLine(DateTime.Now.ToString()+": "+$"Container {container}");
                if (container.StartsWith(bufferContainer))
                {
                    Console.WriteLine(DateTime.Now.ToString()+": "+$"Checking container {container}");
                    List<string> blobs = await BlobStorage_V1.ListBlobs(storageAccount, container, DataBufferObserverLogic_V1.GetProcessSensorStringDataFolder()+"/", log);
                    List<JSONSmartKPIMachineStringDataRow_V1> jsonData = new();
                    foreach (string blob in blobs)
                    {
                        string content = await BlobStorage_V1.ReadBlob(connectionstring, container, blob, log);
                        Console.WriteLine(DateTime.Now.ToString()+": "+$"Check blob {blob}");
                        if (content.Contains("\"MeassurementDateTimeJava\": " + timestamp))
                        {
                            Console.WriteLine(DateTime.Now.ToString()+": "+"OK, blob found");
                            counter++;
                        }
                    }
                }
            }
            Assert.AreEqual(2,counter);
        }

        private static async Task DoesBlobFileExists(string timestamp, string StagingLevel, string connectionstring)
        {
            Console.WriteLine(DateTime.Now.ToString()+": "+"DoesBlobFileExists");
            int offset = 6;
            while (timefordelay >= 10)
            {
                timefordelay -= 10;
            }

            if (timefordelay >=  5)
            {
                offset = 11;
            }

            offset -= timefordelay;

            Console.WriteLine(DateTime.Now.ToString()+": "+"Wait " + offset + " Minute(s)");
            await Task.Delay(offset* 60 * 1000);
            Console.WriteLine(DateTime.Now.ToString()+": "+"Countinue...");


            using ILoggerFactory loggerFactory =
                LoggerFactory.Create(builder =>
                    builder.AddConsole());

            ILogger log = loggerFactory.CreateLogger("test");

            int counter = 0;
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(connectionstring);

            List<string> containers = await BlobStorage_V1.ListContainers(storageAccount, log);
            Console.WriteLine(DateTime.Now.ToString()+": "+"Found " + containers.Count + " containers");

            foreach (string container in containers)
            {
                if (container == GlobalSettings_V1.BLOB_CONTAINER)
                {
                    Console.WriteLine(DateTime.Now.ToString()+": "+$"Start container {container}");
                    string dir = StagingLevel + "/FUNCTIONALTEST/" + TableName + "/" + DateTime.Now.Year + "/" + DateTime.Now.Month + "/" + DateTime.Now.Day + "/" + SourceSystem + "/";
                    List<string> blobs = await BlobStorage_V1.ListBlobs(storageAccount, container, dir, log);
                    foreach (string blob in blobs)
                    {
                        string content = await BlobStorage_V1.ReadBlob(connectionstring, container, blob, log);
                        Console.WriteLine(DateTime.Now.ToString()+": "+$"Check blob {blob}");
                        if (
                            blob.Contains("_incremental_" + TableName + "_DirectPush_V1_") && 
                            content.Contains("\"MachineTime\": " + timestamp) && 
                            content.Contains("\"Machine\": \"" + Machine + "\"") && 
                            content.StartsWith("[") && 
                            content.Contains("},"))
                        {
                            Console.WriteLine(DateTime.Now.ToString()+": "+"OK, blob found");
                            counter++;
                            break;
                        }
                    }
                }
            }
            Assert.AreEqual(1, counter);
        }














        static async Task<string> PostURI(Uri u, HttpContent c)
        {
            var response = string.Empty;
            using (var client = new HttpClient())
            {
                HttpResponseMessage result = await client.PostAsync(u, c);
                if (result.IsSuccessStatusCode)
                {
                    response = result.StatusCode.ToString();
                }
            }
            return response;
        }

    }
}