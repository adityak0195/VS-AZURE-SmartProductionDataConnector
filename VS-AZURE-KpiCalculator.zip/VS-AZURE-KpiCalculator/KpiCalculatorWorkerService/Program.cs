using KpiCalculator.Logic;
using Microsoft.Extensions.Hosting.WindowsServices;
using Microsoft.Extensions.Logging.EventLog;

//var builder = Host.CreateApplicationBuilder(args);
//builder.Services.AddHostedService<Worker>();
//
//var host = builder.Build();
//host.Run();

Host.CreateDefaultBuilder(args)
    .ConfigureLogging(logging =>
    {
        if (OperatingSystem.IsWindows())
        {
            logging.AddFilter<EventLogLoggerProvider>(level => level >= LogLevel.Information);
        }
    })
    .ConfigureServices(services =>
    {
        services.AddHostedService<CalculatorWorkerPROD>();
        if (OperatingSystem.IsWindows())
        {
            services.Configure<EventLogSettings>(config =>
            {
                config.LogName = "KpiCalculatorWorkerServicePROD";
                config.SourceName = "KPI Calculator Service PROD";
            });
        }
    })
    .UseWindowsService()
    .Build()
    .Run();