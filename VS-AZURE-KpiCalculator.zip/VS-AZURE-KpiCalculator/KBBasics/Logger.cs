﻿using KBBasics.SetupForFileSystem;
using Microsoft.Extensions.Logging;
using System.Diagnostics;
using System.Runtime.Versioning;

namespace KBBasics
{
    public enum LogType
    {
        EVENT_LOG = 0x00000001,
        CONSOLE = 0x00000002,
    }

    public enum LogLevel
    {
        INFO = 0x00000001,
        WARNING = 0x00000002,
        ERROR = 0x00000002,
    }


    public class Logger
    {
        private readonly LogType LogType;
        private readonly ILogger? EventLogger;

        [SupportedOSPlatform("windows")]
        public Logger()
        {
            LogType = LogType.CONSOLE;
        }

        [SupportedOSPlatform("windows")]
        public Logger(ILogger logger)
        {
            LogType = LogType.EVENT_LOG;
            EventLogger = logger;
        }

            [SupportedOSPlatform("windows")]
        public void Log(LogLevel logLevel, string message)
        {
            string messageOut = DateTime.Now + " > " + message;
            if (LogType.CONSOLE == LogType)
            {
                Console.WriteLine(logLevel.ToString()+": "+ messageOut);
            }
            else if (LogType.EVENT_LOG == LogType && EventLogger != null)
            {
                if (LogLevel.ERROR == logLevel)
                {
                    EventLogger.LogError(message);
                }
                else if (LogLevel.WARNING == logLevel)
                {
                    EventLogger.LogWarning(message);
                }
                else if (LogLevel.INFO == logLevel)
                {
                    EventLogger.LogInformation(message);
                }
                else
                {
                    throw new NotImplementedException();
                }
            }
            else
            {
                throw new NotImplementedException();
            }
        }
    }
}
