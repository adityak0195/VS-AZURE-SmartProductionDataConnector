﻿
namespace KBBasics.SetupForFileSystem
{


    public class SnowflakeDivision
    {
        public const string CVS = "CVS";
        public const string RVS = "RVS";
    }
    
    public class Basics
    {
        public string loggerName = "KpiCalculator";
    }

    public class KPICalculation
    {
        public int TimeoutForKPICalculationInSeconds = 60;
        public Boolean enableShiftKPIs = false;
        public Boolean enableHourlyKPIs = false;
        public Boolean enableDailyKPIs = false;
        public Boolean enableWeeklyKPIs = false;
        public Boolean enableMonthlyPIs = false;
        public Boolean enableYearlyKPIs = false;
        public int MinutesToRecalculateKPIsOfPreviousSlotForShiftBase = 10;
        public int MinutesToRecalculateKPIsOfPreviousSlotForHourlyBase = 10;
        public int MinutesToRecalculateKPIsOfPreviousSlotForDailyBase = 30;
        public int MinutesToRecalculateKPIsOfPreviousSlotForWeeklyBase = 100;
        public int MinutesToRecalculateKPIsOfPreviousSlotForMonthlyBase = 100;
        public int MinutesToRecalculateKPIsOfPreviousSlotForYearlyBase = 2000;
    }

    public class  MsSQL
    {
        public string passwort = "";
        public string server = "";
        public string database = "";
        public string user = "";
        public string name = "";
        public string snowflakeSourceNameForLongtermKpiCalculation = "";
        public KPICalculation KPICalculation = new();
    }

    public class Snowflake
    {
        public Boolean getSnowflakeKeyFromFile = true;
        public string snowflakeKeyFile = "";
        public string snowflakeKey = "";
        public string host = "";
        public string DB = "";
        public string user = "";
        public string warehouse = "";
        public string account = "";
        public string name = "";
        public string schema = "";
        public string role = "";
    }

    public class SettingsKpiCalculator
    {
        public Basics basics = new();
        public List<Snowflake> snowflake = new();
        public List<MsSQL> mssql = new();
    }

    public static class SettingsDefinition
    {
        private static string mainPath = "C:\\KBData";
        private static string subPath = mainPath + "\\KpiCalculator";
        private static string settingsFileNameWithoutSuffix = "settings";
        private static string settingsFileName = settingsFileNameWithoutSuffix;
        private static string settingsFileTemplateName = settingsFileNameWithoutSuffix + "-Template-copy-to-edit.json";
        private static string fullSettingsFileName = subPath + "\\" + settingsFileName;
        private static string fullSettingsTemplateFileName = subPath + "\\" + settingsFileTemplateName;

        public static string GetSettingsFileName(string stagingLevel)
        {
            return settingsFileName + stagingLevel + ".json";
        }

        public static string GetFullSettingsFileName(string stagingLevel)
        {
            return fullSettingsFileName + stagingLevel + ".json";
        }

        public static string GetFullSettingsTemplateFileName(string stagingLevel)
        {
            return fullSettingsTemplateFileName + stagingLevel + ".json";
        }

        public static string GetMainPath()
        {
            return mainPath;
        }

        public static string GetSubPath()
        {
            return subPath;
        }

        public static string GetSettingsFileTemplateName(string stagingLevel)
        {
            return settingsFileTemplateName + stagingLevel + ".json";
        }

        public static Settings AddDefaultContentAfterFileSetup(Settings settings)
        {
            return settings;
        }
        public static Settings AddDefaultContentBeforeFileSetup(Settings settings)
        {
            if (!settings.settingsKpiCalculator.snowflake.Any(x => x.name == "CVS"))
            {
                settings.settingsKpiCalculator.snowflake.Add(new Snowflake()
                {
                    getSnowflakeKeyFromFile = true,
                    snowflakeKeyFile = "C:\\KBData\\SF\\SVC.MUC.THINGWORX@KNORR-BREMSE.COM.p8",
                    snowflakeKey = "",
                    host = "hs05738.west-europe.azure.snowflakecomputing.com",
                    DB = "CORP_PROD_M_DB",
                    user = "SVC.MUC.THINGWORX@KNORR-BREMSE.COM",
                    warehouse = "CORP_PROD_ANALYTICS_WH",
                    account = "hs05738",
                    name = SnowflakeDivision.CVS,
                    schema = "CVS_SMARTPRODUCTION",
                    role = "CORP_PROD_CVS_SMARTPRODUCTION_GLOBAL_FR"
                });

                if (!settings.settingsKpiCalculator.snowflake.Any(x => x.name == "RVS"))
                {
                    settings.settingsKpiCalculator.snowflake.Add(new Snowflake()
                    {
                        getSnowflakeKeyFromFile = true,
                        snowflakeKeyFile = "C:\\KBData\\SF\\SVC.MUC.THINGWORX@KNORR-BREMSE.COM.p8",
                        snowflakeKey = "",
                        host = "hs05738.west-europe.azure.snowflakecomputing.com",
                        DB = "CORP_PROD_M_DB",
                        user = "SVC.MUC.THINGWORX@KNORR-BREMSE.COM",
                        warehouse = "CORP_PROD_ANALYTICS_WH",
                        account = "hs05738",
                        name = SnowflakeDivision.RVS,
                        schema = "RVS_SMARTPRODUCTION",
                        role = "CORP_PROD_RVS_SMARTPRODUCTION_GLOBAL_FR"
                    });
                }

                if (!settings.settingsKpiCalculator.mssql.Any(x => x.name == "Sample"))
                {
                    settings.settingsKpiCalculator.mssql.Add(new MsSQL()
                    {
                        passwort = "PW",
                        server = "Server",
                        database = "Database",
                        user = "User",
                        name = "Sample",
                    });
                }
                

            }
            return settings;
        }
    }
}
