﻿using Newtonsoft.Json;
using Microsoft.Extensions.Logging;

namespace KBBasics.SetupForFileSystem
{
    public class Settings
    {
        public SettingsKpiCalculator settingsKpiCalculator = new();
    }

    public class AppSettings
    {
        public Settings? Settings { get; private set; }
        private string _stagingLevel;

        public AppSettings(string stagingLevel)
        {
            _stagingLevel = stagingLevel;
            RootWorkingDirectory = "";
            Settings = new();
            SetupConfigFile();
            SettingsDefinition.AddDefaultContentBeforeFileSetup(Settings);
            ReadWriteConfig();
            SettingsDefinition.AddDefaultContentAfterFileSetup(Settings);
        }

        private string RootWorkingDirectory;


        private void SetupConfigFile()
        {
            if (!Directory.Exists(SettingsDefinition.GetMainPath()))
            {
                Directory.CreateDirectory(SettingsDefinition.GetMainPath());
            }
            if (!Directory.Exists(SettingsDefinition.GetSubPath()))
            {
                Directory.CreateDirectory(SettingsDefinition.GetSubPath());
            }

            RootWorkingDirectory = SettingsDefinition.GetMainPath();
            Settings = new();

        }

        private void ReadWriteConfig()
        {
            if (!File.Exists(SettingsDefinition.GetFullSettingsFileName(_stagingLevel)))
            {
                File.WriteAllText(SettingsDefinition.GetFullSettingsFileName(_stagingLevel), JsonConvert.SerializeObject(Settings, Formatting.Indented));
            }
            string filecontent = File.ReadAllText(SettingsDefinition.GetFullSettingsFileName(_stagingLevel));
            Settings = JsonConvert.DeserializeObject<Settings>(filecontent);

            Settings settingsTemplate = new();
            File.WriteAllText(SettingsDefinition.GetFullSettingsTemplateFileName(_stagingLevel), JsonConvert.SerializeObject(settingsTemplate, Formatting.Indented));
        }

        public string GetRootWorkingDirectory()
        {
            return RootWorkingDirectory ?? "";
        }
    }

}
