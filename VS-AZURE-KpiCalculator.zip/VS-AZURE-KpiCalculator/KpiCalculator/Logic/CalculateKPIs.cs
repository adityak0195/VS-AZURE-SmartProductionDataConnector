﻿using Amazon.Runtime.Internal.Util;
using KBBasics;
using KBBasics.SetupForFileSystem;
using KpiCalculator.Data;
using KpiCalculator.Data.Dataprovider;
using KpiCalculator.JSON;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Mono.Unix.Native;
using Org.BouncyCastle.Crypto.IO;
using System;
using System.Diagnostics.Eventing.Reader;
using System.Reflection.PortableExecutable;

namespace KpiCalculator.Logic
{
    // CalculateKPIsType
    // Enum for calculating KPIs hourly or daily
    public enum CalculateKPIsType
    {
        HOURLY = 0x00000001,
        DAILY = 0x00000002,
        SHIFT = 0x00000003,
        WEEKLY = 0x00000004,
        MONTHLY = 0x00000005,
        YEARLY = 0x00000006
    }

    // CalculationType
    // Enum for calculating KPIs for machines or stations
    public enum CalculationType
    {
        STATION = 0x00000001,
        MACHINE = 0x00000002,
        AREA = 0x00000003,
        MODULE = 0x00000004,
        PLANT = 0x00000005
    }

    // CalculateKPIs
    // Class for calculating KPIs for machines and stations
    public class CalculateKPIs
    {
        public class CalculationTimeSlot
        {
            public DateTime Start;
            public DateTime End;
            public Boolean DoCalculation = true;
        }

        internal readonly AppSettings appSettings;
        private readonly KBBasics.Logger _logger;
        public readonly CalculateKPIsType CalculateKPIsType;
        public readonly CalculationType CalculationType;
        public readonly string CalculationName = "CalculateKPIs";
        private readonly string _calculateKPIsTypeNameForDB;

        // Constructor
        // @param calculateKPIsType: CalculateKPIsType
        // @param calculationType: CalculationType
        public CalculateKPIs(CalculateKPIsType calculateKPIsType, CalculationType calculationType, string stagingLevele)
        {
            appSettings = new(stagingLevele);
            _logger = new();
            CalculateKPIsType = calculateKPIsType;
            CalculationType = calculationType;
            if (CalculateKPIsType == CalculateKPIsType.DAILY)
            {
                CalculationName += "Daily";
                _calculateKPIsTypeNameForDB = "day";
            }
            else if (CalculateKPIsType == CalculateKPIsType.HOURLY)
            {
                CalculationName += "Hourly";
                _calculateKPIsTypeNameForDB = "hour";
            }
            else if (CalculateKPIsType == CalculateKPIsType.SHIFT)
            {
                CalculationName += "Shift";
                _calculateKPIsTypeNameForDB = "shift";
            }
            else if (CalculateKPIsType == CalculateKPIsType.WEEKLY)
            {
                CalculationName += "Week";
                _calculateKPIsTypeNameForDB = "week";
            }
            else if (CalculateKPIsType == CalculateKPIsType.MONTHLY)
            {
                CalculationName += "Month";
                _calculateKPIsTypeNameForDB = "month";
            }
            else if (CalculateKPIsType == CalculateKPIsType.YEARLY)
            {
                CalculationName += "Year";
                _calculateKPIsTypeNameForDB = "year";
            }
            else
            {
                throw new NotImplementedException();
            }

            if (CalculationType == CalculationType.MACHINE)
            {
                CalculationName += "Machine";
            }
            else if (CalculationType == CalculationType.STATION)
            {
                CalculationName += "Station";
            }
            else if (CalculationType == CalculationType.AREA)
            {
                CalculationName += "Area";
            }
            else if (CalculationType == CalculationType.MODULE)
            {
                CalculationName += "Module";
            }
            else if (CalculationType == CalculationType.PLANT)
            {
                CalculationName += "Plant";
            }
            else
            {
                throw new NotImplementedException();
            }
        }

        // Constructor
        // @param logger: Logger
        // @param calculateKPIsType: CalculateKPIsType
        // @param calculationType: CalculationType
        public CalculateKPIs(Microsoft.Extensions.Logging.ILogger logger, CalculateKPIsType calculateKPIsType, CalculationType calculationType, string stagingLevel) :this(calculateKPIsType, calculationType, stagingLevel)
        {
            _logger = new(logger);
        }

        // GetStartOfSlot
        // Get the start of a slot
        // @param baseDateTime: Base date time
        // @param stationMachineAreas: JsonOutputAreaMachineStation
        // @return DateTime
        public DateTime GetStartOfSlot(DateTime baseDateTime, JsonOutputAreaMachineModuleStation stationMachineArea, Boolean useTimeOffset)
        {
            if (CalculateKPIsType == CalculateKPIsType.HOURLY)
            {
                return baseDateTime;
            }
            else if (CalculateKPIsType == CalculateKPIsType.SHIFT)
            {
                throw new NotImplementedException();
            }
            else 
            {
                double utcOffset = 0;
                double plantOffset = 0;

                if (stationMachineArea != null && useTimeOffset)
                {
                    utcOffset = GetUtcOffset(stationMachineArea.ServerTimeZoneDB, baseDateTime);
                    plantOffset = stationMachineArea.DayOffset;
                }
                if (useTimeOffset)
                {
                    return baseDateTime.AddMinutes(-utcOffset).AddMinutes(plantOffset);
                }
                else
                {
                    return baseDateTime;
                }
            }
        }

        // GetEndOfSlot
        // Get the end of a slot
        // @param baseDateTime: Base date time
        // @param stationMachineAreas: JsonOutputAreaMachineStation
        // @param useTimeOffset: use Time Offset
        // @return DateTime
        public DateTime GetEndOfSlot(DateTime baseDateTime, JsonOutputAreaMachineModuleStation stationMachineArea, Boolean useTimeOffset)
        {
            if (CalculateKPIsType == CalculateKPIsType.HOURLY)
            {
                return baseDateTime.AddHours(1);
            }
            else if (CalculateKPIsType == CalculateKPIsType.SHIFT)
            {
                throw new NotImplementedException();
            }
            else 
            {
                double utcOffset = 0;
                double plantOffset = 0;

                if (stationMachineArea != null && useTimeOffset)
                {
                    plantOffset = stationMachineArea.DayOffset;
                }

                if (CalculateKPIsType == CalculateKPIsType.DAILY)
                {
                    if (useTimeOffset)
                    {
                        DateTime newBaseTime = baseDateTime.AddDays(1);
                        utcOffset = GetUtcOffset(stationMachineArea.ServerTimeZoneDB, newBaseTime);
                        return newBaseTime.AddMinutes(-utcOffset).AddMinutes(plantOffset);
                    }
                    else
                    {
                        return baseDateTime.AddDays(1);
                    }
                }
                else if (CalculateKPIsType == CalculateKPIsType.WEEKLY)
                {
                    if (useTimeOffset)
                    {
                        DateTime newBaseTime = baseDateTime.AddDays(7);
                        utcOffset = GetUtcOffset(stationMachineArea.ServerTimeZoneDB, newBaseTime);
                        return newBaseTime.AddMinutes(-utcOffset).AddMinutes(plantOffset);
                    }
                    else
                    {
                        return baseDateTime.AddDays(7);
                    }
                }
                else if (CalculateKPIsType == CalculateKPIsType.MONTHLY)
                {
                    if (useTimeOffset)
                    {
                        DateTime newBaseTime = baseDateTime.AddMonths(1);
                        utcOffset = GetUtcOffset(stationMachineArea.ServerTimeZoneDB, newBaseTime);
                        return newBaseTime.AddMinutes(-utcOffset).AddMinutes(plantOffset);
                    }
                    else
                    {
                        return baseDateTime.AddMonths(1);
                    }
                }
                else if (CalculateKPIsType == CalculateKPIsType.YEARLY)
                {
                    if (useTimeOffset)
                    {
                        DateTime newBaseTime = baseDateTime.AddYears(1);
                        utcOffset = GetUtcOffset(stationMachineArea.ServerTimeZoneDB, newBaseTime);
                        return newBaseTime.AddMinutes(-utcOffset).AddMinutes(plantOffset);
                    }
                    else
                    {
                        return baseDateTime.AddYears(1);
                    }
                }
                else
                {
                    throw new NotImplementedException();
                }
            }
        }

        // GetStartOfPriviousSlot
        // Get the start of the privious slot
        // @param baseDateTime: Base date time
        // @param stationMachineAreas: JsonOutputAreaMachineStation
        // @return DateTime
        public DateTime GetStartOfPriviousSlot(DateTime baseDateTime, JsonOutputAreaMachineModuleStation stationMachineArea, Boolean useTimeOffset)
        {
            if (CalculateKPIsType == CalculateKPIsType.HOURLY)
            {
                return baseDateTime.AddHours(-1);
            }
            else if (CalculateKPIsType == CalculateKPIsType.SHIFT)
            {
                throw new NotImplementedException();
            }
            else 
            {
                double utcOffset = 0;
                double plantOffset = 0;

                if (stationMachineArea != null && useTimeOffset)
                {
                    plantOffset = stationMachineArea.DayOffset;
                }


                if (CalculateKPIsType == CalculateKPIsType.DAILY)
                {
                    if (useTimeOffset)
                    {
                        DateTime newBaseTime = baseDateTime.AddDays(-1);
                        utcOffset = GetUtcOffset(stationMachineArea.ServerTimeZoneDB, newBaseTime);
                        return newBaseTime.AddMinutes(-utcOffset).AddMinutes(plantOffset);
                    }
                    else
                    {
                        return baseDateTime.AddDays(-1);
                    }
                }
                else if (CalculateKPIsType == CalculateKPIsType.WEEKLY)
                {
                    if (useTimeOffset)
                    {
                        DateTime newBaseTime = baseDateTime.AddDays(-7);
                        utcOffset = GetUtcOffset(stationMachineArea.ServerTimeZoneDB, newBaseTime);
                        return newBaseTime.AddMinutes(-utcOffset).AddMinutes(plantOffset);
                    }
                    else
                    {
                        return baseDateTime.AddDays(-7);
                    }
                }
                else if (CalculateKPIsType == CalculateKPIsType.MONTHLY)
                {
                    if (useTimeOffset)
                    {
                        DateTime newBaseTime = baseDateTime.AddMonths(-1);
                        utcOffset = GetUtcOffset(stationMachineArea.ServerTimeZoneDB, newBaseTime);
                        return newBaseTime.AddMinutes(-utcOffset).AddMinutes(plantOffset);
                    }
                    else
                    {
                        return baseDateTime.AddMonths(-1);
                    }
                }
                else if (CalculateKPIsType == CalculateKPIsType.YEARLY)
                {
                    if (useTimeOffset)
                    {
                        DateTime newBaseTime = baseDateTime.AddYears(-1);
                        utcOffset = GetUtcOffset(stationMachineArea.ServerTimeZoneDB, newBaseTime);
                        return newBaseTime.AddMinutes(-utcOffset).AddMinutes(plantOffset);
                    }
                    else
                    {
                        return baseDateTime.AddYears(-1);
                    }
                }
                else
                { 
                    throw new NotImplementedException(); 
                }
            }
        }


        // GetEndOfPriviousSlot
        // Get the end of the privious slot
        // @param baseDateTime: Base date time
        // @param stationMachineAreas: JsonOutputAreaMachineStation
        // @return DateTime
        public DateTime GetEndOfPriviousSlot(DateTime baseDateTime, JsonOutputAreaMachineModuleStation stationMachineArea, Boolean useTimeOffset)
        {
            if (CalculateKPIsType == CalculateKPIsType.HOURLY)
            {
                return baseDateTime;
            }
            else if (CalculateKPIsType == CalculateKPIsType.SHIFT)
            {
                throw new NotImplementedException();
            }
            else 
            {
                double utcOffset = 0;
                double plantOffset = 0;

                if (stationMachineArea != null && useTimeOffset)
                {
                    utcOffset = GetUtcOffset(stationMachineArea.ServerTimeZoneDB, baseDateTime);
                    plantOffset = stationMachineArea.DayOffset;
                }
                if (useTimeOffset)
                {
                    return baseDateTime.AddMinutes(-utcOffset).AddMinutes(plantOffset);
                }
                else
                {
                    return baseDateTime;
                }
            }
        }

        // GetListOfAreasMachinesModulesStations
        // Get a list of areas, machines, modules or stations
        // @param dataMssql: DataMssql DB connection
        // @return JsonOutputListOfAreasMachinesModulesStations
        private JsonOutputListOfAreasMachinesModulesStations GetListOfAreasMachinesModulesStations(DataMssql dataMssql)
        {
            if (CalculationType == CalculationType.MACHINE)
            {
                return AreasMachinesModulesStations.GetListOfMachines(dataMssql);
            }
            else if (CalculationType == CalculationType.STATION)
            {
                return AreasMachinesModulesStations.GetListOfStations(dataMssql);
            }
            else if (CalculationType == CalculationType.AREA)
            {
                return AreasMachinesModulesStations.GetListOfAreas(dataMssql);
            }
            else if (CalculationType == CalculationType.MODULE)
            {
                return AreasMachinesModulesStations.GetListOfModules(dataMssql);
            }
            else if (CalculationType == CalculationType.PLANT)
            {
                return AreasMachinesModulesStations.GetListOfPlants(dataMssql);
            }
            else
            {
                throw new NotImplementedException();
            }
        }


        public int GetWeekOffset(DateTime baseTime)
        {
            //Sunday        0
            //Monday        1
            //Tuesday       2
            //Wednesday     3
            //Thursday      4
            //Friday        5
            //Saturday      6
            int offset = baseTime.DayOfWeek - DayOfWeek.Monday;
            if (offset < 0)
            {
                offset += 7;
            }
            return offset;
        }

        // GetBaseTime
        // Get the base time
        // @param startTime: Start time
        // @return DateTime
        public DateTime GetBaseTime(DateTime startTime)
        {
            if (CalculateKPIsType == CalculateKPIsType.HOURLY)
            {
                return new(startTime.Year, startTime.Month, startTime.Day, startTime.Hour, 0, 0);
            }
            else if (CalculateKPIsType == CalculateKPIsType.DAILY)
            {
                return new(startTime.Year, startTime.Month, startTime.Day, 0, 0, 0);
            }
            else if (CalculateKPIsType == CalculateKPIsType.WEEKLY)
            {
                DateTime returnvalue = new(startTime.Year, startTime.Month, startTime.Day, 0, 0, 0);
                return returnvalue.AddDays(-GetWeekOffset(startTime));
            }
            else if (CalculateKPIsType == CalculateKPIsType.MONTHLY)
            {
                return new(startTime.Year, startTime.Month, 1, 0, 0, 0);
            }
            else if (CalculateKPIsType == CalculateKPIsType.YEARLY)
            {
                return new(startTime.Year, 1, 1, 0, 0, 0);
            }
            else
            {
                return startTime;
            }
        }

        // GetCurrentCalculationTimeSlot
        // Get the current calculation time slot
        // @param baseDateTime: Base date time
        // @param stationMachineAreas: JsonOutputAreaMachineStation
        // @param useTimeOffset: Use time offset
        // @return CalculationTimeSlot
        private CalculationTimeSlot GetCurrentCalculationTimeSlot(DataMssql dataMssql, DateTime baseDateTime, JsonOutputAreaMachineModuleStation stationMachineArea, Boolean useTimeOffset = true)
        {
            CalculationTimeSlot calculationTimeSlot = new();

            if (CalculateKPIsType == CalculateKPIsType.SHIFT)
            {
                JsonOutputListOfShiftDefinitions jsonOutputListOfShiftDefinitions = dataMssql.GetCurrentOrNextShiftDefinition(stationMachineArea.Machine, baseDateTime);
                if (jsonOutputListOfShiftDefinitions.ShiftDefinitions == null || jsonOutputListOfShiftDefinitions.ShiftDefinitions.Count != 1)
                {
                    calculationTimeSlot.DoCalculation = false;
                }
                else
                {
                    calculationTimeSlot.Start = jsonOutputListOfShiftDefinitions.ShiftDefinitions[0].StartTime;
                    calculationTimeSlot.End = jsonOutputListOfShiftDefinitions.ShiftDefinitions[0].EndTime;
                }
            }
            else
            {
                calculationTimeSlot.Start = GetStartOfSlot(baseDateTime, stationMachineArea, useTimeOffset);
                calculationTimeSlot.End = GetEndOfSlot(baseDateTime, stationMachineArea, useTimeOffset);
            }


            return calculationTimeSlot;
        }

        // GetPriviousCalculationTimeSlot
        // Get the privious calculation time slot
        // @param baseDateTime: Base date time
        // @param stationMachineAreas: JsonOutputAreaMachineStation
        // @param useTimeOffset: Use time offset
        // @return CalculationTimeSlot
        private CalculationTimeSlot GetPriviousCalculationTimeSlot(DataMssql dataMssql, DateTime baseDateTime, JsonOutputAreaMachineModuleStation stationMachineArea, Boolean useTimeOffset = true)
        {
            CalculationTimeSlot calculationTimeSlot = new();

            if (CalculateKPIsType == CalculateKPIsType.SHIFT)
            {
                JsonOutputListOfShiftDefinitions jsonOutputListOfShiftDefinitions = dataMssql.GetLastShiftDefinition(stationMachineArea.Machine, baseDateTime);
                if (jsonOutputListOfShiftDefinitions.ShiftDefinitions == null || jsonOutputListOfShiftDefinitions.ShiftDefinitions.Count != 1)
                {
                    calculationTimeSlot.DoCalculation = false;
                }
                else
                {
                    calculationTimeSlot.Start = jsonOutputListOfShiftDefinitions.ShiftDefinitions[0].StartTime;
                    calculationTimeSlot.End = jsonOutputListOfShiftDefinitions.ShiftDefinitions[0].EndTime;
                }
            }
            else
            {
                calculationTimeSlot.Start = GetStartOfPriviousSlot(baseDateTime, stationMachineArea, useTimeOffset);
                calculationTimeSlot.End = GetEndOfPriviousSlot(baseDateTime, stationMachineArea, useTimeOffset);
            }

            return calculationTimeSlot;
        }

        // GetSettingsRecalculationTime
        // Get the settings recalculation time
        // @param msSQL: MsSQL settings part
        // @return int
        private int GetSettingsRecalculationTime(MsSQL msSQL)
        {
            if (CalculateKPIsType == CalculateKPIsType.HOURLY)
            {
                return msSQL.KPICalculation.MinutesToRecalculateKPIsOfPreviousSlotForHourlyBase;
            }
            else if (CalculateKPIsType == CalculateKPIsType.DAILY)
            {
                return msSQL.KPICalculation.MinutesToRecalculateKPIsOfPreviousSlotForDailyBase;
            }
            else if (CalculateKPIsType == CalculateKPIsType.SHIFT)
            {
                return msSQL.KPICalculation.MinutesToRecalculateKPIsOfPreviousSlotForShiftBase;
            }
            else if (CalculateKPIsType == CalculateKPIsType.MONTHLY)
            {
                return msSQL.KPICalculation.MinutesToRecalculateKPIsOfPreviousSlotForMonthlyBase;
            }
            else if (CalculateKPIsType == CalculateKPIsType.WEEKLY)
            {
                return msSQL.KPICalculation.MinutesToRecalculateKPIsOfPreviousSlotForWeeklyBase;
            }
            else if (CalculateKPIsType == CalculateKPIsType.YEARLY)
            {
                return msSQL.KPICalculation.MinutesToRecalculateKPIsOfPreviousSlotForYearlyBase;
            }
            else
            {
                return 0;
            }
        }

        // DoCalculation
        // Calculate KPIs for machines or stations
        // @param msSQL: MsSQL settings part
        // @return JsonOutputSummary
        public JsonOutputSummary DoCalculation(MsSQL msSQL)
        {
            JsonOutputSummary jsonOutputSummary = new();

            if (IsFiveMinuteJob(msSQL) || IsOneHourJob(msSQL) || IsOneDayJob(msSQL))
            {
                DateTime nowUTC = DateTime.UtcNow;
                DateTime baseDateTime = GetBaseTime(nowUTC);
                _logger.Log(KBBasics.LogLevel.INFO, CalculationName + " DB: " + msSQL.name);
                DataMssql dataMssql = new(msSQL);
                DataSnowflake dataSnowflake = new(appSettings.Settings?.settingsKpiCalculator.snowflake.Find(x => x.name == msSQL.snowflakeSourceNameForLongtermKpiCalculation));
                JsonOutputListOfAreasMachinesModulesStations areasMachinesModulesStations = GetListOfAreasMachinesModulesStations(dataMssql);
                _logger.Log(KBBasics.LogLevel.INFO, " DB: " + areasMachinesModulesStations.AreasMachinesModulesStations.Count + " Objects found ("+CalculateKPIsType+", "+CalculationType+").");


                foreach (var stationModuleMachineArea in areasMachinesModulesStations.AreasMachinesModulesStations)
                {
                    CalculationTimeSlot calculationPriviousTimeSlot = GetPriviousCalculationTimeSlot(dataMssql, baseDateTime, stationModuleMachineArea);
                    CalculationTimeSlot calculationTimeSlot = GetCurrentCalculationTimeSlot(dataMssql, baseDateTime, stationModuleMachineArea);

                    //First x Minutes of an hour the last one will be recalculated
                    if ((nowUTC - calculationPriviousTimeSlot.End).TotalMinutes <= GetSettingsRecalculationTime(msSQL))
                    {
                        if (calculationPriviousTimeSlot.DoCalculation)
                        {
                            if (IsLongtermCalculation() && dataSnowflake != null)
                            {
                                jsonOutputSummary = DoLongtermCalculation(jsonOutputSummary,dataSnowflake, dataMssql, calculationPriviousTimeSlot.Start, calculationPriviousTimeSlot.End, stationModuleMachineArea, _calculateKPIsTypeNameForDB);
                            }
                            else
                            {
                                jsonOutputSummary = DoCalculation(jsonOutputSummary, dataMssql, calculationPriviousTimeSlot.Start, calculationPriviousTimeSlot.End, stationModuleMachineArea, msSQL.KPICalculation.TimeoutForKPICalculationInSeconds);
                            }
                        }
                    }
                    if (calculationTimeSlot.DoCalculation)
                    {
                        if (IsLongtermCalculation())
                        {
                            jsonOutputSummary = DoLongtermCalculation(jsonOutputSummary, dataSnowflake, dataMssql, calculationTimeSlot.Start, calculationTimeSlot.End, stationModuleMachineArea, _calculateKPIsTypeNameForDB);
                        }
                        else
                        {
                            jsonOutputSummary = DoCalculation(jsonOutputSummary, dataMssql, calculationTimeSlot.Start, calculationTimeSlot.End, stationModuleMachineArea, msSQL.KPICalculation.TimeoutForKPICalculationInSeconds);
                        }
                    }
                }
            }
            _logger.Log(KBBasics.LogLevel.INFO, CalculationName + " DB: " + msSQL.name + " done");
            return jsonOutputSummary;
        }


        // ReCalculateKPIsForYearForMachines
        // Recalculate KPIs for machines for a year
        // @param year: Year
        // @return JsonOutputSummary
        public JsonOutputSummary ReCalculateKPIsForYear(int year, MsSQL msSQL)
        {
            DateTime startDate2calculate = new(year, 1, 1, 0, 0, 0);
            return ReCalculateKPIs(startDate2calculate, startDate2calculate.AddYears(1), msSQL);
        }

        // ReCalculateKPIsForMonthForMachines
        // Recalculate KPIs for machines for a month
        // @param year: Year
        // @param month: Month
        // @return JsonOutputSummary
        public JsonOutputSummary ReCalculateKPIsForMonth(int year, int month, MsSQL msSQL)
        {
            DateTime startDate2calculate = new(year, month, 1, 0, 0, 0);
            return ReCalculateKPIs(startDate2calculate, startDate2calculate.AddMonths(1), msSQL);
        }

        // ReCalculateKPIsForDayForMachines
        // Recalculate KPIs for machines for a day
        // @param year: Year
        // @param month: Month
        // @param day: Day
        // @return JsonOutputSummary
        public JsonOutputSummary ReCalculateKPIsForDay(int year, int month, int day, MsSQL msSQL)
        {
            DateTime startDate2calculate = new(year, month, day, 0, 0, 0);
            return ReCalculateKPIs(startDate2calculate, startDate2calculate.AddDays(1), msSQL);
        }

        // ReCalculateKPIs
        // Recalculate KPIs
        // @param startDate2calculate: Start date
        // @param endDate2calculate: End date
        // @param msSQL: MsSQL settings part
        // @return JsonOutputSummary
        private JsonOutputSummary ReCalculateKPIs(DateTime startDate2calculate, DateTime endDate2calculate, MsSQL msSQL)
        {
            JsonOutputSummary jsonOutputSummary = new();
            DateTime nowFull = DateTime.UtcNow;
            DateTime now = new(nowFull.Year, nowFull.Month, nowFull.Day, nowFull.Hour, 0, 0);
            DataMssql dataMssql = new(msSQL);

            startDate2calculate = GetBaseTime(startDate2calculate);

            JsonOutputAreaMachineModuleStation lastStationMachineAreas = new();
            if (IsLongtermCalculation())
            {
                DataSnowflake dataSnowflake = new(appSettings.Settings?.settingsKpiCalculator.snowflake.Find(x => x.name == msSQL.snowflakeSourceNameForLongtermKpiCalculation));
                _logger.Log(KBBasics.LogLevel.INFO, "ReCalculateKPIs DB: " + msSQL.name);
                JsonOutputListOfAreasMachinesModulesStations stationMachineAreas = GetListOfAreasMachinesModulesStations(dataMssql);
                foreach (var stationMachineArea in stationMachineAreas.AreasMachinesModulesStations)
                {
                    DateTime date2calculate = startDate2calculate;
                    while (date2calculate < now && date2calculate < endDate2calculate)
                    {
                        _logger.Log(KBBasics.LogLevel.INFO, "ReCalculateKPIs: " + stationMachineArea.Station + "/" + stationMachineArea.Module + "/" + stationMachineArea.Machine + "/" + stationMachineArea.Area);
                        CalculationTimeSlot calculationTimeSlot = GetCurrentCalculationTimeSlot(dataMssql, date2calculate, stationMachineArea);
                        if (calculationTimeSlot.DoCalculation)
                        {
                            jsonOutputSummary = DoLongtermCalculation(jsonOutputSummary, dataSnowflake, dataMssql, calculationTimeSlot.Start, calculationTimeSlot.End, stationMachineArea, _calculateKPIsTypeNameForDB);
                            CalculationTimeSlot calculationTimeSlotEnd = GetCurrentCalculationTimeSlot(dataMssql, date2calculate, stationMachineArea, false);
                            if (calculationTimeSlotEnd.DoCalculation)
                            {
                                date2calculate = calculationTimeSlotEnd.End;
                            }
                            else
                            {
                                break;
                            }
                        }
                        else
                        {
                            break;
                        }
                    }
                }
            }
            else
            {
                _logger.Log(KBBasics.LogLevel.INFO, "ReCalculateKPIs DB: " + msSQL.name);
                JsonOutputListOfAreasMachinesModulesStations stationMachineAreas = GetListOfAreasMachinesModulesStations(dataMssql);
                foreach (var stationMachineArea in stationMachineAreas.AreasMachinesModulesStations)
                {
                    DateTime date2calculate = startDate2calculate;
                    while (date2calculate < now && date2calculate < endDate2calculate)
                    {
                        _logger.Log(KBBasics.LogLevel.INFO, "ReCalculateKPIs: " + stationMachineArea.Station + "/" + stationMachineArea.Module + "/" + stationMachineArea.Machine + "/" + stationMachineArea.Area);
                        CalculationTimeSlot calculationTimeSlot = GetCurrentCalculationTimeSlot(dataMssql, date2calculate, stationMachineArea);
                        if (calculationTimeSlot.DoCalculation)
                        {
                            jsonOutputSummary = DoCalculation(jsonOutputSummary, dataMssql, calculationTimeSlot.Start, calculationTimeSlot.End, stationMachineArea, msSQL.KPICalculation.TimeoutForKPICalculationInSeconds);
                            CalculationTimeSlot calculationTimeSlotEnd = GetCurrentCalculationTimeSlot(dataMssql, date2calculate, stationMachineArea, false);
                            if (calculationTimeSlotEnd.DoCalculation)
                            {
                                date2calculate = calculationTimeSlotEnd.End;
                            }
                            else
                            {
                                break;
                            }
                        }
                        else
                        {
                            break;
                        }
                    }
                }
            }

            return jsonOutputSummary;
        }

        // DoCalculation
        // Calculate KPIs for machines or stations
        // @param jsonOutputSummary: JsonOutputSummary
        // @param dataMssql: DataMssql DB connection
        // @param shiftStartOfDayUtcBased: Start of the period
        // @param shiftEndOfDayUtcBased: End of the period
        // @param stationMachineArea: JsonOutputAreaMachineStation
        // @param timeoutInSeconds: Timeout in seconds
        // @return JsonOutputSummary
        private JsonOutputSummary DoCalculation(JsonOutputSummary jsonOutputSummary, DataMssql dataMssql, DateTime shiftStartOfDayUtcBased, DateTime shiftEndOfDayUtcBased, JsonOutputAreaMachineModuleStation stationMachineArea, int timeoutInSeconds) 
        {
            JsonOutputSimpleState dbResult;
            string message;
            if (CalculationType == CalculationType.MACHINE)
            {
                dbResult = Data.CalculateKPIs.CalulateKPIsForSingleMachine(dataMssql, shiftStartOfDayUtcBased, shiftEndOfDayUtcBased, _calculateKPIsTypeNameForDB, stationMachineArea.Machine, timeoutInSeconds);
                message = CalculationName + ": Result for start of " + stationMachineArea.Machine + ", start " + shiftStartOfDayUtcBased.ToString() + " and end " + shiftEndOfDayUtcBased.ToString() + ": " + dbResult.State;
            }
            else if (CalculationType == CalculationType.STATION)
            {
                dbResult = Data.CalculateKPIs.CalulateKPIsForSingleStation(dataMssql, shiftStartOfDayUtcBased, shiftEndOfDayUtcBased, _calculateKPIsTypeNameForDB, stationMachineArea.Machine, stationMachineArea.Station, timeoutInSeconds);
                message = CalculationName + ": Result for start of " + stationMachineArea.Station + "("+ stationMachineArea.Machine+ "), start " + shiftStartOfDayUtcBased.ToString() + " and end " + shiftEndOfDayUtcBased.ToString() + ": " + dbResult.State;
            }
            else if (CalculationType == CalculationType.AREA)
            {
                dbResult = Data.CalculateKPIs.CalulateKPIsForSingleArea(dataMssql, shiftStartOfDayUtcBased, shiftEndOfDayUtcBased, _calculateKPIsTypeNameForDB, stationMachineArea.Area, timeoutInSeconds);
                message = CalculationName + ": Result for start of " + stationMachineArea.Area + ", start " + shiftStartOfDayUtcBased.ToString() + " and end " + shiftEndOfDayUtcBased.ToString() + ": " + dbResult.State;
            }
            else if (CalculationType == CalculationType.MODULE)
            {
                dbResult = Data.CalculateKPIs.CalulateKPIsForSingleModule(dataMssql, shiftStartOfDayUtcBased, shiftEndOfDayUtcBased, _calculateKPIsTypeNameForDB, stationMachineArea.Module, timeoutInSeconds);
                message = CalculationName + ": Result for start of " + stationMachineArea.Module + ", start " + shiftStartOfDayUtcBased.ToString() + " and end " + shiftEndOfDayUtcBased.ToString() + ": " + dbResult.State;
            }
            else if (CalculationType == CalculationType.PLANT)
            {
                dbResult = Data.CalculateKPIs.CalulateKPIsForSinglePlant(dataMssql, shiftStartOfDayUtcBased, shiftEndOfDayUtcBased, _calculateKPIsTypeNameForDB, stationMachineArea.Plant, timeoutInSeconds);
                message = CalculationName + ": Result for start of " + stationMachineArea.Module + ", start " + shiftStartOfDayUtcBased.ToString() + " and end " + shiftEndOfDayUtcBased.ToString() + ": " + dbResult.State;
            }
            else
            {
                throw new NotImplementedException();
            }
            
            jsonOutputSummary.OutputForProcedureCalls.Add(dbResult);
            if (dbResult.State == "OK")
            {
                jsonOutputSummary.OkCount++;
                _logger.Log(KBBasics.LogLevel.INFO, message);
            }
            else
            {
                jsonOutputSummary.NokCount++;
                _logger.Log(KBBasics.LogLevel.WARNING, message);
            }

            return jsonOutputSummary;

        }

        // DoLongtermCalculation
        // Calculate longterm KPIs for machines or stations
        // @param jsonOutputSummary: JsonOutputSummary
        // @param dataSnowflake: DataSnowflake DB connection
        // @param dataMssql: DataMssql DB connection
        // @param shiftStartOfDayUtcBased: Start of the period
        // @param shiftEndOfDayUtcBased: End of the period
        // @param stationMachineArea: JsonOutputAreaMachineStation
        // @param calculationBase: Calculation base
        // @return JsonOutputSummary
        private JsonOutputSummary DoLongtermCalculation(JsonOutputSummary jsonOutputSummary, DataSnowflake dataSnowflake, DataMssql dataMssql, DateTime shiftStartOfDayUtcBased, DateTime shiftEndOfDayUtcBased, JsonOutputAreaMachineModuleStation stationMachineModuleArea, string calculationBase)
        {
            JsonOutputSimpleState dbResult;
            string message;
            string stationMachineModuleAreaName;
            if (CalculationType == CalculationType.MACHINE)
            {
                stationMachineModuleAreaName = stationMachineModuleArea.Machine;
            }
            else if (CalculationType == CalculationType.STATION)
            {
                stationMachineModuleAreaName = stationMachineModuleArea.Station;
            }
            else if (CalculationType == CalculationType.AREA)
            {
                stationMachineModuleAreaName = stationMachineModuleArea.Area;
            }
            else if (CalculationType == CalculationType.MODULE)
            {
                stationMachineModuleAreaName = stationMachineModuleArea.Module;
            }
            else if (CalculationType == CalculationType.PLANT)
            {
                stationMachineModuleAreaName = stationMachineModuleArea.Plant;
            }
            else
            {
                throw new NotImplementedException();
            }

            dbResult = Data.CalculateKPIs.CalulateLongtermKPIs(dataSnowflake, dataMssql, stationMachineModuleAreaName, shiftStartOfDayUtcBased, shiftEndOfDayUtcBased, calculationBase);
            message = CalculationName + ": Result for start of longtermcalculation (" + calculationBase + ") " + stationMachineModuleAreaName + ", start " + shiftStartOfDayUtcBased.ToString() + " and end " + shiftEndOfDayUtcBased.ToString() + ": " + dbResult.State;

            jsonOutputSummary.OutputForProcedureCalls.Add(dbResult);
            if (dbResult.State == "OK")
            {
                jsonOutputSummary.OkCount++;
                _logger.Log(KBBasics.LogLevel.INFO, message);
            }
            else
            {
                jsonOutputSummary.NokCount++;
                _logger.Log(KBBasics.LogLevel.WARNING, message);
            }

            return jsonOutputSummary;

        }

        // IsLongtermCalculation
        // Check if the calculation is longterm
        // @return Boolean
        public Boolean IsLongtermCalculation()
        {
            if (CalculateKPIsType == CalculateKPIsType.WEEKLY || CalculateKPIsType == CalculateKPIsType.MONTHLY || CalculateKPIsType == CalculateKPIsType.YEARLY)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // IsFiveMinuteJob
        // Check if the calculation is a five minute job
        // @return Boolean
        public Boolean IsFiveMinuteJob()
        {
            if (CalculateKPIsType == CalculateKPIsType.HOURLY || CalculateKPIsType == CalculateKPIsType.SHIFT || CalculateKPIsType == CalculateKPIsType.DAILY)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // IsOneHourJob
        // Check if the calculation is a one hour job
        // @return Boolean
        public Boolean IsOneHourJob()
        {
            if (CalculateKPIsType == CalculateKPIsType.WEEKLY || CalculateKPIsType == CalculateKPIsType.MONTHLY)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // IsOneDayJob
        // Check if the calculation is a one day job
        // @return Boolean
        public Boolean IsOneDayJob()
        {
            if (CalculateKPIsType == CalculateKPIsType.YEARLY)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // IsFiveMinuteJob
        // Check if the calculation is a five minute job
        // @param msSQL: MsSQL settings part
        // @return Boolean
        public Boolean IsFiveMinuteJob(MsSQL msSQL)
        {
            if ((CalculateKPIsType == CalculateKPIsType.HOURLY && msSQL.KPICalculation.enableHourlyKPIs) || (CalculateKPIsType == CalculateKPIsType.DAILY && msSQL.KPICalculation.enableDailyKPIs) || (CalculateKPIsType == CalculateKPIsType.SHIFT && msSQL.KPICalculation.enableShiftKPIs))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // IsOneHourJob
        // Check if the calculation is a one hour job
        // @param msSQL: MsSQL settings part
        // @return Boolean
        public Boolean IsOneHourJob(MsSQL msSQL)
        {
            if ((CalculateKPIsType == CalculateKPIsType.WEEKLY && msSQL.KPICalculation.enableWeeklyKPIs) || (CalculateKPIsType == CalculateKPIsType.MONTHLY && msSQL.KPICalculation.enableMonthlyPIs))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // IsOneDayJob
        // Check if the calculation is a one day job
        // @param msSQL: MsSQL settings part
        // @return Boolean
        public Boolean IsOneDayJob(MsSQL msSQL)
        {
            if (CalculateKPIsType == CalculateKPIsType.YEARLY && msSQL.KPICalculation.enableYearlyKPIs)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // GetUtcOffset
        // Get the UTC offset
        // @param timeZone: Time zone
        // @param dateTime: Date time
        // @return int
        public int GetUtcOffset(string timeZone, DateTime dateTime)
        {
            TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById(timeZone);
            int baseUtcOffset =(int)timeZoneInfo.BaseUtcOffset.TotalMinutes;
            if(timeZoneInfo.IsDaylightSavingTime(dateTime))
            {
                baseUtcOffset += 60;
            }
            return baseUtcOffset;
        }
    }
}
