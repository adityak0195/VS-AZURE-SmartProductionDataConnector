using KBBasics.SetupForFileSystem;
using KpiCalculator.Data.Dataprovider;
using KpiCalculator.Data;
using KpiCalculator.JSON;
using System.Timers;
using Microsoft.Extensions.Hosting;
using System.Threading.Tasks;
using System.Threading;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System;

namespace KpiCalculator.Logic
{

    public class CalculatorWorker : BackgroundService
    {
        private readonly ILogger<CalculatorWorker> _logger;
        private readonly List<WorkerThreadGroup> _workerThreadGroups = new();
        private readonly AppSettings _appSettings;

        // WorkerThreadGroup
        // Class for storing threads
        // @param CalculateKPIs: KpiCalculator.Logic.CalculateKPIs
        // @param Threads: List of threads
        public class WorkerThreadGroup
        {
            public KpiCalculator.Logic.CalculateKPIs CalculateKPIs;
            public List<Thread> Threads = new List<Thread>();
        }

        // Constructor
        // @param logger: Logger
        public CalculatorWorker(ILogger<CalculatorWorker> logger, string stagingLevel)
        {
            _logger = logger;
            _appSettings = new(stagingLevel);

            if (_appSettings == null || _appSettings.Settings == null)
            {
                throw new Exception("No settings found in settings file");
            }

            // Setup Threads
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.HOURLY, CalculationType.MACHINE, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.HOURLY, CalculationType.STATION, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.HOURLY, CalculationType.AREA, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.HOURLY, CalculationType.MODULE, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.HOURLY, CalculationType.PLANT, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.SHIFT, CalculationType.MACHINE, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.SHIFT, CalculationType.STATION, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.SHIFT, CalculationType.AREA, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.SHIFT, CalculationType.MODULE, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.SHIFT, CalculationType.PLANT, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.DAILY, CalculationType.MACHINE, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.DAILY, CalculationType.STATION, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.DAILY, CalculationType.AREA, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.DAILY, CalculationType.MODULE, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.DAILY, CalculationType.PLANT, stagingLevel) });

            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.WEEKLY, CalculationType.MACHINE, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.WEEKLY, CalculationType.STATION, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.WEEKLY, CalculationType.AREA, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.WEEKLY, CalculationType.MODULE, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.WEEKLY, CalculationType.PLANT, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.MONTHLY, CalculationType.MACHINE, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.MONTHLY, CalculationType.STATION, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.MONTHLY, CalculationType.AREA, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.MONTHLY, CalculationType.MODULE, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.MONTHLY, CalculationType.PLANT, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.YEARLY, CalculationType.MACHINE, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.YEARLY, CalculationType.STATION, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.YEARLY, CalculationType.AREA, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.YEARLY, CalculationType.MODULE, stagingLevel) });
            _workerThreadGroups.Add(new WorkerThreadGroup() { CalculateKPIs = new(_logger, CalculateKPIsType.YEARLY, CalculationType.PLANT, stagingLevel) });
        }

        // StartCalculateKPIsThread
        // Start a new thread for calculating KPIs
        // @param db: MsSQL settings part
        // @param workerThreadGroup: WorkerThreadGroup 
        // @return void
        private void StartCalculateKPIsThread(MsSQL db, WorkerThreadGroup workerThreadGroup)
        {
            try
            {
                if (workerThreadGroup != null)
                {
                    _logger.LogInformation(GetWorkerThreadName(db, workerThreadGroup) + " CalculateKPIsThread is starting.");
                    Thread calculateKPIsThread = new Thread(() => workerThreadGroup.CalculateKPIs.DoCalculation(db))
                    {
                        Name = GetWorkerThreadName(db, workerThreadGroup),
                        IsBackground = true
                    };
                    calculateKPIsThread.Start();
                    workerThreadGroup.Threads.Add(calculateKPIsThread);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(GetWorkerThreadName(db, workerThreadGroup) + "Thread cannot be started:" + ex.ToString());
            }
        }

        // GetWorkerThreadName
        // Get the name of the worker thread
        // @param db: MsSQL settings part
        // @param workerThreadGroup: WorkerThreadGroup
        private string GetWorkerThreadName(MsSQL db, WorkerThreadGroup workerThreadGroup)
        {
            return workerThreadGroup.CalculateKPIs.CalculationName + db.name;
        }

        // OnFiveMinutesTimer
        // Timer event for starting the KPI calculation threads
        // @param sender: object
        // @param args: ElapsedEventArgs
        // @return void
        public void OnFiveMinutesTimer(object? sender, ElapsedEventArgs? args)
        {
            try
            {
                _logger.LogInformation("OnFiveMinutesTimer is starting.");
                foreach(var workerThreadGroup in _workerThreadGroups)
                {
                    if (workerThreadGroup != null && workerThreadGroup.CalculateKPIs != null && workerThreadGroup.CalculateKPIs.IsFiveMinuteJob())
                    {
                        ExecuteTimer(workerThreadGroup, "OnFiveMinutesTimer");
                    }
                }
            }
            catch (Exception ex) 
            {
                _logger.LogError("OnFiveMinutesTimer cannot be executed:" + ex.ToString());
            }
        }

        // OnOneHourTimer
        // Timer event for starting the KPI calculation threads
        // @param sender: object
        // @param args: ElapsedEventArgs
        // @return void
        public void OnOneHourTimer(object? sender, ElapsedEventArgs? args)
        {
            try
            {
                _logger.LogInformation("OnOneHourTimer is starting.");
                foreach (var workerThreadGroup in _workerThreadGroups)
                {
                    if (workerThreadGroup != null && workerThreadGroup.CalculateKPIs != null && workerThreadGroup.CalculateKPIs.IsOneHourJob())
                    {
                        ExecuteTimer(workerThreadGroup, "OnOneHourTimer");
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("OnOneHourTimer cannot be executed:" + ex.ToString());
            }
        }

        // OnOneDayTimer
        // Timer event for starting the KPI calculation threads
        // @param sender: object
        // @param args: ElapsedEventArgs
        // @return void
        public void OnOneDayTimer(object? sender, ElapsedEventArgs? args)
        {
            try
            {
                _logger.LogInformation("OnOneDayTimer is starting.");
                foreach (var workerThreadGroup in _workerThreadGroups)
                {
                    if (workerThreadGroup != null && workerThreadGroup.CalculateKPIs != null && workerThreadGroup.CalculateKPIs.IsOneDayJob())
                    {
                        ExecuteTimer(workerThreadGroup, "OnOneDayTimer");
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("OnOneDayTimer cannot be executed:" + ex.ToString());
            }
        }

        // ExecuteTimer
        // Execute the timer
        // @param workerThreadGroup: WorkerThreadGroup
        // @param name: string
        // @return void
        private void ExecuteTimer(WorkerThreadGroup workerThreadGroup, string name)
        {
            if (_appSettings.Settings != null)
            {
                _logger.LogInformation(name + " Threadgroup " + workerThreadGroup.CalculateKPIs.CalculationName + " is starting.");
                foreach (var db in _appSettings.Settings.settingsKpiCalculator.mssql)
                {
                    if (db != null)
                    {
                       try
                       {
                           Thread? workerThread = workerThreadGroup.Threads.Find(thread => thread.Name == GetWorkerThreadName(db, workerThreadGroup));
                           if (workerThread != null && !workerThread.IsAlive)
                           {
                               workerThreadGroup.Threads.Remove(workerThread);
                           }
                           if (workerThread == null || (workerThread != null && !workerThread.IsAlive))
                           {
                               _logger.LogInformation(name + " Triggering Thread");
                               StartCalculateKPIsThread(db, workerThreadGroup);
                           }
                       }
                       catch (Exception ex)
                       {
                           _logger.LogError(name + " cannot be executed for " + workerThreadGroup.CalculateKPIs.CalculationName + ":" + ex.ToString());
                       }
                    }
                }
            }
        }

        // ExecuteAsync
        // Main worker function
        // @param stoppingToken: CancellationToken
        // @return Task
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            try
            {

                // Set up a timer.
                System.Timers.Timer fiveMinutesTimer = new System.Timers.Timer { Interval = 1000 * 60 * 5 /* 5 minutes*/ };
                System.Timers.Timer oneHourTimer = new System.Timers.Timer { Interval = 1000 * 60 * 60 /* 1 hour*/ };
                System.Timers.Timer oneDayTimer = new System.Timers.Timer { Interval = 1000 * 60 * 60 * 24 /* 1 day*/ };
                fiveMinutesTimer.Elapsed += new ElapsedEventHandler(OnFiveMinutesTimer);
                oneHourTimer.Elapsed += new ElapsedEventHandler(OnOneHourTimer);
                oneDayTimer.Elapsed += new ElapsedEventHandler(OnOneDayTimer);
                fiveMinutesTimer.Start();
                oneHourTimer.Start();
                oneDayTimer.Start();

                OnFiveMinutesTimer(null, null);
                OnOneHourTimer(null, null);
                OnOneDayTimer(null, null);

                _logger.LogInformation("CalculatorWorker is starting.");
            }
            catch (Exception ex)
            {
                _logger.LogError("CalculatorWorker cannot be started:" + ex.ToString());
            }

            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    _logger.LogInformation("CalculatorWorker alive");
                    await Task.Delay(1000 * 60, stoppingToken);
                }
                catch (Exception) { }
            }
        }

    }
}
