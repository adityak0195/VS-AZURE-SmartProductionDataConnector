using Microsoft.Extensions.Logging;

namespace KpiCalculator.Logic
{

    public class CalculatorWorkerTEST : CalculatorWorker
    {
        // Constructor
        // @param logger: Logger
        public CalculatorWorkerTEST(ILogger<CalculatorWorker> logger) : base(logger, "TEST")
        {
        }
    }
}
