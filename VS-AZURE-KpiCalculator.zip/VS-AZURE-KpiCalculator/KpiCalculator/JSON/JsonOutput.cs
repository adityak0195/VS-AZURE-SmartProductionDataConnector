﻿using System;
using System.Collections.Generic;

namespace KpiCalculator.JSON
{
    // JsonOutputTestConnection
    // Class for storing the output of a test connection
    public class JsonOutputTestConnection
    {
        public string Name;
        public string Server;
        public string Database;
        public string User;
        public string Warehouse;
        public string Schema;
        public string Role;
        public string Account;
        public long JavaDate;
        public DateTime Date;
        public string Message;
        public string state;
    }

    // JsonOutputSimpleState
    // Class for storing the output of a procedure call
    public class JsonOutputSimpleState
    {
        public string State;
        public string Message;
    }

    // JsonOutputSummary
    // Class for storing the summary of the output
    public class JsonOutputSummary
    {
        public List<JsonOutputSimpleState> OutputForProcedureCalls = new();
        public int OkCount = 0;
        public int NokCount = 0;
    }

    // JsonOutputListOfAreasMachinesModulesStations
    // Class for storing a list of areas, machines and stations
    public class JsonOutputListOfAreasMachinesModulesStations
    {
        public List<JsonOutputAreaMachineModuleStation> AreasMachinesModulesStations = new();
        public string State;
    }

    // JsonOutputAreaMachineStation
    // Class for storing an area, machine and station
    public class JsonOutputAreaMachineModuleStation
    {
        public string Plant;
        public string Area;
        public string Machine;
        public string Module;
        public string Station;
        public string Type;
        public double DayOffset;
        public string ServerTimeZoneDB;
    }

    // JsonOutputListOfShiftDefinitions
    // Class for storing a list of shifts
    public class JsonOutputListOfShiftDefinitions
    {
        public List<JsonOutputShiftDefinition> ShiftDefinitions = new();
        public string State;
    }

    // JsonOutputShiftDefinition
    // Class for storing a shift
    public class JsonOutputShiftDefinition
    {
        public string Machine;
        public string ShiftName;
        public DateTime StartTime;
        public DateTime EndTime;
    }

    // JsonOutputKPIValue
    // Class for storing a KPI Value
    public class JsonOutputKPIValue
    {
        public string Machine;
        public string KPIName;
        public string KPICalculationBase;
        public string KPITimeBase;
        public DateTime KPIStartTime;
        public DateTime KPIEndTime;
        public decimal KPIFloatValue;
    }

    // JsonOutputKPIValues
    // Class for storing a list of KPI values
    public class JsonOutputKPIValues
    {
        public List<JsonOutputKPIValue> KPIValues = new();
        public string State;
    }
}
