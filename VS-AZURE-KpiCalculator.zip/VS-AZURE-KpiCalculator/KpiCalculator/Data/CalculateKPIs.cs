﻿using KpiCalculator.Data.Dataprovider;
using KpiCalculator.JSON;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KpiCalculator.Data
{
    // CalculateKPIs
    // Class for calculating KPIs
    public class CalculateKPIs
    {
        // CalulateKPIsForSingleMachine
        // Calculate KPIs for a single machine
        // @param dataconnection: Data connection
        // @param shiftStartOfDayUtcBased: Start of the day
        // @param shiftEndOfDayUtcBased: End of the day
        // @param calculationBase: Calculation base
        // @param machine: Machine
        // @return JsonOutputSimpleState
        public static JsonOutputSimpleState CalulateKPIsForSingleMachine(IData dataconnection, DateTime shiftStartOfDayUtcBased, DateTime shiftEndOfDayUtcBased, string calculationBase, string machine, int timeoutInSeconds)
        {
            return dataconnection.CalulateKPIsForSingleMachine(shiftStartOfDayUtcBased, shiftEndOfDayUtcBased, calculationBase, machine, timeoutInSeconds);
        }

        // CalulateKPIsForSingleArea
        // Calculate KPIs for a single machine
        // @param dataconnection: Data connection
        // @param shiftStartOfDayUtcBased: Start of the day
        // @param shiftEndOfDayUtcBased: End of the day
        // @param calculationBase: Calculation base
        // @param area: Area
        // @return JsonOutputSimpleState
        public static JsonOutputSimpleState CalulateKPIsForSingleArea(IData dataconnection, DateTime shiftStartOfDayUtcBased, DateTime shiftEndOfDayUtcBased, string calculationBase, string area, int timeoutInSeconds)
        {
            return dataconnection.CalulateKPIsForSingleArea(shiftStartOfDayUtcBased, shiftEndOfDayUtcBased, calculationBase, area, timeoutInSeconds);
        }

        // CalulateKPIsForSingleMachine
        // Calculate KPIs for a single machine
        // @param dataconnection: Data connection
        // @param shiftStartOfDayUtcBased: Start of the day
        // @param shiftEndOfDayUtcBased: End of the day
        // @param calculationBase: Calculation base
        // @param module: Module
        // @return JsonOutputSimpleState
        public static JsonOutputSimpleState CalulateKPIsForSingleModule(IData dataconnection, DateTime shiftStartOfDayUtcBased, DateTime shiftEndOfDayUtcBased, string calculationBase, string module, int timeoutInSeconds)
        {
            return dataconnection.CalulateKPIsForSingleModule(shiftStartOfDayUtcBased, shiftEndOfDayUtcBased, calculationBase, module, timeoutInSeconds);
        }

        // CalulateKPIsForSinglePlant
        // Calculate KPIs for a single plant
        // @param dataconnection: Data connection
        // @param shiftStartOfDayUtcBased: Start of the day
        // @param shiftEndOfDayUtcBased: End of the day
        // @param calculationBase: Calculation base
        // @param module: Module
        // @return JsonOutputSimpleState
        public static JsonOutputSimpleState CalulateKPIsForSinglePlant(IData dataconnection, DateTime shiftStartOfDayUtcBased, DateTime shiftEndOfDayUtcBased, string calculationBase, string plant, int timeoutInSeconds)
        {
            return dataconnection.CalulateKPIsForSinglePlant(shiftStartOfDayUtcBased, shiftEndOfDayUtcBased, calculationBase, plant, timeoutInSeconds);
        }

        // CalulateKPIsForSingleStation
        // Calculate KPIs for a single station
        // @param dataconnection: Data connection
        // @param shiftStartOfDayUtcBased: Start of the day
        // @param shiftEndOfDayUtcBased: End of the day
        // @param calculationBase: Calculation base
        // @param machine: Machine
        // @param station: Station
        // @return JsonOutputSimpleState
        public static JsonOutputSimpleState CalulateKPIsForSingleStation(IData dataconnection, DateTime shiftStartOfDayUtcBased, DateTime shiftEndOfDayUtcBased, string calculationBase, string machine, string station, int timeoutInSeconds)
        {
            return dataconnection.CalulateKPIsForSingleStation(shiftStartOfDayUtcBased, shiftEndOfDayUtcBased, calculationBase, machine, station, timeoutInSeconds);
        }

        // CalulateLongtermKPIs
        // Calculate longterm KPIs
        // @param sourcedataconnection: Source data connection
        // @param targetdataconnection: Target data connection
        // @param areaMachineModuleStation: Area Machine Module Station
        // @param startDateTime: Start date and time
        // @param endDateTime: End date and time
        // @param calculationBase: Calculation base
        // @return JsonOutputSimpleState
        public static JsonOutputSimpleState CalulateLongtermKPIs(IData sourcedataconnection, IData targetdataconnection, string areaMachineModuleStation, DateTime startDateTime, DateTime endDateTime, string calculationBase)
        {
            JsonOutputKPIValues jsonOutputKPIValues = sourcedataconnection.GetKPIValues(areaMachineModuleStation, startDateTime, endDateTime, "day");
            if (jsonOutputKPIValues.State == "OK")
            {
                return targetdataconnection.SetKPIValues(jsonOutputKPIValues, areaMachineModuleStation, startDateTime, endDateTime, calculationBase);
            }
            return new JsonOutputSimpleState() { State = jsonOutputKPIValues.State };

        }

    }
}
