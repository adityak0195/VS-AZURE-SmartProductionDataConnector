﻿using KpiCalculator.Data.Dataprovider;
using KpiCalculator.JSON;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KpiCalculator.Data
{
    public class Shifts
    {
        // GetListOfShiftDefinitions
        // Get a list of shift definitions
        // @param dataconnection: IData
        // @param machine: Machine
        // @param startDateTime: Start date and time
        // @param endDateTime: End date and time
        // @return JsonOutputListOfShiftDefinitions
        public static JsonOutputListOfShiftDefinitions GetListOfShiftDefinitions(IData dataconnection, string machine, DateTime startDateTime, DateTime endDateTime)
        {
            return dataconnection.GetListOfShiftDefinitions(machine, startDateTime, endDateTime);
        }

        // GetCurrentOrNextShiftDefinition
        // Get Current Or Next Shift Definitions
        // @param dataconnection: IData
        // @param machine: Machine
        // @param referenceTime: End date and time
        // @return JsonOutputListOfShiftDefinitions
        public static JsonOutputListOfShiftDefinitions GetCurrentOrNextShiftDefinition(IData dataconnection, string machine, DateTime referenceTime)
        {
            return dataconnection.GetCurrentOrNextShiftDefinition(machine, referenceTime);
        }

        // GetLastShiftDefinition
        // Get Last Shift Definition
        // @param dataconnection: IData
        // @param machine: Machine
        // @param referenceTime: End date and time
        // @return JsonOutputListOfShiftDefinitions
        public static JsonOutputListOfShiftDefinitions GetLastShiftDefinition(IData dataconnection, string machine, DateTime referenceTime)
        {
            return dataconnection.GetLastShiftDefinition(machine, referenceTime);
        }
    }
}
