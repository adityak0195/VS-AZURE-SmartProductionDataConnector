﻿using KpiCalculator.JSON;
using KpiCalculator.Data.Dataprovider;

namespace KpiCalculator.Data
{
    // TestConnection
    // Class for testing a connection
    public class TestConnection
    {
        // GetResult
        // Get the result of a test connection
        // @param dataconnection: Data connection
        // @return JsonOutputTestConnection
        public static JsonOutputTestConnection GetResult(IData dataconnection)
        {
            return dataconnection.TestConnection();
        }
    }
}
