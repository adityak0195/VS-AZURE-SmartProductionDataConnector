﻿using KBBasics.SetupForFileSystem;
using KpiCalculator.JSON;
using System.Collections.Generic;
using System;
using System.Data.SqlClient;
using System.Reflection.PortableExecutable;
using static System.Collections.Specialized.BitVector32;
using static log4net.Appender.RollingFileAppender;

namespace KpiCalculator.Data.Dataprovider
{
    // DataMssql
    // Class for handling data from MSSQL
    public class DataMssql : Data<SqlConnection>, IData
    {
        private readonly MsSQL _msSQL;

        // Constructor
        // @param dBName: Name of the database
        // @param settings: AppSettings
        public DataMssql(MsSQL msSQL) : base()
        {
            _msSQL = msSQL;

            try
            {
                string connString = @"Data Source=" + _msSQL.server + ";Initial Catalog="
                            + _msSQL.database + ";Persist Security Info=True;User ID=" + _msSQL.user + ";Password=" + _msSQL.passwort;
                conn.ConnectionString = connString;
                conn.Open();
            }
            catch (Exception e)
            {
                Logger.Log(KBBasics.LogLevel.ERROR, e.Message);
            }
        }

        // CalulateKPIsForSingleMachine
        // Calculate KPIs for a single machine
        // @param shiftStartOfDayUtcBased: Start of the period
        // @param shiftEndOfDayUtcBased: End of the period
        // @param calculationBase: Calculation base
        // @param machine: Machine
        // @return JsonOutputSimpleState
        public JsonOutputSimpleState CalulateKPIsForSingleMachine(DateTime shiftStartOfDayUtcBased, DateTime shiftEndOfDayUtcBased, string calculationBase, string module, int timeoutInSeconds)
        {
            List<ProcedureProperties> procedureProperties = new()
            {
                new ProcedureProperties { PropertyName = "@StartDate", PropertyValue = shiftStartOfDayUtcBased },
                new ProcedureProperties { PropertyName = "@EndDate", PropertyValue = shiftEndOfDayUtcBased },
                new ProcedureProperties { PropertyName = "@CalculationBase", PropertyValue = calculationBase },
                new ProcedureProperties { PropertyName = "@Machine", PropertyValue = module }
            };
            return CallProcedure("KPI_CALCULATOR_CalulateKPIsForSingleMachine", procedureProperties, timeoutInSeconds);
        }

        // CalulateKPIsForSingleArea
        // Calculate KPIs for a single area
        // @param shiftStartOfDayUtcBased: Start of the period
        // @param shiftEndOfDayUtcBased: End of the period
        // @param calculationBase: Calculation base
        // @param area: Area
        // @return JsonOutputSimpleState
        public JsonOutputSimpleState CalulateKPIsForSingleArea(DateTime shiftStartOfDayUtcBased, DateTime shiftEndOfDayUtcBased, string calculationBase, string area, int timeoutInSeconds)
        {
            List<ProcedureProperties> procedureProperties = new()
            {
                new ProcedureProperties { PropertyName = "@StartDate", PropertyValue = shiftStartOfDayUtcBased },
                new ProcedureProperties { PropertyName = "@EndDate", PropertyValue = shiftEndOfDayUtcBased },
                new ProcedureProperties { PropertyName = "@CalculationBase", PropertyValue = calculationBase },
                new ProcedureProperties { PropertyName = "@Area", PropertyValue = area }
            };
            return CallProcedure("KPI_CALCULATOR_CalulateKPIsForSingleArea", procedureProperties, timeoutInSeconds);
        }

        // CalulateKPIsForSingleModule
        // Calculate KPIs for a single module
        // @param shiftStartOfDayUtcBased: Start of the period
        // @param shiftEndOfDayUtcBased: End of the period
        // @param calculationBase: Calculation base
        // @param module: Module
        // @return JsonOutputSimpleState
        public JsonOutputSimpleState CalulateKPIsForSingleModule(DateTime shiftStartOfDayUtcBased, DateTime shiftEndOfDayUtcBased, string calculationBase, string module, int timeoutInSeconds)
        {
            List<ProcedureProperties> procedureProperties = new()
            {
                new ProcedureProperties { PropertyName = "@StartDate", PropertyValue = shiftStartOfDayUtcBased },
                new ProcedureProperties { PropertyName = "@EndDate", PropertyValue = shiftEndOfDayUtcBased },
                new ProcedureProperties { PropertyName = "@CalculationBase", PropertyValue = calculationBase },
                new ProcedureProperties { PropertyName = "@Module", PropertyValue = module }
            };
            return CallProcedure("KPI_CALCULATOR_CalulateKPIsForSingleModule", procedureProperties, timeoutInSeconds);
        }


        // CalulateKPIsForSinglePlant
        // Calculate KPIs for a single plant
        // @param shiftStartOfDayUtcBased: Start of the period
        // @param shiftEndOfDayUtcBased: End of the period
        // @param calculationBase: Calculation base
        // @param plant: Plant
        // @return JsonOutputSimpleState
        public JsonOutputSimpleState CalulateKPIsForSinglePlant(DateTime shiftStartOfDayUtcBased, DateTime shiftEndOfDayUtcBased, string calculationBase, string plant, int timeoutInSeconds)
        {
            List<ProcedureProperties> procedureProperties = new()
            {
                new ProcedureProperties { PropertyName = "@StartDate", PropertyValue = shiftStartOfDayUtcBased },
                new ProcedureProperties { PropertyName = "@EndDate", PropertyValue = shiftEndOfDayUtcBased },
                new ProcedureProperties { PropertyName = "@CalculationBase", PropertyValue = calculationBase },
                new ProcedureProperties { PropertyName = "@Plant", PropertyValue = plant }
            };
            return CallProcedure("KPI_CALCULATOR_CalulateKPIsForSinglePlant", procedureProperties, timeoutInSeconds);
        }

        // CalulateKPIsForSingleStation
        // Calculate KPIs for a single station
        // @param shiftStartOfDayUtcBased: Start of the period
        // @param shiftEndOfDayUtcBased: End of the period
        // @param calculationBase: Calculation base
        // @param machine: Machine
        // @param station: Station
        // @return JsonOutputSimpleState
        public JsonOutputSimpleState CalulateKPIsForSingleStation(DateTime shiftStartOfDayUtcBased, DateTime shiftEndOfDayUtcBased, string calculationBase, string machine, string station, int timeoutInSeconds)
        {
            List<ProcedureProperties> procedureProperties = new()
            {
                new ProcedureProperties { PropertyName = "@StartDate", PropertyValue = shiftStartOfDayUtcBased },
                new ProcedureProperties { PropertyName = "@EndDate", PropertyValue = shiftEndOfDayUtcBased },
                new ProcedureProperties { PropertyName = "@CalculationBase", PropertyValue = calculationBase },
                new ProcedureProperties { PropertyName = "@Machine", PropertyValue = machine },
                new ProcedureProperties { PropertyName = "@Station", PropertyValue = station }
            };
            return CallProcedure("KPI_CALCULATOR_CalulateKPIsForSingleStation", procedureProperties, timeoutInSeconds);
        }

        // GetListOfAreasMachinesStations
        // Get a list of areas, machines and stations
        // @param query: Query
        // @return JsonOutputListOfAreasMachinesModulesStations
        public JsonOutputListOfAreasMachinesModulesStations GetListOfAreas()
        {
            return GetListOfAreasMachinesModulesStations("select plant, area, machine, station, module, type, offset, serverTimeZoneDB from KPI_CALCULATOR_GetAreasToCalculateKPIs();");
        }

        // GetListOfMachines
        // Get a list of machines
        // @return JsonOutputListOfAreasMachinesModulesStations
        public JsonOutputListOfAreasMachinesModulesStations GetListOfMachines()
        {
            return GetListOfAreasMachinesModulesStations("select plant, area, machine, station, module, type, offset, serverTimeZoneDB from KPI_CALCULATOR_GetMachinesToCalculateKPIs();");
        }

        // GetListOfStations
        // Get a list of stations
        // @return JsonOutputListOfAreasMachinesModulesStations
        public JsonOutputListOfAreasMachinesModulesStations GetListOfStations()
        {
            return GetListOfAreasMachinesModulesStations("select plant, area, machine, station, module, type, offset, serverTimeZoneDB from KPI_CALCULATOR_GetStationsToCalculateKPIs();");
        }

        // GetListOfPlants
        // Get a list of plants
        // @return JsonOutputListOfAreasMachinesModulesStations
        public JsonOutputListOfAreasMachinesModulesStations GetListOfPlants()
        {
            return GetListOfAreasMachinesModulesStations("select plant, area, machine, station, module, type, offset, serverTimeZoneDB from KPI_CALCULATOR_GetPlantsToCalculateKPIs();");
        }

        // GetListOfModules
        // Get a list of modules
        // @return JsonOutputListOfAreasMachinesModulesStations
        public JsonOutputListOfAreasMachinesModulesStations GetListOfModules()
        {
            return GetListOfAreasMachinesModulesStations("select plant, area, machine, station, module, type, offset, serverTimeZoneDB from KPI_CALCULATOR_GetModulesToCalculateKPIs();");
        }

        // GetListOfSShifts
        // Get a list of shiftss
        // @return JsonOutputListOfAreasMachinesModulesStations
        public JsonOutputListOfShiftDefinitions GetListOfShiftDefinitions(string machine, DateTime startDateTime, DateTime endDateTime)
        {
            return GetListOfShiftDefinitions("select machine, shiftName, startTime, endTime from KPI_CALCULATOR_GetShiftsListToCalculateKPIs"+
                "('"+machine+ "', convert(datetime2,'" + startDateTime.ToString("yyyy-MM-dd HH:mm:ss") + "',20), convert(datetime2,'" + endDateTime.ToString("yyyy-MM-dd HH:mm:ss") + "',20));");
        }

        // TestConnection
        // Tests a connection
        // @return JsonOutputTestConnection
        public JsonOutputTestConnection TestConnection()
        {
            JsonOutputTestConnection result = TestConnection("select convert(varchar(255),GETDATE());");
            result.Name += ": " + _msSQL.name;
            result.Server = _msSQL.server;
            result.Database = _msSQL.database;
            result.User = _msSQL.user;
            result.Message = "MSSQL " + result.Message;

            return result;
        }

        // GetCurrentOrNextShiftDefinition
        // Get the current or next shift definition
        // @param machine: Machine
        // @param referenceTime: Reference time
        // @return JsonOutputListOfShiftDefinitions
        public JsonOutputListOfShiftDefinitions GetCurrentOrNextShiftDefinition(string machine, DateTime referenceTime)
        {
            return GetListOfShiftDefinitions("select machine, shiftName, startTime, endTime from KPI_CALCULATOR_GetCurrentOrNextShiftToCalculateKPIs" +
                "('" + machine + "', convert(datetime2,'" + referenceTime.ToString("yyyy-MM-dd HH:mm:ss") + "',20));");
        }

        // GetLastShiftDefinition
        // Get the last shift definition
        // @param machine: Machine
        // @param referenceTime: Reference time
        // @return JsonOutputListOfShiftDefinitions
        public JsonOutputListOfShiftDefinitions GetLastShiftDefinition(string machine, DateTime referenceTime)
        {
            return GetListOfShiftDefinitions("select machine, shiftName, startTime, endTime from KPI_CALCULATOR_GetLastShiftToCalculateKPIs" +
                "('" + machine + "', convert(datetime2,'" + referenceTime.ToString("yyyy-MM-dd HH:mm:ss") + "',20));");
        }

        // GetKPIValues
        // Get KPI Values
        // @param machine: Machine
        // @param startDateTime: Start date and time
        // @param endDateTime: End date and time
        // @param calculationBase: Calculation base
        // @return JsonOutputKPIValues
        public JsonOutputKPIValues GetKPIValues(string machine, DateTime startDateTime, DateTime endDateTime, string calculationBase)
        {
            throw new NotImplementedException();
        }

        // SetKPIValues
        // Set KPI Values
        // @param jsonOutputKPIValues: JsonOutputKPIValues
        // @param areaMachineModuleStation: Area Machine Module Station
        // @param startDateTime: Start date and time
        // @param endDateTime: End date and time
        // @param calculationBase: Calculation base
        // @return JsonOutputSimpleState
        public JsonOutputSimpleState SetKPIValues(JsonOutputKPIValues jsonOutputKPIValues, string areaMachineModuleStation, DateTime startDateTime, DateTime endDateTime, string calculationBase)
        {
            string idForTempTable = Guid.NewGuid().ToString().Replace('-','_');
            int timeoutInSeconds = 300;
            JsonOutputSimpleState jsonOutputSimpleState;

            try
            {
                jsonOutputSimpleState = SetKPIValuesPreparation(idForTempTable, timeoutInSeconds);
                if (jsonOutputSimpleState.State == "OK")
                {
                    jsonOutputSimpleState = SetKPIValuesPrepareData(jsonOutputKPIValues, idForTempTable);
                    if (jsonOutputSimpleState.State == "OK")
                    {
                        jsonOutputSimpleState = SetKPIValuesExecution(areaMachineModuleStation, startDateTime, endDateTime, calculationBase, idForTempTable, timeoutInSeconds);
                    }
                }
            }
            finally
            {
                SetKPIValuesPostProcessing(idForTempTable, timeoutInSeconds);
            }

            return jsonOutputSimpleState;

        }

        // GetListOfAreasMachinesStations
        // Get a list of areas, machines and stations
        // @param query: Query
        // @return JsonOutputListOfAreasMachinesModulesStations
        private JsonOutputSimpleState SetKPIValuesPreparation(string idForTempTable, int timeoutInSeconds)
        {
            List<ProcedureProperties> procedureProperties = new()
            {
                new ProcedureProperties { PropertyName = "@Id", PropertyValue = idForTempTable }
            };
            return CallProcedure("KPI_CALCULATOR_CalculateSummedUpKPIs_Preparation", procedureProperties, timeoutInSeconds);
        }

        // GetListOfAreasMachinesStations
        // Get a list of areas, machines and stations
        // @param query: Query
        // @return JsonOutputListOfAreasMachinesModulesStations
        private JsonOutputSimpleState SetKPIValuesPostProcessing(string idForTempTable, int timeoutInSeconds)
        {
            List<ProcedureProperties> procedureProperties = new()
            {
                new ProcedureProperties { PropertyName = "@Id", PropertyValue = idForTempTable }
            };
            return CallProcedure("KPI_CALCULATOR_CalculateSummedUpKPIs_Postprocessing", procedureProperties, timeoutInSeconds);
        }

        // GetListOfAreasMachinesStations
        // Get a list of areas, machines and stations
        // @param query: Query
        // @return JsonOutputListOfAreasMachinesModulesStations
        private JsonOutputSimpleState SetKPIValuesExecution(string areaMachineModuleStation, DateTime startDateTime, DateTime endDateTime, string calculationBase, string idForTempTable, int timeoutInSeconds)
        {
            List<ProcedureProperties> procedureProperties = new()
            {
                new ProcedureProperties { PropertyName = "@Id", PropertyValue = idForTempTable },
                new ProcedureProperties { PropertyName = "@Machine", PropertyValue = areaMachineModuleStation },
                new ProcedureProperties { PropertyName = "@StartDate", PropertyValue = startDateTime },
                new ProcedureProperties { PropertyName = "@EndDate", PropertyValue = endDateTime },
                new ProcedureProperties { PropertyName = "@KPITimeBase", PropertyValue = calculationBase }
            };
            return CallProcedure("KPI_CALCULATOR_CalculateSummedUpKPIs_Execution", procedureProperties, timeoutInSeconds);
        }

        // GetListOfAreasMachinesStations
        // Get a list of areas, machines and stations
        // @param query: Query
        // @return JsonOutputListOfAreasMachinesModulesStations
        private JsonOutputSimpleState SetKPIValuesPrepareData(JsonOutputKPIValues jsonOutputKPIValues, string idForTempTable)
        {
            if (jsonOutputKPIValues.KPIValues.Count > 0)
            {

                JsonOutputSimpleState jsonOutputSimpleState = new();
                string insertQuery = "";
                string insertBaseQuery = "insert into TEMP_KPI_CALCULATOR_CalculateSummedUpKPIs_IN_" + idForTempTable;
                insertBaseQuery += " (";
                insertBaseQuery += "    [Machine], ";
                insertBaseQuery += "    [KPIName], ";
                insertBaseQuery += "    [KPICalculationBase], ";
                insertBaseQuery += "    [KPIDateTime], ";
                insertBaseQuery += "    [KPIDateTimeEnd], ";
                insertBaseQuery += "    [KPIFloatValue], ";
                insertBaseQuery += "    [KPITimeBase] ";
                insertBaseQuery += " ) values ";
                int counter = 0;
                Boolean newQuery = true;
                foreach (JsonOutputKPIValue jsonOutputKPIValue in jsonOutputKPIValues.KPIValues)
                {
                    if (newQuery)
                    {
                        insertQuery = insertBaseQuery;
                        newQuery = false;
                    }

                    insertQuery += counter > 0 ? "," : "";
                    insertQuery += "(";
                    insertQuery += "'" + jsonOutputKPIValue.Machine + "', ";
                    insertQuery += "'" + jsonOutputKPIValue.KPIName + "', ";
                    insertQuery += "'" + jsonOutputKPIValue.KPICalculationBase + "', ";
                    insertQuery += "convert(datetime2, '" + jsonOutputKPIValue.KPIStartTime.ToString("yyyy-MM-dd HH:mm:ss") + "', 20), ";
                    insertQuery += "convert(datetime2, '" + jsonOutputKPIValue.KPIEndTime.ToString("yyyy-MM-dd HH:mm:ss") + "', 20), ";
                    insertQuery += jsonOutputKPIValue.KPIFloatValue.ToString().Replace(',', '.') + ", ";
                    insertQuery += "'" + jsonOutputKPIValue.KPITimeBase + "' ";
                    insertQuery += ")";
                    counter++;
                    if (counter == 1000)
                    {
                        jsonOutputSimpleState = CallStatement(insertQuery);
                        counter = 0;
                        if (jsonOutputSimpleState.State != "OK") break;
                        newQuery = true;
                    }
                }
                if (counter > 0)
                {
                    jsonOutputSimpleState = CallStatement(insertQuery);
                }
                return jsonOutputSimpleState;
            }
            else
            {
                return new JsonOutputSimpleState { State = "OK", Message = "No data to insert" };
            }
        }
    }
}
