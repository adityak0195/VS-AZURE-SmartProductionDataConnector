﻿using KpiCalculator.JSON;
using System;
using System.Reflection.PortableExecutable;

namespace KpiCalculator.Data.Dataprovider
{
    public interface IData : IDisposable
    {
        // TestConnection
        // Test the connection
        // @return JsonOutputTestConnection
        public JsonOutputTestConnection TestConnection();

        // GetListOfAreas
        // Get a list of areas
        // @return JsonOutputListOfAreasMachinesModulesStations
        public JsonOutputListOfAreasMachinesModulesStations GetListOfAreas();

        // GetListOfMachines
        // Get a list of machines
        // @return JsonOutputListOfAreasMachinesModulesStations
        public JsonOutputListOfAreasMachinesModulesStations GetListOfMachines();

        // GetListOfStations
        // Get a list of stations
        // @return JsonOutputListOfAreasMachinesModulesStations
        public JsonOutputListOfAreasMachinesModulesStations GetListOfStations();

        // GetListOfStations
        // Get a list of stations
        // @return JsonOutputListOfAreasMachinesModulesStations
        public JsonOutputListOfAreasMachinesModulesStations GetListOfModules();

        // GetListOfPlants
        // Get a list of Plants
        // @return JsonOutputListOfAreasMachinesModulesStations
        public JsonOutputListOfAreasMachinesModulesStations GetListOfPlants();

        // CalulateKPIsForSingleMachine
        // Calculate KPIs for a single machine
        // @param shiftStartOfDayUtcBased: Start of the period
        // @param shiftEndOfDayUtcBased: End of the period
        // @param calculationBase: Calculation base
        // @param machine: Machine
        // @param timeoutInSeconds: Timeout in seconds
        // @return JsonOutputSimpleState
        public JsonOutputSimpleState CalulateKPIsForSingleMachine(DateTime shiftStartOfDayUtcBased, DateTime shiftEndOfDayUtcBased, string calculationBase, string machine, int timeoutInSeconds);

        // CalulateKPIsForSingleMachine
        // Calculate KPIs for a single machine
        // @param shiftStartOfDayUtcBased: Start of the period
        // @param shiftEndOfDayUtcBased: End of the period
        // @param calculationBase: Calculation base
        // @param area: Area
        // @param timeoutInSeconds: Timeout in seconds
        // @return JsonOutputSimpleState
        public JsonOutputSimpleState CalulateKPIsForSingleArea(DateTime shiftStartOfDayUtcBased, DateTime shiftEndOfDayUtcBased, string calculationBase, string area, int timeoutInSeconds);

        // CalulateKPIsForSingleMachine
        // Calculate KPIs for a single machine
        // @param shiftStartOfDayUtcBased: Start of the period
        // @param shiftEndOfDayUtcBased: End of the period
        // @param calculationBase: Calculation base
        // @param module: Module
        // @param timeoutInSeconds: Timeout in seconds
        // @return JsonOutputSimpleState
        public JsonOutputSimpleState CalulateKPIsForSingleModule(DateTime shiftStartOfDayUtcBased, DateTime shiftEndOfDayUtcBased, string calculationBase, string module, int timeoutInSeconds);

        // CalulateKPIsForSinglePlant
        // Calculate KPIs for a single plant
        // @param shiftStartOfDayUtcBased: Start of the period
        // @param shiftEndOfDayUtcBased: End of the period
        // @param calculationBase: Calculation base
        // @param plant: Plant
        // @param timeoutInSeconds: Timeout in seconds
        // @return JsonOutputSimpleState
        public JsonOutputSimpleState CalulateKPIsForSinglePlant(DateTime shiftStartOfDayUtcBased, DateTime shiftEndOfDayUtcBased, string calculationBase, string plant, int timeoutInSeconds);

        // CalulateKPIsForSingleStation
        // Calculate KPIs for a single station
        // @param shiftStartOfDayUtcBased: Start of the period
        // @param shiftEndOfDayUtcBased: End of the period
        // @param calculationBase: Calculation base
        // @param machine: Machine
        // @param station: Station
        // @param timeoutInSeconds: Timeout in seconds
        // @return JsonOutputSimpleState
        public JsonOutputSimpleState CalulateKPIsForSingleStation(DateTime shiftStartOfDayUtcBased, DateTime shiftEndOfDayUtcBased, string calculationBase, string machine, string station, int timeoutInSeconds);

        // GetListOfShiftDefinitions
        // Get a list of shift definitions
        // @param machine: Machine
        // @param startDateTime: Start date and time
        // @param endDateTime: End date and time
        // @return JsonOutputListOfShiftDefinitions
        public JsonOutputListOfShiftDefinitions GetListOfShiftDefinitions(string machine, DateTime startDateTime, DateTime endDateTime);

        // GetCurrentOrNextShiftDefinition
        // Get the current or next shift definition
        // @param machine: Machine
        // @param referenceTime: Reference time
        // @return JsonOutputListOfShiftDefinitions
        JsonOutputListOfShiftDefinitions GetCurrentOrNextShiftDefinition(string machine, DateTime referenceTime);

        // GetLastShiftDefinition
        // Get the last shift definition
        // @param machine: Machine
        // @param referenceTime: Reference time
        // @return JsonOutputListOfShiftDefinitions
        JsonOutputListOfShiftDefinitions GetLastShiftDefinition(string machine, DateTime referenceTime);


        // GetKPIValues
        // Get KPI values
        // @param machine: Machine
        // @param startDateTime: Start date and time
        // @param endDateTime: End date and time
        // @param calculationBase: Calculation base
        // @param timeoutInSeconds: Timeout in seconds
        JsonOutputKPIValues GetKPIValues(string machine, DateTime startDateTime, DateTime endDateTime, string calculationBase);

        // SetKPIValues
        // Set KPI values
        // @param jsonOutputKPIValues: JsonOutputKPIValues
        // @param areaMachineModuleStation: Area Machine Module Station
        // @param startDateTime: Start date and time
        // @param endDateTime: End date and time
        // @param calculationBase: Calculation base
        // @param timeoutInSeconds: Timeout in seconds
        JsonOutputSimpleState SetKPIValues(JsonOutputKPIValues jsonOutputKPIValues, string areaMachineModuleStation, DateTime startDateTime, DateTime endDateTime, string calculationBase);
    }
}
