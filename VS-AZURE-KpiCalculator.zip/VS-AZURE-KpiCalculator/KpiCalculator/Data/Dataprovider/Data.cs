﻿using KBBasics;
using KBBasics.SetupForFileSystem;
using KpiCalculator.JSON;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection.PortableExecutable;

namespace KpiCalculator.Data.Dataprovider
{
    //ProcedureProperties
    //Provides a list of properties for a procedure
    internal class ProcedureProperties
    {
        internal string PropertyName { get; set; }
        internal object PropertyValue { get; set; }
    }

    //abstract class Data
    public abstract class Data<T> where T : IDbConnection, new()
    {
        internal readonly T conn;
        internal readonly Logger Logger;

        // Constructor
        // Initializes the settings and logger
        // Initializes the connection
        // Parameters:
        //   settings: AppSettings
        // Returns:
        //   void
        protected Data()
        {
            Logger = new();
            conn = new T();
        }

        // Dispose
        // Closes the connection
        public void Dispose()
        {
            try
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
            catch (Exception e)
            {
                Logger.Log(KBBasics.LogLevel.ERROR,e.Message);
            }
        }

        // CallProcedure
        // Calls a procedure
        // Parameters:
        //   procedureName: string
        //   procedureProperties: List<ProcedureProperties>
        // Returns:
        //   JsonOutputSimpleState
        internal JsonOutputSimpleState CallProcedure(string procedureName, List<ProcedureProperties> procedureProperties, int timeoutInSeconds)
        {
            JsonOutputSimpleState result = new();
            try
            {
                using (IDbCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = procedureName;
                    cmd.CommandTimeout = timeoutInSeconds;
                    if (procedureProperties != null)
                    {
                        foreach (ProcedureProperties property in procedureProperties)
                        {
                            IDataParameter param = cmd.CreateParameter();
                            param.ParameterName = property.PropertyName;
                            param.Value = property.PropertyValue;
                            cmd.Parameters.Add(param);
                        }
                    }
                    using IDataReader reader = cmd.ExecuteReader();
                }
                result.State = "OK";
            }
            catch (Exception e)
            {
                Logger.Log(KBBasics.LogLevel.ERROR, e.Message);
                result.State = e.Message;
            }
            return result;
        }

        // CallStatement
        // Calls a statement
        // Parameters:
        //   query: string
        // Returns:
        //   JsonOutputSimpleState
        internal JsonOutputSimpleState CallStatement(string query)
        {
            JsonOutputSimpleState result = new();
            try
            {
                string DBState;
                try
                {
                    using (IDbCommand cmd = conn.CreateCommand())
                    {
                        cmd.CommandText = query; // Set up query
                        using (IDataReader reader = cmd.ExecuteReader());
                    }
                    DBState = "OK";
                }
                catch (Exception x)
                {
                    DBState = x.Message;
                }
                result.State = DBState;
            }
            catch (Exception e)
            {
                Logger.Log(KBBasics.LogLevel.ERROR, e.Message);
            }

            return result;
        }


        // TestConnection
        // Tests the connection
        // Parameters:
        //   query: string
        // Returns:
        //   JsonOutputTestConnection
        internal JsonOutputTestConnection TestConnection(string query)
        {
            JsonOutputTestConnection result = new();
            try
            {
                string DBResult;
                string DBState;
                try
                {
                    using (IDbCommand cmd = conn.CreateCommand())
                    {
                        cmd.CommandText = query; // Set up query
                        using (IDataReader reader = cmd.ExecuteReader())
                        {
                            reader.Read();
                            DBResult = "Connection OK, current date at DB: " + reader.GetString(0);
                        }
                    }
                    DBState = "OK";
                }
                catch (Exception x)
                {
                    DBResult = x.ToString();
                    DBState = "Error";
                }
                result = new()
                {
                    Name = GetType().Name,
                    JavaDate = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                    Date = DateTime.Now,
                    Message = DBResult,
                    state = DBState
                };
            }
            catch (Exception e)
            {
                Logger.Log(KBBasics.LogLevel.ERROR, e.Message);
            }

            return result;
        }

        // GetListOfAreasMachinesModulesStations
        // Gets a list of areas, machines, modules and stations
        // Parameters:
        //   query: string
        // Returns:
        //   JsonOutputListOfAreasMachinesModulesStations
        protected JsonOutputListOfAreasMachinesModulesStations GetListOfAreasMachinesModulesStations(string query)
        {
            JsonOutputListOfAreasMachinesModulesStations result = new();
            try
            {
                using (IDbCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = query; // Set up query
                    using (IDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            JsonOutputAreaMachineModuleStation item = new()
                            {
                                Plant = reader.GetString(0),
                                Area = reader.GetString(1),
                                Machine = reader.GetString(2),
                                Station = reader.GetString(3),
                                Module = reader.GetString(4),
                                Type = reader.GetString(5),
                                DayOffset = reader.GetDouble(6),
                                ServerTimeZoneDB = reader.GetString(7)
                            };
                            result.AreasMachinesModulesStations.Add(item);
                        }
                    }
                }

                result.State = "OK";
            }
            catch (Exception x)
            {
                result.State = x.ToString();
            }

            return result;
        }

        // GetListOfSShifts
        // Get a list of shiftss
        // @return JsonOutputListOfAreasMachinesModulesStations
        public JsonOutputListOfShiftDefinitions GetListOfShiftDefinitions(string query)
        {
            JsonOutputListOfShiftDefinitions result = new();
            try
            {
                using (IDbCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = query; // Set up query
                    using (IDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            JsonOutputShiftDefinition item = new()
                            {
                                Machine = reader.GetString(0),
                                ShiftName = reader.GetString(1),
                                StartTime = reader.GetDateTime(2),
                                EndTime = reader.GetDateTime(3)
                            };
                            result.ShiftDefinitions.Add(item);
                        }
                    }
                }

                result.State = "OK";
            }
            catch (Exception x)
            {
                result.State = x.ToString();
            }

            return result;
        }

        // GetListOfKPIValues
        // Gets a list of KPI values
        // Parameters:
        //   query: string
        // Returns:
        //   JsonOutputKPIValues
        protected JsonOutputKPIValues GetListOfKPIValues(string query)
        {
            JsonOutputKPIValues result = new();
            try
            {
                using (IDbCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = query; // Set up query
                    using (IDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            JsonOutputKPIValue item = new()
                            {
                                Machine = reader.GetString(0),
                                KPIName = reader.GetString(1),
                                KPICalculationBase = reader.GetString(2),
                                KPITimeBase = reader.GetString(3),
                                KPIStartTime = reader.GetDateTime(4),
                                KPIEndTime = reader.GetDateTime(5),
                                KPIFloatValue = reader.GetDecimal(6)
                            };
                            result.KPIValues.Add(item);
                        }
                    }
                }

                result.State = "OK";
            }
            catch (Exception x)
            {
                result.State = x.ToString();
            }

            return result;
        }
    }
}
