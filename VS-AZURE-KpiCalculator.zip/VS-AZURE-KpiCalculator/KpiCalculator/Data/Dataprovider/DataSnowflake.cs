﻿using KpiCalculator.JSON;
using Snowflake.Data.Client;
using System;
using KBBasics.SetupForFileSystem;
using System.Reflection.PortableExecutable;
using static log4net.Appender.RollingFileAppender;
using System.Data;

namespace KpiCalculator.Data.Dataprovider
{
    // DataSnowflake
    // Class for handling Snowflake data
    public class DataSnowflake : Data<SnowflakeDbConnection>, IData
    {
        private readonly KBBasics.SetupForFileSystem.Snowflake _snowflake;

        // TestConnection
        // Test the connection
        // @return JsonOutputTestConnection
        public JsonOutputTestConnection TestConnection()
        {
            JsonOutputTestConnection result = TestConnection("select cast(current_timestamp() as varchar);");
            result.Server = _snowflake.host;
            result.Database = _snowflake.DB;
            result.User = _snowflake.user;
            result.Warehouse = _snowflake.warehouse;
            result.Schema = _snowflake.schema;
            result.Role = _snowflake.role;
            result.Account = _snowflake.account;
            result.Message = "Snowflake " + result.Message;

            return result;
        }

        // Constructor
        // @param snowflakeDivision: Snowflake division
        // @param settings: App settings
        public DataSnowflake(KBBasics.SetupForFileSystem.Snowflake snowflake) : base()
        {
            _snowflake = snowflake;
            try
            {
                string connectionString = "host=" + _snowflake.host + ";" +
                    "warehouse=" + _snowflake.warehouse + ";" +
                    "db=" + _snowflake.DB + ";" +
                    "schema=" + _snowflake.schema + ";" +
                    "account=" + _snowflake.account + ";" +
                    "authenticator=snowflake_jwt;" +
                    "user=" + _snowflake.user + ";" +
                    "role=" + _snowflake.role + ";";
                if (_snowflake.getSnowflakeKeyFromFile)
                {
                    connectionString += "private_key_file=" + _snowflake.snowflakeKeyFile;
                }
                else
                {
                    connectionString += "private_key=" + _snowflake.snowflakeKey;
                }

                conn.ConnectionString = connectionString;
                conn.Open();
            }
            catch (Exception e)
            {
                Logger.Log(KBBasics.LogLevel.ERROR, e.Message);
            }
        }

        // GetListOfAreas
        // Get a list of areas
        // @return JsonOutputListOfAreasMachinesModulesStations
        public JsonOutputListOfAreasMachinesModulesStations GetListOfAreas()
        {
            return GetListOfAreasMachinesModulesStations(
                "select                                                                                  " +
                "    ifnull(planttemplate.Machine,'NULL') as plant                                       " +
                "    ,ifnull(machine.Machine,'NULL') as area                                             " +
                "    ,'NULL' as machine                                                                  " +
                "    ,'NULL' as module                                                                  " +
                "    ,'NULL' as station                                                                  " +
                "    ,ifnull(machine.PropertySubKey2,'NULL') as type                                     " +
                "    ,ifnull(offset.FloatValue,0) as offset                                              " +
                "    ,ifnull(serverTimeZoneDB.TextValue, 'Central European Standard Time')            " +
                "from                                                                                    " +
                _snowflake.DB + "." + _snowflake.schema + "." + "SMARTKPI_MACHINEKEYVALUEDATA as planttemplate," +
                _snowflake.DB + "." + _snowflake.schema + "." + "SMARTKPI_MACHINEKEYVALUEDATA as machine,      " +
                _snowflake.DB + "." + _snowflake.schema + "." + "SMARTKPI_MACHINEKEYVALUEDATA as offset,        " +
                _snowflake.DB + "." + _snowflake.schema + "." + "SMARTKPI_MACHINEKEYVALUEDATA serverTimeZoneDB " +
                "where                                                                                   " +
                "    planttemplate.TextValue = 'KBLocalPlantThingTemplate'                               " +
                "    and machine.PropertyKey = 'KBPlantThing'                                            " +
                "    and machine.UpdateTime > dateadd(month,-1,getdate())                                " +
                "    and planttemplate.Machine = machine.TextValue                                       " +
                "    and ifnull(machine.TextValue,'') != ''                                              " +
                "    and machine.PropertySubKey2 = 'KBLocalAreaThingTemplate'                            " +
                "    and offset.Machine = planttemplate.Machine                                          " +
                "    and offset.PropertyKey = 'CVS_DMS_Day_Offset_in_Minutes'                            " +
                "    and planttemplate.delete_identifier != 'DELETED'                                    " +
                "    and machine.delete_identifier != 'DELETED'                                          " +
                "    and serverTimeZoneDB.delete_identifier != 'DELETED'                                          " +
                "    and offset.delete_identifier != 'DELETED'                                           " +
                "    and serverTimeZoneDB.Machine = 'KBTimeHelperThing' " +
                "    and serverTimeZoneDB.PropertyKey = 'ServerTimeZoneDB' "  
                );
        }

        // GetListOfMachines
        // Get a list of machines
        // @return JsonOutputListOfAreasMachinesModulesStations
        public JsonOutputListOfAreasMachinesModulesStations GetListOfMachines()
        {
            return GetListOfAreasMachinesModulesStations(
                "select                                                                               " +
                "    ifnull(planttemplate.Machine,'NULL') as plant                                    " +
                "    ,'NULL' as area                                                                  " +
                "    ,ifnull(machine.Machine,'NULL')                                                  " +
                "    ,'NULL' as module                                                                " +
                "    ,'NULL' as station                                                               " +
                "    ,ifnull(machine.PropertySubKey2,'NULL')                                          " +
                "    ,ifnull(offset.FloatValue, 0)                                                    " +
                "    ,ifnull(serverTimeZoneDB.TextValue, 'Central European Standard Time')            " +
                "from                                                                                 " +
                _snowflake.DB + "." + _snowflake.schema + "." + "SMARTKPI_MACHINEKEYVALUEDATA planttemplate," +
                _snowflake.DB + "." + _snowflake.schema + "." + "SMARTKPI_MACHINEKEYVALUEDATA machine,      " +
                _snowflake.DB + "." + _snowflake.schema + "." + "SMARTKPI_MACHINEKEYVALUEDATA offset,       " +
                _snowflake.DB + "." + _snowflake.schema + "." + "SMARTKPI_MACHINEKEYVALUEDATA serverTimeZoneDB " +
                "where                                                                                " +
                "    planttemplate.TextValue = 'KBLocalPlantThingTemplate'                            " +
                "    and machine.PropertyKey = 'KBPlantThing'                                         " +
                "    and machine.UpdateTime > dateadd(month,-1,getdate())                             " +
                "    and planttemplate.Machine = machine.TextValue                                    " +
                "    and ifnull(machine.TextValue,'') != ''                                           " +
                "    and machine.PropertySubKey2 = 'KBLocalMachineThingTemplate'                      " +
                "    and offset.Machine = planttemplate.Machine                                       " +
                "    and offset.PropertyKey = 'CVS_DMS_Day_Offset_in_Minutes'                         " +
                "    and planttemplate.delete_identifier != 'DELETED'                                 " +
                "    and machine.delete_identifier != 'DELETED'                                       " +
                "    and serverTimeZoneDB.delete_identifier != 'DELETED'                                          " +
                "    and offset.delete_identifier != 'DELETED'                                        " +
                "    and serverTimeZoneDB.Machine = 'KBTimeHelperThing' " +
                "    and serverTimeZoneDB.PropertyKey = 'ServerTimeZoneDB' "  
                );
        }

        // GetListOfStations
        // Get a list of stations
        // @return JsonOutputListOfAreasMachinesModulesStations
        public JsonOutputListOfAreasMachinesModulesStations GetListOfStations()
        {
            return GetListOfAreasMachinesModulesStations(
                "select                                                                               " +
                "    ifnull(planttemplate.Machine,'NULL')                                             " +
                "    ,'NULL' as area                                                                  " +
                "    ,ifnull(machine.Machine,'NULL')                                                  " +
                "    ,'NULL' as module                                                                " +
                "    ,ifnull(station.Machine,'NULL')                                                  " +
                "    ,ifnull(station.PropertySubKey2,'NULL')                                          " +
                "    ,ifnull(offset.FloatValue, 0)                                                    " +
                "    ,ifnull(serverTimeZoneDB.TextValue, 'Central European Standard Time')            " +
                "from                                                                                 " +
                _snowflake.DB + "." + _snowflake.schema + "." + "SMARTKPI_MACHINEKEYVALUEDATA planttemplate," +
                _snowflake.DB + "." + _snowflake.schema + "." + "SMARTKPI_MACHINEKEYVALUEDATA machine,      " +
                _snowflake.DB + "." + _snowflake.schema + "." + "SMARTKPI_MACHINEKEYVALUEDATA station,      " +
                _snowflake.DB + "." + _snowflake.schema + "." + "SMARTKPI_MACHINEKEYVALUEDATA offset,        " +
                _snowflake.DB + "." + _snowflake.schema + "." + "SMARTKPI_MACHINEKEYVALUEDATA serverTimeZoneDB " +
                "where                                                                                " +
                "    planttemplate.TextValue = 'KBLocalPlantThingTemplate'                            " +
                "    and machine.PropertyKey = 'KBPlantThing'                                         " +
                "    and planttemplate.Machine = machine.TextValue                                    " +
                "    and ifnull(machine.TextValue,'') != ''                                           " +
                "    and machine.PropertySubKey2 = 'KBLocalMachineThingTemplate'                      " +
                "    and machine.Machine = station.TextValue                                          " +
                "    and station.PropertyKey = 'KBLocalLineThing'                                     " +
                "    and station.UpdateTime > dateadd(month,-1,getdate())                             " +
                "    and offset.Machine = planttemplate.Machine                                       " +
                "    and offset.PropertyKey = 'CVS_DMS_Day_Offset_in_Minutes'                         " +
                "    and planttemplate.delete_identifier != 'DELETED'                                 " +
                "    and machine.delete_identifier != 'DELETED'                                       " +
                "    and station.delete_identifier != 'DELETED'                                       " +
                "    and serverTimeZoneDB.delete_identifier != 'DELETED'                              " +
                "    and offset.delete_identifier != 'DELETED'                                        " +
                "    and serverTimeZoneDB.Machine = 'KBTimeHelperThing'                               " +
                "    and serverTimeZoneDB.PropertyKey = 'ServerTimeZoneDB'                            "  
                );
        }

        // CalulateKPIsForSingleMachine
        // Calculate KPIs for a single machine
        // @param shiftStartOfDayUtcBased: Start of the period
        // @param shiftEndOfDayUtcBased: End of the period
        // @param calculationBase: Calculation base
        // @param machine: Machine
        // @return JsonOutputSimpleState
        public JsonOutputSimpleState CalulateKPIsForSingleMachine(DateTime shiftStartOfDayUtcBased, DateTime shiftEndOfDayUtcBased, string calculationBase, string machine, int timeoutInSeconds)
        {
            throw new NotImplementedException();
        }

        // CalulateKPIsForSingleStation
        // Calculate KPIs for a single station
        // @param shiftStartOfDayUtcBased: Start of the period
        // @param shiftEndOfDayUtcBased: End of the period
        // @param calculationBase: Calculation base
        // @param machine: Machine
        // @param station: Station
        // @return JsonOutputSimpleState
        public JsonOutputSimpleState CalulateKPIsForSingleStation(DateTime shiftStartOfDayUtcBased, DateTime shiftEndOfDayUtcBased, string calculationBase, string machine, string station, int timeoutInSeconds)
        {
            throw new NotImplementedException();
        }

        // GetListOfShiftDefinitions
        // Get a list of shift definitions
        // @param machine: Machine
        // @param startDateTime: Start date and time
        // @param endDateTime: End date and time
        // @return JsonOutputListOfShiftDefinitions
        public JsonOutputListOfShiftDefinitions GetListOfShiftDefinitions(string machine, DateTime startDateTime, DateTime endDateTime)
        {
            throw new NotImplementedException();
        }

        // GetCurrentOrNextShiftDefinition
        // Get the current or next shift definition
        // @param machine: Machine
        // @param referenceTime: Reference time
        // @return JsonOutputListOfShiftDefinitions
        public JsonOutputListOfShiftDefinitions GetCurrentOrNextShiftDefinition(string machine, DateTime referenceTime)
        {
            throw new NotImplementedException();
        }

        // GetLastShiftDefinition
        // Get the last shift definition
        // @param machine: Machine
        // @param referenceTime: Reference time
        // @return JsonOutputListOfShiftDefinitions
        public JsonOutputListOfShiftDefinitions GetLastShiftDefinition(string machine, DateTime referenceTime)
        {
            throw new NotImplementedException();
        }

        // GetListOfKPIValues
        // Get a list of KPI values
        // @param query: Query
        // @return JsonOutputKPIValues
        public JsonOutputKPIValues GetKPIValues(string machine, DateTime startDateTime, DateTime endDateTime, string calculationBase)
        {
            return GetListOfKPIValues(
                "select machine, KPIName, KPICalculationBase, KPITimeBase, CAST (kpidatetime as datetime), CAST (kpidatetimeend as datetime), KPIFloatValue" +
                "    from "+
                _snowflake.DB + "." + _snowflake.schema + "." + "SMARTKPI_VALUES" +
                "    where delete_identifier != 'DELETED'" +
                "    and kpitimebase = 'day'"+
                "    and kpidatetime > '"+ startDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff") + " +0000'" +
                "    and kpidatetime < '" + endDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff") + " +0000'" +
                "    and machine = '"+machine+"';"

                );

            //convert datetime to string


        }

        // SetKPIValues
        // Set KPI values
        // @param jsonOutputKPIValues: JsonOutputKPIValues
        // @param areaMachineModuleStation: Area Machine Module Station
        // @param startDateTime: Start date and time
        // @param endDateTime: End date and time
        // @param calculationBase: Calculation base
        // @return JsonOutputSimpleState
        public JsonOutputSimpleState SetKPIValues(JsonOutputKPIValues jsonOutputKPIValues, string areaMachineModuleStation, DateTime startDateTime, DateTime endDateTime, string calculationBase)
        {
            throw new NotImplementedException();
        }

        // GetListOfModules
        // Get a list of modules
        // @return JsonOutputListOfAreasMachinesModulesStations
        public JsonOutputListOfAreasMachinesModulesStations GetListOfModules()
        {
            throw new NotImplementedException();
        }

        // CalulateKPIsForSingleArea
        // Calculate KPIs for a single area
        // @param shiftStartOfDayUtcBased: Start of the period
        // @param shiftEndOfDayUtcBased: End of the period
        // @param calculationBase: Calculation base
        // @param area: Area
        // @return JsonOutputSimpleState
        public JsonOutputSimpleState CalulateKPIsForSingleArea(DateTime shiftStartOfDayUtcBased, DateTime shiftEndOfDayUtcBased, string calculationBase, string area, int timeoutInSeconds)
        {
            throw new NotImplementedException();
        }

        // CalulateKPIsForSingleModule
        // Calculate KPIs for a single module
        // @param shiftStartOfDayUtcBased: Start of the period
        // @param shiftEndOfDayUtcBased: End of the period
        // @param calculationBase: Calculation base
        // @param module: Module
        // @return JsonOutputSimpleState
        public JsonOutputSimpleState CalulateKPIsForSingleModule(DateTime shiftStartOfDayUtcBased, DateTime shiftEndOfDayUtcBased, string calculationBase, string module, int timeoutInSeconds)
        {
            throw new NotImplementedException();
        }

        public JsonOutputListOfAreasMachinesModulesStations GetListOfPlants()
        {
            throw new NotImplementedException();
        }

        public JsonOutputSimpleState CalulateKPIsForSinglePlant(DateTime shiftStartOfDayUtcBased, DateTime shiftEndOfDayUtcBased, string calculationBase, string plant, int timeoutInSeconds)
        {
            throw new NotImplementedException();
        }
    }
}
