﻿using KpiCalculator.Data.Dataprovider;
using KpiCalculator.JSON;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KpiCalculator.Data
{
    public class AreasMachinesModulesStations
    {
        /// <summary>
        /// This method is used to get a list of areas defined in database (Type = KBLocalAreaThingTemplate), opened data connection is needed
        /// Machine and Station is NULL
        /// DayOffset contains the property CVS_DMS_Day_Offset_in_Minutes for defined day offset
        /// </summary>
        /// <param name="dataconnection"></param>
        /// <returns>JsonOutputListOfAreasMachinesModulesStations</returns>
        public static JsonOutputListOfAreasMachinesModulesStations GetListOfAreas(IData dataconnection)
        {
            return dataconnection.GetListOfAreas();
        }

        /// <summary>
        /// This method is used to get a list of machines defined in database (Type = KBLocalMachineThingTemplate), opened data connection is needed
        /// Area and Station is NULL
        /// DayOffset contains the property CVS_DMS_Day_Offset_in_Minutes for defined day offset
        /// </summary>
        /// <param name="dataconnection"></param>
        /// <returns>JsonOutputListOfAreasMachinesModulesStations</returns>
        public static JsonOutputListOfAreasMachinesModulesStations GetListOfMachines(IData dataconnection)
        {
            return dataconnection.GetListOfMachines();
        }

        /// <summary>
        /// This method is used to get a list of stations defined in database (Type = KBLocalStationThingTemplate), opened data connection is needed
        /// Machine containes the related machine assigned and Area is NULL
        /// DayOffset contains the property CVS_DMS_Day_Offset_in_Minutes for defined day offset
        /// </summary>
        /// <param name="dataconnection"></param>
        /// <returns>JsonOutputListOfAreasMachinesModulesStations</returns>
        public static JsonOutputListOfAreasMachinesModulesStations GetListOfStations(IData dataconnection)
        {
            return dataconnection.GetListOfStations();
        }

        /// <summary>
        /// This method is used to get a list of modules defined in database (Type = KBLocalModuleThingTemplate), opened data connection is needed
        /// Machine containes the related machine assigned and Area is NULL
        /// DayOffset contains the property CVS_DMS_Day_Offset_in_Minutes for defined day offset
        /// </summary>
        /// <param name="dataconnection"></param>
        /// <returns>JsonOutputListOfAreasMachinesModulesStations</returns>
        public static JsonOutputListOfAreasMachinesModulesStations GetListOfModules(IData dataconnection)
        {
            return dataconnection.GetListOfModules();
        }

        /// <summary>
        /// This method is used to get a list of plants defined in database (Type = KBLocalPlantThingTemplate), opened data connection is needed
        /// Machine containes the related machine assigned and Area is NULL
        /// DayOffset contains the property CVS_DMS_Day_Offset_in_Minutes for defined day offset
        /// </summary>
        /// <param name="dataconnection"></param>
        /// <returns>JsonOutputListOfAreasMachinesModulesStations</returns>
        public static JsonOutputListOfAreasMachinesModulesStations GetListOfPlants(IData dataconnection)
        {
            return dataconnection.GetListOfPlants();
        }
    }
}
