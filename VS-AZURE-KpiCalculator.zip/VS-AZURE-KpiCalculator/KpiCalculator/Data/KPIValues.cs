﻿using KpiCalculator.Data.Dataprovider;
using KpiCalculator.JSON;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KpiCalculator.Data
{
    public class KPIValues
    {
        // GetListOfShiftDefinitions
        // Get a list of shift definitions
        // @param dataconnection: IData
        // @param machine: Machine
        // @param startDateTime: Start date and time
        // @param endDateTime: End date and time
        // @return JsonOutputListOfShiftDefinitions
        public static JsonOutputKPIValues GetKPIValues(IData dataconnection, string machine, DateTime startDateTime, DateTime endDateTime, string calculationBase)
        {
            return dataconnection.GetKPIValues(machine, startDateTime, endDateTime, calculationBase) ;
        }
    }
}
