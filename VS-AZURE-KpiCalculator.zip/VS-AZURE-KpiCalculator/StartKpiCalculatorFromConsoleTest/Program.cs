﻿// See https://aka.ms/new-console-template for more information
using KBBasics;
using KBBasics.SetupForFileSystem;
using KpiCalculator.Logic;
using StartKpiCalculatorFromConsole;

string stagingLevel = "TEST";
SelectionData SelectionData = new();
SelectionData.appSettings = new(stagingLevel);
SelectionData = Helper.GetDatabase(SelectionData);
SelectionData.msSQL = SelectionData.appSettings.Settings.settingsKpiCalculator.mssql.Find(x => x.name == SelectionData.db);
SelectionData = Helper.PrintMenuLevel1(SelectionData, stagingLevel);
SelectionData = Helper.PrintMenuLevel2(SelectionData);
Helper.Run(SelectionData);


Console.WriteLine("End!");
