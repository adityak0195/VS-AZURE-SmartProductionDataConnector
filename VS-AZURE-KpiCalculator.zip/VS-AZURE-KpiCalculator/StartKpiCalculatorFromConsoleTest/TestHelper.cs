using KpiCalculator.Logic;
using StartKpiCalculatorFromConsole;

namespace StartKpiCalculatorFromConsoleTest
{
    [TestClass]
    public class TestHelper
    {
        [DataRow("CVSTEST")]
        [TestMethod]
        public void TestGetDatabase(string testvalue)
        {
            string stagingLevel = "TEST";
            SelectionData selectionData = new SelectionData();
            selectionData.appSettings = new(stagingLevel);
            selectionData = Helper.GetDatabase(selectionData, testvalue);

            Assert.AreEqual(testvalue, selectionData.db);
        }

        [DataRow("1")]
        [DataRow("2")]
        [DataRow("3")]
        [DataRow("4")]
        [DataRow("5")]
        [DataRow("6")]
        [DataRow("7")]
        [DataRow("8")]
        [DataRow("9")]
        [DataRow("10")]
        [DataRow("11")]
        [DataRow("12")]
        [DataRow("13")]
        [DataRow("14")]
        [DataRow("15")]
        [DataRow("16")]
        [DataRow("17")]
        [DataRow("18")]
        [DataRow("19")]
        [DataRow("20")]
        [DataRow("21")]
        [DataRow("22")]
        [DataRow("23")]
        [DataRow("24")]
        [DataRow("25")]
        [DataRow("26")]
        [DataRow("27")]
        [DataRow("28")]
        [DataRow("29")]
        [DataRow("30")]
        [DataRow("99")]
        [DataRow("xxxxxx")]
        [TestMethod]
        public void TestPrintMenuLevel1(string testvalue)
        {
            string stagingLevel = "TEST";
            SelectionData selectionData = new SelectionData();
            selectionData.appSettings = new(stagingLevel);
            selectionData = Helper.PrintMenuLevel1(selectionData, stagingLevel, testvalue);

            Assert.AreEqual(testvalue, selectionData.level1Menu);



            if (testvalue == "1")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNotNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.HOURLY, selectionData.calculateHourlyStationKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.STATION, selectionData.calculateHourlyStationKPIs.CalculationType);
            }
            else if (testvalue == "2")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNotNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.HOURLY, selectionData.calculateHourlyModuleKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MODULE, selectionData.calculateHourlyModuleKPIs.CalculationType);
            }
            else if (testvalue == "3")
            {
                Assert.IsNotNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.HOURLY, selectionData.calculateHourlyMachineKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MACHINE, selectionData.calculateHourlyMachineKPIs.CalculationType);
            }
            else if (testvalue == "4")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNotNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.HOURLY, selectionData.calculateHourlyAreaKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.AREA, selectionData.calculateHourlyAreaKPIs.CalculationType);
            }
            else if (testvalue == "5")
            {
                Assert.IsNotNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNotNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNotNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNotNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.HOURLY, selectionData.calculateHourlyStationKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.STATION, selectionData.calculateHourlyStationKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.HOURLY, selectionData.calculateHourlyMachineKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MACHINE, selectionData.calculateHourlyMachineKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.HOURLY, selectionData.calculateHourlyModuleKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MODULE, selectionData.calculateHourlyModuleKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.HOURLY, selectionData.calculateHourlyAreaKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.AREA, selectionData.calculateHourlyAreaKPIs.CalculationType);
            }
            else if (testvalue == "6")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNotNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.DAILY, selectionData.calculateDailyStationKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.STATION, selectionData.calculateDailyStationKPIs.CalculationType);
            }
            else if (testvalue == "7")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNotNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.DAILY, selectionData.calculateDailyModuleKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MODULE, selectionData.calculateDailyModuleKPIs.CalculationType);
            }
            else if (testvalue == "8")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNotNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.DAILY, selectionData.calculateDailyMachineKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MACHINE, selectionData.calculateDailyMachineKPIs.CalculationType);
            }
            else if (testvalue == "9")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNotNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.DAILY, selectionData.calculateDailyAreaKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.AREA, selectionData.calculateDailyAreaKPIs.CalculationType);
            }
            else if (testvalue == "10")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNotNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNotNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNotNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNotNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.DAILY, selectionData.calculateDailyStationKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.STATION, selectionData.calculateDailyStationKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.DAILY, selectionData.calculateDailyModuleKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MODULE, selectionData.calculateDailyModuleKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.DAILY, selectionData.calculateDailyMachineKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MACHINE, selectionData.calculateDailyMachineKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.DAILY, selectionData.calculateDailyAreaKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.AREA, selectionData.calculateDailyAreaKPIs.CalculationType);
            }
            else if (testvalue == "11")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNotNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.SHIFT, selectionData.calculateShiftStationKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.STATION, selectionData.calculateShiftStationKPIs.CalculationType);
            }
            else if (testvalue == "12")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNotNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.SHIFT, selectionData.calculateShiftModuleKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MODULE, selectionData.calculateShiftModuleKPIs.CalculationType);
            }
            else if (testvalue == "13")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNotNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.SHIFT, selectionData.calculateShiftMachineKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MACHINE, selectionData.calculateShiftMachineKPIs.CalculationType);
            }
            else if (testvalue == "14")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNotNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.SHIFT, selectionData.calculateShiftAreaKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.AREA, selectionData.calculateShiftAreaKPIs.CalculationType);
            }
            else if (testvalue == "15")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNotNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNotNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNotNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNotNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.SHIFT, selectionData.calculateShiftStationKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.STATION, selectionData.calculateShiftStationKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.SHIFT, selectionData.calculateShiftModuleKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MODULE, selectionData.calculateShiftModuleKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.SHIFT, selectionData.calculateShiftMachineKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MACHINE, selectionData.calculateShiftMachineKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.SHIFT, selectionData.calculateShiftAreaKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.AREA, selectionData.calculateShiftAreaKPIs.CalculationType);
            }
            else if (testvalue == "16")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNotNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.WEEKLY, selectionData.calculateWeeklyStationKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.STATION, selectionData.calculateWeeklyStationKPIs.CalculationType);
            }
            else if (testvalue == "17")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNotNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.WEEKLY, selectionData.calculateWeeklyModuleKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MODULE, selectionData.calculateWeeklyModuleKPIs.CalculationType);
            }
            else if (testvalue == "18")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNotNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.WEEKLY, selectionData.calculateWeeklyMachineKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MACHINE, selectionData.calculateWeeklyMachineKPIs.CalculationType);
            }
            else if (testvalue == "19")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNotNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.WEEKLY, selectionData.calculateWeeklyAreaKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.AREA, selectionData.calculateWeeklyAreaKPIs.CalculationType);
            }
            else if (testvalue == "20")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNotNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNotNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNotNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNotNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.WEEKLY, selectionData.calculateWeeklyStationKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.STATION, selectionData.calculateWeeklyStationKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.WEEKLY, selectionData.calculateWeeklyModuleKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MODULE, selectionData.calculateWeeklyModuleKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.WEEKLY, selectionData.calculateWeeklyMachineKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MACHINE, selectionData.calculateWeeklyMachineKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.WEEKLY, selectionData.calculateWeeklyAreaKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.AREA, selectionData.calculateWeeklyAreaKPIs.CalculationType);
            }
            else if (testvalue == "21")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNotNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.MONTHLY, selectionData.calculateMonthlyStationKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.STATION, selectionData.calculateMonthlyStationKPIs.CalculationType);
            }
            else if (testvalue == "22")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNotNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.MONTHLY, selectionData.calculateMonthlyModuleKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MODULE, selectionData.calculateMonthlyModuleKPIs.CalculationType);
            }
            else if (testvalue == "23")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNotNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.MONTHLY, selectionData.calculateMonthlyMachineKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MACHINE, selectionData.calculateMonthlyMachineKPIs.CalculationType);
            }
            else if (testvalue == "24")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNotNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.MONTHLY, selectionData.calculateMonthlyAreaKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.AREA, selectionData.calculateMonthlyAreaKPIs.CalculationType);
            }
            else if (testvalue == "25")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNotNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNotNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNotNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNotNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.MONTHLY, selectionData.calculateMonthlyStationKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.STATION, selectionData.calculateMonthlyStationKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.MONTHLY, selectionData.calculateMonthlyModuleKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MODULE, selectionData.calculateMonthlyModuleKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.MONTHLY, selectionData.calculateMonthlyMachineKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MACHINE, selectionData.calculateMonthlyMachineKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.MONTHLY, selectionData.calculateMonthlyAreaKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.AREA, selectionData.calculateMonthlyAreaKPIs.CalculationType);
            }
            else if (testvalue == "26")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNotNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.YEARLY, selectionData.calculateYearlyStationKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.STATION, selectionData.calculateYearlyStationKPIs.CalculationType);
            }
            else if (testvalue == "27")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNotNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.YEARLY, selectionData.calculateYearlyModuleKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MODULE, selectionData.calculateYearlyModuleKPIs.CalculationType);
            }
            else if (testvalue == "28")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNotNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.YEARLY, selectionData.calculateYearlyMachineKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MACHINE, selectionData.calculateYearlyMachineKPIs.CalculationType);
            }
            else if (testvalue == "29")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNotNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.YEARLY, selectionData.calculateYearlyAreaKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.AREA, selectionData.calculateYearlyAreaKPIs.CalculationType);
            }
            else if (testvalue == "30")
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNotNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNotNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNotNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNotNull(selectionData.calculateYearlyAreaKPIs);

                Assert.AreEqual(CalculateKPIsType.YEARLY, selectionData.calculateYearlyStationKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.STATION, selectionData.calculateYearlyStationKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.YEARLY, selectionData.calculateYearlyModuleKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MODULE, selectionData.calculateYearlyModuleKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.YEARLY, selectionData.calculateYearlyMachineKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MACHINE, selectionData.calculateYearlyMachineKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.YEARLY, selectionData.calculateYearlyAreaKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.AREA, selectionData.calculateYearlyAreaKPIs.CalculationType);
            }
            else if (testvalue == "99")
            {
                Assert.IsNotNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNotNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNotNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNotNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNotNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNotNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNotNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNotNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNotNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNotNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNotNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNotNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNotNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNotNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNotNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNotNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNotNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNotNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNotNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNotNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNotNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNotNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNotNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNotNull(selectionData.calculateYearlyAreaKPIs);


                Assert.AreEqual(CalculateKPIsType.YEARLY, selectionData.calculateYearlyStationKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.STATION, selectionData.calculateYearlyStationKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.YEARLY, selectionData.calculateYearlyModuleKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MODULE, selectionData.calculateYearlyModuleKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.YEARLY, selectionData.calculateYearlyMachineKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MACHINE, selectionData.calculateYearlyMachineKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.YEARLY, selectionData.calculateYearlyAreaKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.AREA, selectionData.calculateYearlyAreaKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.MONTHLY, selectionData.calculateMonthlyStationKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.STATION, selectionData.calculateMonthlyStationKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.MONTHLY, selectionData.calculateMonthlyModuleKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MODULE, selectionData.calculateMonthlyModuleKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.MONTHLY, selectionData.calculateMonthlyMachineKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MACHINE, selectionData.calculateMonthlyMachineKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.MONTHLY, selectionData.calculateMonthlyAreaKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.AREA, selectionData.calculateMonthlyAreaKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.WEEKLY, selectionData.calculateWeeklyStationKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.STATION, selectionData.calculateWeeklyStationKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.WEEKLY, selectionData.calculateWeeklyModuleKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MODULE, selectionData.calculateWeeklyModuleKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.WEEKLY, selectionData.calculateWeeklyMachineKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MACHINE, selectionData.calculateWeeklyMachineKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.WEEKLY, selectionData.calculateWeeklyAreaKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.AREA, selectionData.calculateWeeklyAreaKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.SHIFT, selectionData.calculateShiftStationKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.STATION, selectionData.calculateShiftStationKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.SHIFT, selectionData.calculateShiftModuleKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MODULE, selectionData.calculateShiftModuleKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.SHIFT, selectionData.calculateShiftMachineKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MACHINE, selectionData.calculateShiftMachineKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.SHIFT, selectionData.calculateShiftAreaKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.AREA, selectionData.calculateShiftAreaKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.DAILY, selectionData.calculateDailyStationKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.STATION, selectionData.calculateDailyStationKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.DAILY, selectionData.calculateDailyModuleKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MODULE, selectionData.calculateDailyModuleKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.DAILY, selectionData.calculateDailyMachineKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MACHINE, selectionData.calculateDailyMachineKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.DAILY, selectionData.calculateDailyAreaKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.AREA, selectionData.calculateDailyAreaKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.HOURLY, selectionData.calculateHourlyStationKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.STATION, selectionData.calculateHourlyStationKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.HOURLY, selectionData.calculateHourlyMachineKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MACHINE, selectionData.calculateHourlyMachineKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.HOURLY, selectionData.calculateHourlyModuleKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.MODULE, selectionData.calculateHourlyModuleKPIs.CalculationType);
                Assert.AreEqual(CalculateKPIsType.HOURLY, selectionData.calculateHourlyAreaKPIs.CalculateKPIsType);
                Assert.AreEqual(CalculationType.AREA, selectionData.calculateHourlyAreaKPIs.CalculationType);
            }
            else
            {
                Assert.IsNull(selectionData.calculateHourlyMachineKPIs);
                Assert.IsNull(selectionData.calculateHourlyStationKPIs);
                Assert.IsNull(selectionData.calculateHourlyModuleKPIs);
                Assert.IsNull(selectionData.calculateHourlyAreaKPIs);

                Assert.IsNull(selectionData.calculateDailyMachineKPIs);
                Assert.IsNull(selectionData.calculateDailyStationKPIs);
                Assert.IsNull(selectionData.calculateDailyModuleKPIs);
                Assert.IsNull(selectionData.calculateDailyAreaKPIs);

                Assert.IsNull(selectionData.calculateShiftMachineKPIs);
                Assert.IsNull(selectionData.calculateShiftStationKPIs);
                Assert.IsNull(selectionData.calculateShiftModuleKPIs);
                Assert.IsNull(selectionData.calculateShiftAreaKPIs);

                Assert.IsNull(selectionData.calculateWeeklyMachineKPIs);
                Assert.IsNull(selectionData.calculateWeeklyStationKPIs);
                Assert.IsNull(selectionData.calculateWeeklyModuleKPIs);
                Assert.IsNull(selectionData.calculateWeeklyAreaKPIs);

                Assert.IsNull(selectionData.calculateMonthlyMachineKPIs);
                Assert.IsNull(selectionData.calculateMonthlyStationKPIs);
                Assert.IsNull(selectionData.calculateMonthlyModuleKPIs);
                Assert.IsNull(selectionData.calculateMonthlyAreaKPIs);

                Assert.IsNull(selectionData.calculateYearlyMachineKPIs);
                Assert.IsNull(selectionData.calculateYearlyStationKPIs);
                Assert.IsNull(selectionData.calculateYearlyModuleKPIs);
                Assert.IsNull(selectionData.calculateYearlyAreaKPIs);
            }

        }

        [DataRow("1")]
        [DataRow("2")]
        [DataRow("3")]
        [DataRow("xxxxxx")]
        [TestMethod]
        public void TestPrintMenuLevel2(string testvalue)
        {
            string stagingLevel = "TEST";
            SelectionData selectionData = new SelectionData();
            selectionData.appSettings = new(stagingLevel);
            selectionData = Helper.PrintMenuLevel2(selectionData, testvalue);


            if (testvalue == "1")
            {
                Assert.AreEqual(testvalue, selectionData.level2Menu);
                Assert.AreEqual(testvalue, selectionData.level2MenuYear);
                Assert.IsNull(selectionData.level2MenuMonth);
                Assert.IsNull(selectionData.level2MenuDay);
            }
            else if (testvalue == "2")
            {
                Assert.AreEqual(testvalue, selectionData.level2Menu);
                Assert.AreEqual(testvalue, selectionData.level2MenuYear);
                Assert.AreEqual(testvalue, selectionData.level2MenuMonth);
                Assert.IsNull(selectionData.level2MenuDay);
            }
            else if (testvalue == "3")
            {
                Assert.AreEqual(testvalue, selectionData.level2Menu);
                Assert.AreEqual(testvalue, selectionData.level2MenuYear);
                Assert.AreEqual(testvalue, selectionData.level2MenuMonth);
                Assert.AreEqual(testvalue, selectionData.level2MenuDay);
            }
            else
            {
                Assert.AreEqual("Unknown", selectionData.level2Menu);
                Assert.IsNull(selectionData.level2MenuYear);
                Assert.IsNull(selectionData.level2MenuMonth);
                Assert.IsNull(selectionData.level2MenuDay);
            }

        }
    }
}