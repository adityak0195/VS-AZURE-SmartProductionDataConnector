﻿using KpiCalculator.JSON;
using KpiCalculator.Data;
using KpiCalculator.Data.Dataprovider;
using System.Reflection.PortableExecutable;

namespace KpiCalculatorTest
{
    [TestClass]
    public class TestMssql
    {



        [TestMethod]
        [DataRow("CVSTEST")]
        public void GetListOfShifts(string dbName)
        {
            // Arrange
            TestHelper<TestConnection> testHelper = new();
            DataMssql dataMssql = new(testHelper.AppSettings.Settings?.settingsKpiCalculator.mssql.Find(x => x.name == dbName));
            DateTime shiftStartOfDayUtcBased = new(2024, 1, 1, 0, 0, 0);
            DateTime shiftEndOfDayUtcBased = new(2025, 1, 1, 1, 0, 0);
            string machine = "KBCVSTESTMACHINE4KPICALCULATOR1.1MachineThing";

            // Act
            JsonOutputListOfShiftDefinitions result = Shifts.GetListOfShiftDefinitions(dataMssql, machine, shiftStartOfDayUtcBased, shiftEndOfDayUtcBased);

            // Assert
            Assert.AreEqual("OK", result.State);

        }

        [TestMethod]
        [DataRow("CVSTEST")]
        public void GetCurrentOrNextShift(string dbName)
        {
            // Arrange
            TestHelper<TestConnection> testHelper = new();
            DataMssql dataMssql = new(testHelper.AppSettings.Settings?.settingsKpiCalculator.mssql.Find(x => x.name == dbName));
            string machine = "KBCVSTESTMACHINE4KPICALCULATOR1.1MachineThing";

            // Act
            JsonOutputListOfShiftDefinitions result = Shifts.GetCurrentOrNextShiftDefinition(dataMssql, machine, DateTime.UtcNow);

            // Assert
            Assert.AreEqual("OK", result.State);

        }

        [TestMethod]
        [DataRow("CVSTEST")]
        public void GetLastShift(string dbName)
        {
            // Arrange
            TestHelper<TestConnection> testHelper = new();
            DataMssql dataMssql = new(testHelper.AppSettings.Settings?.settingsKpiCalculator.mssql.Find(x => x.name == dbName));
            string machine = "KBCVSTESTMACHINE4KPICALCULATOR1.1MachineThing";

            // Act
            JsonOutputListOfShiftDefinitions result = Shifts.GetLastShiftDefinition(dataMssql, machine, DateTime.UtcNow);

            // Assert
            Assert.AreEqual("OK", result.State);

        }

        [TestMethod]
        [DataRow("CVSTEST")]
        public void CalulateKPIsForSingleStation(string dbName)
        {
            // Arrange
            TestHelper<TestConnection> testHelper = new();
            DataMssql dataMssql = new(testHelper.AppSettings.Settings?.settingsKpiCalculator.mssql.Find(x => x.name == dbName));
            DateTime shiftStartOfDayUtcBased = new(2024, 10, 22, 0, 0, 0);
            DateTime shiftEndOfDayUtcBased = new(2024, 10, 23, 0, 0, 0);
            string calculationBase = "TEST";
            string machine = "KBCVSTESTMACHINE4KPICALCULATOR1.1MachineThing";
            string station = "KBCVSTESTSTATION4KPICALCULATOR1.1StationThing";

            // Act
            JsonOutputSimpleState result = CalculateKPIs.CalulateKPIsForSingleStation(dataMssql, shiftStartOfDayUtcBased, shiftEndOfDayUtcBased, calculationBase, machine, station, 60);

            // Assert
            Assert.AreEqual("OK", result.State);

        }

        [TestMethod]
        [DataRow("CVSTEST")]
        public void CalulateKPIsForSingleMachine(string dbName)
        {
            // Arrange
            TestHelper<TestConnection> testHelper = new();
            DataMssql dataMssql = new(testHelper.AppSettings.Settings?.settingsKpiCalculator.mssql.Find(x => x.name == dbName));
            DateTime shiftStartOfDayUtcBased = new(2024, 1, 1, 0, 0, 0);
            DateTime shiftEndOfDayUtcBased = new(2024, 1, 1, 1, 0, 0);
            string calculationBase = "TEST";
            string machine = "KBCVSTESTMACHINE4KPICALCULATOR1.1MachineThing";

            // Act
            JsonOutputSimpleState result = CalculateKPIs.CalulateKPIsForSingleMachine(dataMssql, shiftStartOfDayUtcBased, shiftEndOfDayUtcBased, calculationBase, machine, 60);

            // Assert
            Assert.AreEqual("OK", result.State);

        }

        [TestMethod]
        [DataRow("CVSTEST")]
        public void CalulateKPIsForSingleArea(string dbName)
        {
            // Arrange
            TestHelper<TestConnection> testHelper = new();
            DataMssql dataMssql = new(testHelper.AppSettings.Settings?.settingsKpiCalculator.mssql.Find(x => x.name == dbName));
            DateTime shiftStartOfDayUtcBased = new(2024, 1, 1, 0, 0, 0);
            DateTime shiftEndOfDayUtcBased = new(2024, 1, 1, 1, 0, 0);
            string calculationBase = "TEST";
            string area = "KBCVSTESTAREA4KPICALCULATION1AreaThing";

            // Act
            JsonOutputSimpleState result = CalculateKPIs.CalulateKPIsForSingleArea(dataMssql, shiftStartOfDayUtcBased, shiftEndOfDayUtcBased, calculationBase, area, 60);

            // Assert
            Assert.AreEqual("OK", result.State);

        }

        [TestMethod]
        [DataRow("CVSTEST")]
        public void CalulateKPIsForSinglePlant(string dbName)
        {
            // Arrange
            TestHelper<TestConnection> testHelper = new();
            DataMssql dataMssql = new(testHelper.AppSettings.Settings?.settingsKpiCalculator.mssql.Find(x => x.name == dbName));
            DateTime shiftStartOfDayUtcBased = new(2025, 1, 1, 0, 0, 0);
            DateTime shiftEndOfDayUtcBased = new(2025, 1, 1, 1, 0, 0);
            string calculationBase = "TEST";
            string plant = "KBCVSTESTPLANT4KPICALCULATION1PlantThing";

            // Act
            JsonOutputSimpleState result = CalculateKPIs.CalulateKPIsForSinglePlant(dataMssql, shiftStartOfDayUtcBased, shiftEndOfDayUtcBased, calculationBase, plant, 60);

            // Assert
            Assert.AreEqual("OK", result.State);

        }

        [TestMethod]
        [DataRow("CVSTEST")]
        public void CalulateKPIsForSingleModule(string dbName)
        {
            // Arrange
            TestHelper<TestConnection> testHelper = new();
            DataMssql dataMssql = new(testHelper.AppSettings.Settings?.settingsKpiCalculator.mssql.Find(x => x.name == dbName));
            DateTime shiftStartOfDayUtcBased = new(2024, 1, 1, 0, 0, 0);
            DateTime shiftEndOfDayUtcBased = new(2024, 1, 1, 1, 0, 0);
            string calculationBase = "TEST";
            string module = "xxxx";

            // Act
            JsonOutputSimpleState result = CalculateKPIs.CalulateKPIsForSingleModule(dataMssql, shiftStartOfDayUtcBased, shiftEndOfDayUtcBased, calculationBase, module, 60);

            // Assert
            Assert.AreEqual("OK", result.State);

        }

        [TestMethod]
        [DataRow("CVSTEST")]
        public void connect(string dbName)
        {
            // Arrange
            TestHelper<TestConnection> testHelper = new();
            DataMssql dataMssql = new(testHelper.AppSettings.Settings?.settingsKpiCalculator.mssql.Find(x => x.name == dbName));

            // Act
            JsonOutputTestConnection result = TestConnection.GetResult(dataMssql);

            // Assert
            Assert.AreEqual("MSSQL Connection OK", result.Message[..19]);
            Assert.AreEqual("OK", result.state);
            Assert.IsNotNull(result.JavaDate);

        }

        [TestMethod]
        [DataRow("CVSTEST")]
        public void GetListOfAreas(string dbName)
        {
            // Arrange
            TestHelper<AreasMachinesModulesStations> testHelper = new();
            DataMssql dataMssql = new(testHelper.AppSettings.Settings?.settingsKpiCalculator.mssql.Find(x => x.name == dbName));

            // Act
            JsonOutputListOfAreasMachinesModulesStations result = AreasMachinesModulesStations.GetListOfAreas(dataMssql);

            // Assert
            Assert.AreEqual("OK", result.State);
       }

        [TestMethod]
        [DataRow("CVSTEST")]
        public void GetListOfModules(string dbName)
        {
            // Arrange
            TestHelper<AreasMachinesModulesStations> testHelper = new();
            DataMssql dataMssql = new(testHelper.AppSettings.Settings?.settingsKpiCalculator.mssql.Find(x => x.name == dbName));

            // Act
            JsonOutputListOfAreasMachinesModulesStations result = AreasMachinesModulesStations.GetListOfModules(dataMssql);

            // Assert
            Assert.AreEqual("OK", result.State);
        }

        [TestMethod]
        [DataRow("CVSTEST")]
        public void GetListOfMachines(string dbName)
        {
            // Arrange
            TestHelper<AreasMachinesModulesStations> testHelper = new();
            DataMssql dataMssql = new(testHelper.AppSettings.Settings?.settingsKpiCalculator.mssql.Find(x => x.name == dbName));

            // Act
            JsonOutputListOfAreasMachinesModulesStations result = AreasMachinesModulesStations.GetListOfMachines(dataMssql);

            // Assert
            Assert.AreEqual("OK", result.State);
        }

        [TestMethod]
        [DataRow("CVSTEST")]
        public void GetListOfStations(string dbName)
        {
            // Arrange
            TestHelper<AreasMachinesModulesStations> testHelper = new();
            DataMssql dataMssql = new(testHelper.AppSettings.Settings?.settingsKpiCalculator.mssql.Find(x => x.name == dbName));

            // Act
            JsonOutputListOfAreasMachinesModulesStations result = AreasMachinesModulesStations.GetListOfStations(dataMssql);

            // Assert
            Assert.AreEqual("OK", result.State);
        }

        [TestMethod]
        [DataRow("CVSTEST")]
        public void GetListOfPlants(string dbName)
        {
            // Arrange
            TestHelper<AreasMachinesModulesStations> testHelper = new();
            DataMssql dataMssql = new(testHelper.AppSettings.Settings?.settingsKpiCalculator.mssql.Find(x => x.name == dbName));

            // Act
            JsonOutputListOfAreasMachinesModulesStations result = AreasMachinesModulesStations.GetListOfPlants(dataMssql);

            // Assert
            Assert.AreEqual("OK", result.State);
        }


        [TestMethod]
        [DataRow("CVSTEST")]
        public void SetKPIValues(string dbName)
        {
            // Arrange
            TestHelper<CalculateKPIs> testHelper = new();
            DataMssql dataMssql = new(testHelper.AppSettings.Settings?.settingsKpiCalculator.mssql.Find(x => x.name == dbName));
            JsonOutputKPIValues jsonOutputKPIValues = new();

            JsonOutputKPIValue jsonOutputKPIValue = new();
            jsonOutputKPIValue.Machine = "KBCVSTESTMACHINE4KPICALCULATOR1.1MachineThing";
            jsonOutputKPIValue.KPIName = "TestKPI";
            jsonOutputKPIValue.KPICalculationBase = "TestCalculationBase";
            jsonOutputKPIValue.KPITimeBase = "TestTimeBase";
            jsonOutputKPIValue.KPIStartTime = new(2024, 1, 1, 0, 0, 0);
            jsonOutputKPIValue.KPIEndTime = new(2024, 1, 1, 2, 0, 0);
            jsonOutputKPIValue.KPIFloatValue = 1.0m;
            jsonOutputKPIValues.KPIValues.Add(jsonOutputKPIValue);

            jsonOutputKPIValue.Machine = "KBCVSTESTMACHINE4KPICALCULATOR1.1MachineThing";
            jsonOutputKPIValue.KPIName = "TestKPI";
            jsonOutputKPIValue.KPICalculationBase = "TestCalculationBase";
            jsonOutputKPIValue.KPITimeBase = "TestTimeBase";
            jsonOutputKPIValue.KPIStartTime = new(2024, 1, 2, 0, 0, 0);
            jsonOutputKPIValue.KPIEndTime = new(2024, 1, 1, 3, 0, 0);
            jsonOutputKPIValue.KPIFloatValue = 1.0m;
            jsonOutputKPIValues.KPIValues.Add(jsonOutputKPIValue);


            // Act
            JsonOutputSimpleState result = dataMssql.SetKPIValues(jsonOutputKPIValues, "KBCVSTESTMACHINE4KPICALCULATOR1.1MachineThing", new DateTime(2024, 1, 1, 0, 0, 0), new DateTime(2024, 1, 3, 0, 0, 0), "TEST");

            // Assert
            Assert.AreEqual("OK", result.State);
        }

    }
}
