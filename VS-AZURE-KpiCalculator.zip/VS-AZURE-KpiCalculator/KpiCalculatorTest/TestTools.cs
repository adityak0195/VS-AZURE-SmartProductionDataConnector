﻿using KpiCalculator.JSON;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KpiCalculator.Logic;
using static KpiCalculator.Logic.CalculateKPIs;

namespace KpiCalculatorTest
{
    [TestClass]
    public class TestTools
    {
        private class TestTime
        {
            public DateTime DateTimeIn { get; set; }
            public DateTime DateTimeOutWithOffset { get; set; }
            public DateTime DateTimeOutWithoutOffset { get; set; }
        }

        private class TestTimes
        {
            public List<TestTime> Times = new();
        }

        [TestMethod]
        //Central European Standard Time --> Germany
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, -30, "Central European Standard Time", 60, 120)]
        //Central Standard Time --> BWG, DRT
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, -30, "Central Standard Time", -360, -300)]
        //GMT Standard Time --> MLK
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, -30, "GMT Standard Time", 0, 60)]

        public void CheckGetStartOfSlot(CalculateKPIsType calculateKPIsType, CalculationType calculationType, int plantOffset, string timeZone, int utcOffsetWinter, int utcOffsetSommer)
        {
            // Arrange
            CalculateKPIs calculateKPIs = new(calculateKPIsType, calculationType, "TEST");
            JsonOutputAreaMachineModuleStation stationMachineArea = new();
            stationMachineArea.ServerTimeZoneDB = timeZone;
            stationMachineArea.DayOffset = plantOffset;
            TestTimes testTimes = new();

            if (calculateKPIsType == CalculateKPIsType.HOURLY)
            {
                DateTime actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 0, 0, 0));
                DateTime expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 3, 4, 5));
                expected = new(2024, 1, 1, 3, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 0, 0, 0));
                expected = new(2024, 6, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 3, 4, 5));
                expected = new(2024, 6, 1, 3, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected });
            }
            else if (calculateKPIsType == CalculateKPIsType.SHIFT)
            {
                DateTime actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 0, 0, 0));
                DateTime expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected });
            }
            else if (calculateKPIsType == CalculateKPIsType.DAILY)
            {
                DateTime actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 0, 0, 0));
                DateTime expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 2, 3, 4));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 0, 0, 0));
                expected = new(2024, 6, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 2, 3, 4));
                expected = new(2024, 6, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });
            }
            else if (calculateKPIsType == CalculateKPIsType.WEEKLY)
            {
                DateTime actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 0, 0, 0));
                DateTime expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 2, 3, 4));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 2, 0, 0, 0));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 2, 2, 3, 4));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 3, 0, 0, 0));
                expected = new(2024, 6, 3, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 3, 2, 3, 4));
                expected = new(2024, 6, 3, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 0, 0, 0));
                expected = new(2024, 5, 27, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 2, 3, 4));
                expected = new(2024, 5, 27, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });
            }
            else if (calculateKPIsType == CalculateKPIsType.MONTHLY)
            {
                DateTime actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 0, 0, 0));
                DateTime expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 2, 3, 4));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 2, 0, 0, 0));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 2, 2, 3, 4));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 3, 0, 0, 0));
                expected = new(2024, 6, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 3, 2, 3, 4));
                expected = new(2024, 6, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 0, 0, 0));
                expected = new(2024, 6, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 2, 3, 4));
                expected = new(2024, 6, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });
            }
            else if (calculateKPIsType == CalculateKPIsType.YEARLY)
            {
                DateTime actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 0, 0, 0));
                DateTime expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 2, 3, 4));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 2, 0, 0, 0));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 2, 2, 3, 4));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 3, 0, 0, 0));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 3, 2, 3, 4));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 0, 0, 0));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 2, 3, 4));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });
            }

            // Act
            foreach (TestTime testTime in testTimes.Times)
            {
                DateTime resultWithOffset;
                DateTime resultWithOutOffset;

                try
                {
                    resultWithOffset = calculateKPIs.GetStartOfSlot(testTime.DateTimeIn, stationMachineArea, true);
                    resultWithOutOffset = calculateKPIs.GetStartOfSlot(testTime.DateTimeIn, stationMachineArea, false);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    Assert.IsTrue(calculateKPIsType == CalculateKPIsType.SHIFT);
                    resultWithOffset = testTime.DateTimeOutWithOffset;
                    resultWithOutOffset = testTime.DateTimeOutWithoutOffset;
                }

                // Assert
                Assert.AreEqual(calculateKPIsType, calculateKPIs.CalculateKPIsType);
                Assert.AreEqual(calculationType, calculateKPIs.CalculationType);
                Assert.AreEqual(testTime.DateTimeOutWithoutOffset, resultWithOutOffset);
                Assert.AreEqual(testTime.DateTimeOutWithOffset, resultWithOffset);
            }
        }

        [TestMethod]
        //Central European Standard Time --> Germany
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, -30, "Central European Standard Time", 60, 120)]
        //Central Standard Time --> BWG, DRT
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, -30, "Central Standard Time", -360, -300)]
        //GMT Standard Time --> MLK
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, -30, "GMT Standard Time", 0, 60)]
        public void CheckGetEndOfSlot(CalculateKPIsType calculateKPIsType, CalculationType calculationType, int plantOffset, string timeZone, int utcOffsetWinter, int utcOffsetSommer)
        {
            // Arrange
            CalculateKPIs calculateKPIs = new(calculateKPIsType, calculationType, "TEST");
            JsonOutputAreaMachineModuleStation stationMachineArea = new();
            stationMachineArea.ServerTimeZoneDB = timeZone;
            stationMachineArea.DayOffset = plantOffset;
            TestTimes testTimes = new();

            if (calculateKPIsType == CalculateKPIsType.HOURLY)
            {
                DateTime actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 0, 0, 0));
                DateTime expected = new(2024, 1, 1, 1, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 3, 4, 5));
                expected = new(2024, 1, 1, 4, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 0, 0, 0));
                expected = new(2024, 6, 1, 1, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 3, 4, 5));
                expected = new(2024, 6, 1, 4, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected });
            }
            else if (calculateKPIsType == CalculateKPIsType.SHIFT)
            {
                DateTime actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 0, 0, 0));
                DateTime expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected });
            }
            else if (calculateKPIsType == CalculateKPIsType.DAILY)
            {
                DateTime actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 0, 0, 0));
                DateTime expected = new(2024, 1, 2, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 2, 3, 4));
                expected = new(2024, 1, 2, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 0, 0, 0));
                expected = new(2024, 6, 2, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 2, 3, 4));
                expected = new(2024, 6, 2, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });
            }
            else if (calculateKPIsType == CalculateKPIsType.WEEKLY)
            {
                DateTime actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 0, 0, 0));
                DateTime expected = new(2024, 1, 8, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 2, 3, 4));
                expected = new(2024, 1, 8, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 2, 0, 0, 0));
                expected = new(2024, 1, 8, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 2, 2, 3, 4));
                expected = new(2024, 1, 8, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 3, 0, 0, 0));
                expected = new(2024, 6, 10, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 3, 2, 3, 4));
                expected = new(2024, 6, 10, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 0, 0, 0));
                expected = new(2024, 6, 3, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 2, 3, 4));
                expected = new(2024, 6, 3, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });
            }
            else if (calculateKPIsType == CalculateKPIsType.MONTHLY)
            {
                DateTime actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 0, 0, 0));
                DateTime expected = new(2024, 2, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 2, 3, 4));
                expected = new(2024, 2, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 2, 0, 0, 0));
                expected = new(2024, 2, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 2, 2, 3, 4));
                expected = new(2024, 2, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 3, 0, 0, 0));
                expected = new(2024, 7, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 3, 2, 3, 4));
                expected = new(2024, 7, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 0, 0, 0));
                expected = new(2024, 7, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 2, 3, 4));
                expected = new(2024, 7, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });
            }
            else if (calculateKPIsType == CalculateKPIsType.YEARLY)
            {
                DateTime actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 0, 0, 0));
                DateTime expected = new(2025, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 2, 3, 4));
                expected = new(2025, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 2, 0, 0, 0));
                expected = new(2025, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 2, 2, 3, 4));
                expected = new(2025, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 3, 0, 0, 0));
                expected = new(2025, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 3, 2, 3, 4));
                expected = new(2025, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 0, 0, 0));
                expected = new(2025, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 2, 3, 4));
                expected = new(2025, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });
            }

            // Act
            foreach (TestTime testTime in testTimes.Times)
            {
                DateTime resultWithOffset;
                DateTime resultWithOutOffset;

                try
                {
                    resultWithOffset = calculateKPIs.GetEndOfSlot(testTime.DateTimeIn, stationMachineArea, true);
                    resultWithOutOffset = calculateKPIs.GetEndOfSlot(testTime.DateTimeIn, stationMachineArea, false);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    Assert.IsTrue(calculateKPIsType == CalculateKPIsType.SHIFT);
                    resultWithOffset = testTime.DateTimeOutWithOffset;
                    resultWithOutOffset = testTime.DateTimeOutWithoutOffset;
                }

                // Assert
                Assert.AreEqual(calculateKPIsType, calculateKPIs.CalculateKPIsType);
                Assert.AreEqual(calculationType, calculateKPIs.CalculationType);
                Assert.AreEqual(testTime.DateTimeOutWithoutOffset, resultWithOutOffset);
                Assert.AreEqual(testTime.DateTimeOutWithOffset, resultWithOffset);
            }
        }


        [TestMethod]
        //Central European Standard Time --> Germany
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, -30, "Central European Standard Time", 60, 120)]
        //Central Standard Time --> BWG, DRT
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, -30, "Central Standard Time", -360, -300)]
        //GMT Standard Time --> MLK
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, -30, "GMT Standard Time", 0, 60)]
        public void CheckGetStartOfPriviousSlot(CalculateKPIsType calculateKPIsType, CalculationType calculationType, int plantOffset, string timeZone, int utcOffsetWinter, int utcOffsetSommer)
        {
            // Arrange
            CalculateKPIs calculateKPIs = new(calculateKPIsType, calculationType, "TEST");
            JsonOutputAreaMachineModuleStation stationMachineArea = new();
            stationMachineArea.ServerTimeZoneDB = timeZone;
            stationMachineArea.DayOffset = plantOffset;
            TestTimes testTimes = new();

            if (calculateKPIsType == CalculateKPIsType.HOURLY)
            {
                DateTime actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 0, 0, 0));
                DateTime expected = new(2023, 12, 31, 23, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 3, 4, 5));
                expected = new(2024, 1, 1, 2, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 0, 0, 0));
                expected = new(2024, 5, 31, 23, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 3, 4, 5));
                expected = new(2024, 6, 1, 2, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected });
            }
            else if (calculateKPIsType == CalculateKPIsType.SHIFT)
            {
                DateTime actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 0, 0, 0));
                DateTime expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected });
            }
            else if (calculateKPIsType == CalculateKPIsType.DAILY)
            {
                DateTime actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 0, 0, 0));
                DateTime expected = new(2023, 12, 31, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 2, 3, 4));
                expected = new(2023, 12, 31, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 0, 0, 0));
                expected = new(2024, 5, 31, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 2, 3, 4));
                expected = new(2024, 5, 31, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });
            }
            else if (calculateKPIsType == CalculateKPIsType.WEEKLY)
            {
                DateTime actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 0, 0, 0));
                DateTime expected = new(2023, 12, 25, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 2, 3, 4));
                expected = new(2023, 12, 25, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 2, 0, 0, 0));
                expected = new(2023, 12, 25, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 2, 2, 3, 4));
                expected = new(2023, 12, 25, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 3, 0, 0, 0));
                expected = new(2024, 5, 27, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 3, 2, 3, 4));
                expected = new(2024, 5, 27, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 0, 0, 0));
                expected = new(2024, 5, 20, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 2, 3, 4));
                expected = new(2024, 5, 20, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });
            }
            else if (calculateKPIsType == CalculateKPIsType.MONTHLY)
            {
                DateTime actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 0, 0, 0));
                DateTime expected = new(2023, 12, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 2, 3, 4));
                expected = new(2023, 12, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 2, 0, 0, 0));
                expected = new(2023, 12, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 2, 2, 3, 4));
                expected = new(2023, 12, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 3, 0, 0, 0));
                expected = new(2024, 5, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 3, 2, 3, 4));
                expected = new(2024, 5, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 0, 0, 0));
                expected = new(2024, 5, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 2, 3, 4));
                expected = new(2024, 5, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });
            }
            else if (calculateKPIsType == CalculateKPIsType.YEARLY)
            {
                DateTime actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 0, 0, 0));
                DateTime expected = new(2023, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 2, 3, 4));
                expected = new(2023, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 2, 0, 0, 0));
                expected = new(2023, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 2, 2, 3, 4));
                expected = new(2023, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 3, 0, 0, 0));
                expected = new(2023, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 3, 2, 3, 4));
                expected = new(2023, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 0, 0, 0));
                expected = new(2023, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 2, 3, 4));
                expected = new(2023, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });
            }

            // Act
            foreach (TestTime testTime in testTimes.Times)
            {
                DateTime resultWithOffset;
                DateTime resultWithOutOffset;

                try
                {
                    resultWithOffset = calculateKPIs.GetStartOfPriviousSlot(testTime.DateTimeIn, stationMachineArea, true);
                    resultWithOutOffset = calculateKPIs.GetStartOfPriviousSlot(testTime.DateTimeIn, stationMachineArea, false);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    Assert.IsTrue(calculateKPIsType == CalculateKPIsType.SHIFT);
                    resultWithOffset = testTime.DateTimeOutWithOffset;
                    resultWithOutOffset = testTime.DateTimeOutWithoutOffset;
                }

                // Assert
                Assert.AreEqual(calculateKPIsType, calculateKPIs.CalculateKPIsType);
                Assert.AreEqual(calculationType, calculateKPIs.CalculationType);
                Assert.AreEqual(testTime.DateTimeOutWithoutOffset, resultWithOutOffset);
                Assert.AreEqual(testTime.DateTimeOutWithOffset, resultWithOffset);
            }
        }

        [TestMethod]
        //Central European Standard Time --> Germany
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, 60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, -60, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, 30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, -30, "Central European Standard Time", 60, 120)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, -30, "Central European Standard Time", 60, 120)]
        //Central Standard Time --> BWG, DRT
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, 60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, -60, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, 30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, -30, "Central Standard Time", -360, -300)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, -30, "Central Standard Time", -360, -300)]
        //GMT Standard Time --> MLK
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, 60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, -60, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, 30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.MACHINE, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.MACHINE, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.MACHINE, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.MACHINE, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.HOURLY, CalculationType.STATION, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.SHIFT, CalculationType.STATION, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.DAILY, CalculationType.STATION, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.WEEKLY, CalculationType.STATION, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.MONTHLY, CalculationType.STATION, -30, "GMT Standard Time", 0, 60)]
        [DataRow(CalculateKPIsType.YEARLY, CalculationType.STATION, -30, "GMT Standard Time", 0, 60)]
        public void CheckGetEndOfPriviousSlot(CalculateKPIsType calculateKPIsType, CalculationType calculationType, int plantOffset, string timeZone, int utcOffsetWinter, int utcOffsetSommer)
        {
            // Arrange
            CalculateKPIs calculateKPIs = new(calculateKPIsType, calculationType, "TEST");
            JsonOutputAreaMachineModuleStation stationMachineArea = new();
            stationMachineArea.ServerTimeZoneDB = timeZone;
            stationMachineArea.DayOffset = plantOffset;
            TestTimes testTimes = new();

            if (calculateKPIsType == CalculateKPIsType.HOURLY)
            {
                DateTime actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 0, 0, 0));
                DateTime expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 3, 4, 5));
                expected = new(2024, 1, 1, 3, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 0, 0, 0));
                expected = new(2024, 6, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 3, 4, 5));
                expected = new(2024, 6, 1, 3, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected });
            }
            else if (calculateKPIsType == CalculateKPIsType.SHIFT)
            {
                DateTime actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 0, 0, 0));
                DateTime expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected });
            }
            else if (calculateKPIsType == CalculateKPIsType.DAILY)
            {
                DateTime actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 0, 0, 0));
                DateTime expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 2, 3, 4));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 0, 0, 0));
                expected = new(2024, 6, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 2, 3, 4));
                expected = new(2024, 6, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });
            }
            else if (calculateKPIsType == CalculateKPIsType.WEEKLY)
            {
                DateTime actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 0, 0, 0));
                DateTime expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 2, 3, 4));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 2, 0, 0, 0));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 2, 2, 3, 4));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 3, 0, 0, 0));
                expected = new(2024, 6, 3, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 3, 2, 3, 4));
                expected = new(2024, 6, 3, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 0, 0, 0));
                expected = new(2024, 5, 27, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 2, 3, 4));
                expected = new(2024, 5, 27, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });
            }
            else if (calculateKPIsType == CalculateKPIsType.MONTHLY)
            {
                DateTime actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 0, 0, 0));
                DateTime expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 2, 3, 4));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 2, 0, 0, 0));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 2, 2, 3, 4));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 3, 0, 0, 0));
                expected = new(2024, 6, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 3, 2, 3, 4));
                expected = new(2024, 6, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 0, 0, 0));
                expected = new(2024, 6, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 2, 3, 4));
                expected = new(2024, 6, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetSommer).AddMinutes(plantOffset) });
            }
            else if (calculateKPIsType == CalculateKPIsType.YEARLY)
            {
                DateTime actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 0, 0, 0));
                DateTime expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 1, 2, 3, 4));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 2, 0, 0, 0));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 1, 2, 2, 3, 4));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 3, 0, 0, 0));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 3, 2, 3, 4));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 0, 0, 0));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });

                actual = calculateKPIs.GetBaseTime(new(2024, 6, 1, 2, 3, 4));
                expected = new(2024, 1, 1, 0, 0, 0);
                testTimes.Times.Add(new TestTime { DateTimeIn = actual, DateTimeOutWithoutOffset = expected, DateTimeOutWithOffset = expected.AddMinutes(-utcOffsetWinter).AddMinutes(plantOffset) });
            }

            // Act
            foreach (TestTime testTime in testTimes.Times)
            {
                DateTime resultWithOffset;
                DateTime resultWithOutOffset;

                try
                {
                    resultWithOffset = calculateKPIs.GetEndOfPriviousSlot(testTime.DateTimeIn, stationMachineArea, true);
                    resultWithOutOffset = calculateKPIs.GetEndOfPriviousSlot(testTime.DateTimeIn, stationMachineArea, false);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    Assert.IsTrue(calculateKPIsType == CalculateKPIsType.SHIFT);
                    resultWithOffset = testTime.DateTimeOutWithOffset;
                    resultWithOutOffset = testTime.DateTimeOutWithoutOffset;
                }

                // Assert
                Assert.AreEqual(calculateKPIsType, calculateKPIs.CalculateKPIsType);
                Assert.AreEqual(calculationType, calculateKPIs.CalculationType);
                Assert.AreEqual(testTime.DateTimeOutWithoutOffset, resultWithOutOffset);
                Assert.AreEqual(testTime.DateTimeOutWithOffset, resultWithOffset);
            }
        }

        [TestMethod]
        public void CheckGetWeekOffset()
        {
            // Assert
            CalculateKPIs calculateKPIs = new(CalculateKPIsType.SHIFT, CalculationType.MACHINE, "TEST");
            Assert.AreEqual(0, calculateKPIs.GetWeekOffset(new DateTime(2024, 1, 1, 0, 0, 0))); //Monday
            Assert.AreEqual(1, calculateKPIs.GetWeekOffset(new DateTime(2024, 1, 2, 0, 0, 0))); //Tuesday
            Assert.AreEqual(2, calculateKPIs.GetWeekOffset(new DateTime(2024, 1, 3, 0, 0, 0))); //Wednesday
            Assert.AreEqual(3, calculateKPIs.GetWeekOffset(new DateTime(2024, 1, 4, 0, 0, 0))); //Thursday
            Assert.AreEqual(4, calculateKPIs.GetWeekOffset(new DateTime(2024, 1, 5, 0, 0, 0))); //Friday
            Assert.AreEqual(5, calculateKPIs.GetWeekOffset(new DateTime(2024, 1, 6, 0, 0, 0))); //Saturday
            Assert.AreEqual(6, calculateKPIs.GetWeekOffset(new DateTime(2024, 1, 7, 0, 0, 0))); //Sunday
        }

        [TestMethod]
        [DataRow("Central European Standard Time", 2024, 1, 1, 0, 0, 1*60)]
        [DataRow("Central European Standard Time", 2024, 8, 1, 0, 0, 2*60)]
        [DataRow("Central Standard Time", 2024, 1, 1, 0, 0, -6*60)]
        [DataRow("Central Standard Time", 2024, 8, 1, 0, 0, -5*60)]
        public void CheckGetUtcOffset(string timeZone, int testTimeYear, int testTimeMonth, int testTimeDay, int testTimeHour, int testTimeMinute, int expectedValue)
        {
            // Assert
            CalculateKPIs calculateKPIs = new(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, "TEST");
            DateTime testTime = new(testTimeYear, testTimeMonth, testTimeDay, testTimeHour, testTimeMinute, 0);
            Assert.AreEqual(expectedValue, calculateKPIs.GetUtcOffset(timeZone, testTime));
        }
    }
}
