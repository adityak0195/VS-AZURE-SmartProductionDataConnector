﻿using KBBasics;
using KBBasics.SetupForFileSystem;
using Microsoft.Extensions.Logging;


namespace KpiCalculatorTest
{
    internal class TestHelper<T>
    {
        internal ILoggerFactory? Factory;
        internal AppSettings AppSettings;
        internal TestHelper()
        {
            AppSettings = new("TEST");

            Assert.IsNotNull(AppSettings.Settings);
        }
    }
}
