﻿using KpiCalculator.JSON;
using Microsoft.Extensions.Logging;
using KBBasics.SetupForFileSystem;
using KpiCalculator.Data;
using KpiCalculator.Data.Dataprovider;
using System.Reflection.PortableExecutable;

namespace KpiCalculatorTest
{
    [TestClass]
    public class TestDBSnowflake
    {
        [TestMethod]
        [DataRow("RVS")]
        [DataRow("CVS")]
        public void connect(string division)
        {
            // Arrange
            TestHelper<TestConnection> testHelper = new();
            DataSnowflake dataSnowflake = new(testHelper.AppSettings.Settings?.settingsKpiCalculator.snowflake.Find(x => x.name == division));

            // Act
            JsonOutputTestConnection result = TestConnection.GetResult(dataSnowflake);

            // Assert
            Assert.AreEqual("Snowflake Connection OK", result.Message[..23]);
            Assert.AreEqual("OK", result.state);
            Assert.IsNotNull(result.JavaDate);

        }

        [TestMethod]
        [DataRow("RVS")]
        [DataRow("CVS")]
        public void GetListOfAreas(string division)
        {
            // Arrange
            TestHelper<AreasMachinesModulesStations> testHelper = new();
            DataSnowflake dataSnowflake = new(testHelper.AppSettings.Settings?.settingsKpiCalculator.snowflake.Find(x => x.name == division));

            // Act
            JsonOutputListOfAreasMachinesModulesStations result = AreasMachinesModulesStations.GetListOfAreas(dataSnowflake);

            // Assert
            Assert.AreEqual("OK", result.State);
        }

        [TestMethod]
        [DataRow("RVS")]
        [DataRow("CVS")]
        public void GetListOfMachines(string division)
        {
            // Arrange
            TestHelper<AreasMachinesModulesStations> testHelper = new();
            DataSnowflake dataSnowflake = new(testHelper.AppSettings.Settings?.settingsKpiCalculator.snowflake.Find(x => x.name == division));

            // Act
            JsonOutputListOfAreasMachinesModulesStations result = AreasMachinesModulesStations.GetListOfMachines(dataSnowflake);

            // Assert
            Assert.AreEqual("OK", result.State);
        }

        [TestMethod]
        [DataRow("RVS")]
        [DataRow("CVS")]
        public void GetListOfStations(string division)
        {
            // Arrange
            TestHelper<AreasMachinesModulesStations> testHelper = new();
            DataSnowflake dataSnowflake = new(testHelper.AppSettings.Settings?.settingsKpiCalculator.snowflake.Find(x => x.name == division));

            // Act
            JsonOutputListOfAreasMachinesModulesStations result = AreasMachinesModulesStations.GetListOfStations(dataSnowflake);

            // Assert
            Assert.AreEqual("OK", result.State);
        }

        [TestMethod]
        [DataRow("RVS")]
        [DataRow("CVS")]
        public void GetListOfKPIValues(string division)
        {
            // Arrange
            TestHelper<KPIValues> testHelper = new();
            DataSnowflake dataSnowflake = new(testHelper.AppSettings.Settings?.settingsKpiCalculator.snowflake.Find(x => x.name == division));

            // Act
            JsonOutputKPIValues result = dataSnowflake.GetKPIValues("KBLIBNG4MachineThing", DateTime.Now.AddDays(-1), DateTime.Now, "day");

            // Assert
            Assert.AreEqual("OK", result.State);
        }
    }
}
