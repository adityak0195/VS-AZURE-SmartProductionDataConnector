﻿using KBBasics.SetupForFileSystem;
using KpiCalculator.Logic;
using Org.BouncyCastle.Ocsp;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StartKpiCalculatorFromConsole
{
    public class SelectionData
    {
        public MsSQL? msSQL;
        public string? db;
        public AppSettings appSettings;
        public string? level1Menu;
        public string? level1MenuName;
        public string? level2Menu;
        public string? level2MenuDay;
        public string? level2MenuMonth;
        public string? level2MenuYear;
        public KpiCalculator.Logic.CalculateKPIs? calculateHourlyMachineKPIs;
        public KpiCalculator.Logic.CalculateKPIs? calculateHourlyStationKPIs;
        public KpiCalculator.Logic.CalculateKPIs? calculateHourlyModuleKPIs;
        public KpiCalculator.Logic.CalculateKPIs? calculateHourlyAreaKPIs;

        public KpiCalculator.Logic.CalculateKPIs? calculateDailyMachineKPIs;
        public KpiCalculator.Logic.CalculateKPIs? calculateDailyStationKPIs;
        public KpiCalculator.Logic.CalculateKPIs? calculateDailyModuleKPIs;
        public KpiCalculator.Logic.CalculateKPIs? calculateDailyAreaKPIs;

        public KpiCalculator.Logic.CalculateKPIs? calculateShiftMachineKPIs;
        public KpiCalculator.Logic.CalculateKPIs? calculateShiftStationKPIs;
        public KpiCalculator.Logic.CalculateKPIs? calculateShiftModuleKPIs;
        public KpiCalculator.Logic.CalculateKPIs? calculateShiftAreaKPIs;

        public KpiCalculator.Logic.CalculateKPIs? calculateWeeklyMachineKPIs;
        public KpiCalculator.Logic.CalculateKPIs? calculateWeeklyStationKPIs;
        public KpiCalculator.Logic.CalculateKPIs? calculateWeeklyModuleKPIs;
        public KpiCalculator.Logic.CalculateKPIs? calculateWeeklyAreaKPIs;

        public KpiCalculator.Logic.CalculateKPIs? calculateMonthlyMachineKPIs;
        public KpiCalculator.Logic.CalculateKPIs? calculateMonthlyStationKPIs;
        public KpiCalculator.Logic.CalculateKPIs? calculateMonthlyModuleKPIs;
        public KpiCalculator.Logic.CalculateKPIs? calculateMonthlyAreaKPIs;

        public KpiCalculator.Logic.CalculateKPIs? calculateYearlyMachineKPIs;
        public KpiCalculator.Logic.CalculateKPIs? calculateYearlyStationKPIs;
        public KpiCalculator.Logic.CalculateKPIs? calculateYearlyModuleKPIs;
        public KpiCalculator.Logic.CalculateKPIs? calculateYearlyAreaKPIs;

        public Boolean showDayMenu = true;
        public Boolean showMonthMenu = true;

    }
    static public class Helper
    {
        static public SelectionData PrintMenuLevel1(SelectionData selectionData, string stagingLevel, string? testData = null)
        {
            if (testData != null)
            {
                selectionData.level1Menu = testData;
            }
            else
            {
                Console.Clear();
                Console.WriteLine("**************************************************************************");
                Console.WriteLine("Found settings for: " + selectionData.db + " (" + selectionData.msSQL.server + ", " + selectionData.msSQL.database + ")");
                Console.WriteLine("**************************************************************************");
                Console.WriteLine(" 1:  CalculateHourlyKPIsForStations");
                Console.WriteLine(" 2:  CalculateHourlyKPIsForModules");
                Console.WriteLine(" 3:  CalculateHourlyKPIsForMachines");
                Console.WriteLine(" 4:  CalculateHourlyKPIsForAreas");
                Console.WriteLine(" 5:  Calculate all Hourly Types");
                Console.WriteLine("**************************************************************************");
                Console.WriteLine(" 6:  CalculateDailyKPIsForStations");
                Console.WriteLine(" 7:  CalculateDailyKPIsForModules");
                Console.WriteLine(" 8:  CalculateDailyKPIsForMachines");
                Console.WriteLine(" 9:  CalculateDailyKPIsForAreas");
                Console.WriteLine("10:  Calculate all Daily Types");
                Console.WriteLine("**************************************************************************");
                Console.WriteLine("11:  CalculateShiftKPIsForStations");
                Console.WriteLine("12:  CalculateShiftKPIsForModules");
                Console.WriteLine("13:  CalculateShiftKPIsForMachines");
                Console.WriteLine("14:  CalculateShiftKPIsForAreas");
                Console.WriteLine("15:  Calculate all Shift Types");
                Console.WriteLine("**************************************************************************");
                Console.WriteLine("16:  CalculateWeekKPIsForStations");
                Console.WriteLine("17:  CalculateWeekKPIsForModules");
                Console.WriteLine("18:  CalculateWeekKPIsForMachines");
                Console.WriteLine("19:  CalculateWeekKPIsForAreas");
                Console.WriteLine("20:  Calculate all Week Types");
                Console.WriteLine("**************************************************************************");
                Console.WriteLine("21:  CalculateMonthKPIsForStations");
                Console.WriteLine("22:  CalculateMonthKPIsForModules");
                Console.WriteLine("23:  CalculateMonthKPIsForMachines");
                Console.WriteLine("24:  CalculateMonthKPIsForAreas");
                Console.WriteLine("25:  Calculate all Month Types");
                Console.WriteLine("**************************************************************************");
                Console.WriteLine("26:  CalculateYearKPIsForStations");
                Console.WriteLine("27:  CalculateYearKPIsForModules");
                Console.WriteLine("28:  CalculateYearKPIsForMachines");
                Console.WriteLine("29:  CalculateYearKPIsForAreas");
                Console.WriteLine("30:  Calculate all Year Types");
                Console.WriteLine("**************************************************************************");
                Console.WriteLine("99: Calculate all Types");
                Console.WriteLine("**************************************************************************");

                selectionData.level1Menu = Console.ReadLine();
            }

            if (selectionData.level1Menu == "1")
            {
                selectionData.level1MenuName = "CalculateHourlyKPIsForStations";
                selectionData.calculateHourlyStationKPIs = new(CalculateKPIsType.HOURLY, CalculationType.STATION, stagingLevel);
            }
            else if (selectionData.level1Menu == "2")
            {
                selectionData.level1MenuName = "CalculateHourlyKPIsForModules";
                selectionData.calculateHourlyModuleKPIs = new(CalculateKPIsType.HOURLY, CalculationType.MODULE, stagingLevel);
            }
            else if (selectionData.level1Menu == "3")
            {
                selectionData.level1MenuName = "CalculateHourlyKPIsForMachines";
                selectionData.calculateHourlyMachineKPIs = new(CalculateKPIsType.HOURLY, CalculationType.MACHINE, stagingLevel);
            }
            else if (selectionData.level1Menu == "4")
            {
                selectionData.level1MenuName = "CalculateHourlyKPIsForAreas";
                selectionData.calculateHourlyAreaKPIs = new(CalculateKPIsType.HOURLY, CalculationType.AREA, stagingLevel);
            }
            else if (selectionData.level1Menu == "5")
            {
                selectionData.level1MenuName = "Calculate all Hourly Types";
                selectionData.calculateHourlyMachineKPIs = new(CalculateKPIsType.HOURLY, CalculationType.MACHINE, stagingLevel);
                selectionData.calculateHourlyStationKPIs = new(CalculateKPIsType.HOURLY, CalculationType.STATION, stagingLevel);
                selectionData.calculateHourlyModuleKPIs = new(CalculateKPIsType.HOURLY, CalculationType.MODULE, stagingLevel);
                selectionData.calculateHourlyAreaKPIs = new(CalculateKPIsType.HOURLY, CalculationType.AREA, stagingLevel);
            }
            else if (selectionData.level1Menu == "6")
            {
                selectionData.level1MenuName = "CalculateDailyKPIsForStations";
                selectionData.calculateDailyStationKPIs = new(CalculateKPIsType.DAILY, CalculationType.STATION, stagingLevel);
            }
            else if (selectionData.level1Menu == "7")
            {
                selectionData.level1MenuName = "CalculateDailyKPIsForModules";
                selectionData.calculateDailyModuleKPIs = new(CalculateKPIsType.DAILY, CalculationType.MODULE, stagingLevel);
            }
            else if (selectionData.level1Menu == "8")
            {
                selectionData.level1MenuName = "CalculateDailyKPIsForMachines";
                selectionData.calculateDailyMachineKPIs = new(CalculateKPIsType.DAILY, CalculationType.MACHINE, stagingLevel);
            }
            else if (selectionData.level1Menu == "9")
            {
                selectionData.level1MenuName = "CalculateDailyKPIsForAreas";
                selectionData.calculateDailyAreaKPIs = new(CalculateKPIsType.DAILY, CalculationType.AREA, stagingLevel);
            }
            else if (selectionData.level1Menu == "10")
            {
                selectionData.level1MenuName = "Calculate all Daily Types";
                selectionData.calculateDailyMachineKPIs = new(CalculateKPIsType.DAILY, CalculationType.MACHINE, stagingLevel);
                selectionData.calculateDailyStationKPIs = new(CalculateKPIsType.DAILY, CalculationType.STATION, stagingLevel);
                selectionData.calculateDailyModuleKPIs = new(CalculateKPIsType.DAILY, CalculationType.MODULE, stagingLevel);
                selectionData.calculateDailyAreaKPIs = new(CalculateKPIsType.DAILY, CalculationType.AREA, stagingLevel);
            }
            else if (selectionData.level1Menu == "11")
            {
                selectionData.level1MenuName = "CalculateShiftKPIsForStations";
                selectionData.calculateShiftStationKPIs = new(CalculateKPIsType.SHIFT, CalculationType.STATION, stagingLevel);
            }
            else if (selectionData.level1Menu == "12")
            {
                selectionData.level1MenuName = "CalculateShiftKPIsForModules";
                selectionData.calculateShiftModuleKPIs = new(CalculateKPIsType.SHIFT, CalculationType.MODULE, stagingLevel);
            }
            else if (selectionData.level1Menu == "13")
            {
                selectionData.level1MenuName = "CalculateShiftKPIsForMachines";
                selectionData.calculateShiftMachineKPIs = new(CalculateKPIsType.SHIFT, CalculationType.MACHINE, stagingLevel);
            }
            else if (selectionData.level1Menu == "14")
            {
                selectionData.level1MenuName = "CalculateShiftKPIsForAreas";
                selectionData.calculateShiftAreaKPIs = new(CalculateKPIsType.SHIFT, CalculationType.AREA, stagingLevel);
            }
            else if (selectionData.level1Menu == "15")
            {
                selectionData.level1MenuName = "Calculate all Shift Types";
                selectionData.calculateShiftMachineKPIs = new(CalculateKPIsType.SHIFT, CalculationType.MACHINE, stagingLevel);
                selectionData.calculateShiftStationKPIs = new(CalculateKPIsType.SHIFT, CalculationType.STATION, stagingLevel);
                selectionData.calculateShiftModuleKPIs = new(CalculateKPIsType.SHIFT, CalculationType.MODULE, stagingLevel);
                selectionData.calculateShiftAreaKPIs = new(CalculateKPIsType.SHIFT, CalculationType.AREA, stagingLevel);
            }
            else if (selectionData.level1Menu == "16")
            {
                selectionData.showDayMenu = false;
                selectionData.level1MenuName = "CalculateWeekKPIsForStations";
                selectionData.calculateWeeklyStationKPIs = new(CalculateKPIsType.WEEKLY, CalculationType.STATION, stagingLevel);
            }
            else if (selectionData.level1Menu == "17")
            {
                selectionData.showDayMenu = false;
                selectionData.level1MenuName = "CalculateWeekKPIsForModules";
                selectionData.calculateWeeklyModuleKPIs = new(CalculateKPIsType.WEEKLY, CalculationType.MODULE, stagingLevel);
            }
            else if (selectionData.level1Menu == "18")
            {
                selectionData.showDayMenu = false;
                selectionData.level1MenuName = "CalculateWeekKPIsForMachines";
                selectionData.calculateWeeklyMachineKPIs = new(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, stagingLevel);
            }
            else if (selectionData.level1Menu == "19")
            {
                selectionData.showDayMenu = false;
                selectionData.level1MenuName = "CalculateWeekKPIsForAreas";
                selectionData.calculateWeeklyAreaKPIs = new(CalculateKPIsType.WEEKLY, CalculationType.AREA, stagingLevel);
            }
            else if (selectionData.level1Menu == "20")
            {
                selectionData.showDayMenu = false;
                selectionData.level1MenuName = "Calculate all Shift Types";
                selectionData.calculateWeeklyMachineKPIs = new(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, stagingLevel);
                selectionData.calculateWeeklyStationKPIs = new(CalculateKPIsType.WEEKLY, CalculationType.STATION, stagingLevel);
                selectionData.calculateWeeklyModuleKPIs = new(CalculateKPIsType.WEEKLY, CalculationType.MODULE, stagingLevel);
                selectionData.calculateWeeklyAreaKPIs = new(CalculateKPIsType.WEEKLY, CalculationType.AREA, stagingLevel);
            }
            else if (selectionData.level1Menu == "21")
            {
                selectionData.showDayMenu = false;
                selectionData.level1MenuName = "CalculateMonthKPIsForStations";
                selectionData.calculateMonthlyStationKPIs = new(CalculateKPIsType.MONTHLY, CalculationType.STATION, stagingLevel);
            }
            else if (selectionData.level1Menu == "22")
            {
                selectionData.showDayMenu = false;
                selectionData.level1MenuName = "CalculateMonthKPIsForModules";
                selectionData.calculateMonthlyModuleKPIs = new(CalculateKPIsType.MONTHLY, CalculationType.MODULE, stagingLevel);
            }
            else if (selectionData.level1Menu == "23")
            {
                selectionData.showDayMenu = false;
                selectionData.level1MenuName = "CalculateMonthKPIsForMachines";
                selectionData.calculateMonthlyMachineKPIs = new(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, stagingLevel);
            }
            else if (selectionData.level1Menu == "24")
            {
                selectionData.showDayMenu = false;
                selectionData.level1MenuName = "CalculateMonthKPIsForAreas";
                selectionData.calculateMonthlyAreaKPIs = new(CalculateKPIsType.MONTHLY, CalculationType.AREA, stagingLevel);
            }
            else if (selectionData.level1Menu == "25")
            {
                selectionData.showDayMenu = false;
                selectionData.level1MenuName = "Calculate all Shift Types";
                selectionData.calculateMonthlyMachineKPIs = new(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, stagingLevel);
                selectionData.calculateMonthlyStationKPIs = new(CalculateKPIsType.MONTHLY, CalculationType.STATION, stagingLevel);
                selectionData.calculateMonthlyModuleKPIs = new(CalculateKPIsType.MONTHLY, CalculationType.MODULE, stagingLevel);
                selectionData.calculateMonthlyAreaKPIs = new(CalculateKPIsType.MONTHLY, CalculationType.AREA, stagingLevel);
            }
            else if (selectionData.level1Menu == "26")
            {
                selectionData.showMonthMenu = false;
                selectionData.showDayMenu = false;
                selectionData.level1MenuName = "CalculateYearKPIsForStations";
                selectionData.calculateYearlyStationKPIs = new(CalculateKPIsType.YEARLY, CalculationType.STATION, stagingLevel);
            }
            else if (selectionData.level1Menu == "27")
            {
                selectionData.showMonthMenu = false;
                selectionData.showDayMenu = false;
                selectionData.level1MenuName = "CalculateYearKPIsForModules";
                selectionData.calculateYearlyModuleKPIs = new(CalculateKPIsType.YEARLY, CalculationType.MODULE, stagingLevel);
            }
            else if (selectionData.level1Menu == "28")
            {
                selectionData.showMonthMenu = false;
                selectionData.showDayMenu = false;
                selectionData.level1MenuName = "CalculateYearKPIsForMachines";
                selectionData.calculateYearlyMachineKPIs = new(CalculateKPIsType.YEARLY, CalculationType.MACHINE, stagingLevel);
            }
            else if (selectionData.level1Menu == "29")
            {
                selectionData.showMonthMenu = false;
                selectionData.showDayMenu = false;
                selectionData.level1MenuName = "CalculateYearKPIsForAreas";
                selectionData.calculateYearlyAreaKPIs = new(CalculateKPIsType.YEARLY, CalculationType.AREA, stagingLevel);
            }
            else if (selectionData.level1Menu == "30")
            {
                selectionData.showMonthMenu = false;
                selectionData.showDayMenu = false;
                selectionData.level1MenuName = "Calculate all Shift Types";
                selectionData.calculateYearlyMachineKPIs = new(CalculateKPIsType.YEARLY, CalculationType.MACHINE, stagingLevel);
                selectionData.calculateYearlyStationKPIs = new(CalculateKPIsType.YEARLY, CalculationType.STATION, stagingLevel);
                selectionData.calculateYearlyModuleKPIs = new(CalculateKPIsType.YEARLY, CalculationType.MODULE, stagingLevel);
                selectionData.calculateYearlyAreaKPIs = new(CalculateKPIsType.YEARLY, CalculationType.AREA, stagingLevel);
            }




            else if (selectionData.level1Menu == "99")
            {
                selectionData.showMonthMenu = false;
                selectionData.showDayMenu = false;
                selectionData.level1MenuName = "Calculate all Types";
                selectionData.calculateDailyMachineKPIs = new(CalculateKPIsType.DAILY, CalculationType.MACHINE, stagingLevel);
                selectionData.calculateDailyStationKPIs = new(CalculateKPIsType.DAILY, CalculationType.STATION, stagingLevel);
                selectionData.calculateDailyModuleKPIs = new(CalculateKPIsType.DAILY, CalculationType.MODULE, stagingLevel);
                selectionData.calculateDailyAreaKPIs = new(CalculateKPIsType.DAILY, CalculationType.AREA, stagingLevel);

                selectionData.calculateHourlyMachineKPIs = new(CalculateKPIsType.HOURLY, CalculationType.MACHINE, stagingLevel);
                selectionData.calculateHourlyStationKPIs = new(CalculateKPIsType.HOURLY, CalculationType.STATION, stagingLevel);
                selectionData.calculateHourlyModuleKPIs = new(CalculateKPIsType.HOURLY, CalculationType.MODULE, stagingLevel);
                selectionData.calculateHourlyAreaKPIs = new(CalculateKPIsType.HOURLY, CalculationType.AREA, stagingLevel);

                selectionData.calculateShiftMachineKPIs = new(CalculateKPIsType.SHIFT, CalculationType.MACHINE, stagingLevel);
                selectionData.calculateShiftStationKPIs = new(CalculateKPIsType.SHIFT, CalculationType.STATION, stagingLevel);
                selectionData.calculateShiftModuleKPIs = new(CalculateKPIsType.SHIFT, CalculationType.MODULE, stagingLevel);
                selectionData.calculateShiftAreaKPIs = new(CalculateKPIsType.SHIFT, CalculationType.AREA, stagingLevel);

                selectionData.calculateWeeklyMachineKPIs = new(CalculateKPIsType.WEEKLY, CalculationType.MACHINE, stagingLevel);
                selectionData.calculateWeeklyStationKPIs = new(CalculateKPIsType.WEEKLY, CalculationType.STATION, stagingLevel);
                selectionData.calculateWeeklyModuleKPIs = new(CalculateKPIsType.WEEKLY, CalculationType.MODULE, stagingLevel);
                selectionData.calculateWeeklyAreaKPIs = new(CalculateKPIsType.WEEKLY, CalculationType.AREA, stagingLevel);

                selectionData.calculateMonthlyMachineKPIs = new(CalculateKPIsType.MONTHLY, CalculationType.MACHINE, stagingLevel);
                selectionData.calculateMonthlyStationKPIs = new(CalculateKPIsType.MONTHLY, CalculationType.STATION, stagingLevel);
                selectionData.calculateMonthlyModuleKPIs = new(CalculateKPIsType.MONTHLY, CalculationType.MODULE, stagingLevel);
                selectionData.calculateMonthlyAreaKPIs = new(CalculateKPIsType.MONTHLY, CalculationType.AREA, stagingLevel);

                selectionData.calculateYearlyMachineKPIs = new(CalculateKPIsType.YEARLY, CalculationType.MACHINE, stagingLevel);
                selectionData.calculateYearlyStationKPIs = new(CalculateKPIsType.YEARLY, CalculationType.STATION, stagingLevel);
                selectionData.calculateYearlyModuleKPIs = new(CalculateKPIsType.YEARLY, CalculationType.MODULE, stagingLevel);
                selectionData.calculateYearlyAreaKPIs = new(CalculateKPIsType.YEARLY, CalculationType.AREA, stagingLevel);
            }
            else
            {
                selectionData.level1MenuName = "Unknown";
            }

            return selectionData;
        }

        static public SelectionData PrintMenuLevel2(SelectionData selectionData, string? testData = null)
        {
            if (testData != null)
            {
                selectionData.level2Menu = testData;
            }
            else
            {
                Console.Clear();
                Console.WriteLine("**************************************************************************");
                Console.WriteLine(selectionData.level1MenuName);
                Console.WriteLine("**************************************************************************");
                Console.WriteLine("1: Recalculate year");
                if (selectionData.showMonthMenu) Console.WriteLine("2: Recalculate month");
                if (selectionData.showDayMenu) Console.WriteLine("3: Recalculate day");
                Console.WriteLine("**************************************************************************");

                selectionData.level2Menu = Console.ReadLine();
            }

            if (selectionData.level2Menu == "1")
            {
                if (testData != null)
                {
                    selectionData.level2MenuYear = testData;
                }
                else
                {
                    Console.WriteLine("Year to recalculate (integer value)");
                    selectionData.level2MenuYear = Console.ReadLine();
                }
            }
            else if (selectionData.level2Menu == "2" && selectionData.showMonthMenu)
            {
                if (testData != null)
                {
                    selectionData.level2MenuYear = testData;
                    selectionData.level2MenuMonth = testData;
                }
                else
                {
                    Console.WriteLine("Year to recalculate (integer value)");
                    selectionData.level2MenuYear = Console.ReadLine();
                    Console.WriteLine("Month to recalculate (integer value)");
                    selectionData.level2MenuMonth = Console.ReadLine();
                }
            }
            else if (selectionData.level2Menu == "3" && selectionData.showDayMenu)
            {
                if (testData != null)
                {
                    selectionData.level2MenuYear = testData;
                    selectionData.level2MenuMonth = testData;
                    selectionData.level2MenuDay = testData;
                }
                else
                {
                    Console.WriteLine("Year to recalculate (integer value)");
                    selectionData.level2MenuYear = Console.ReadLine();
                    Console.WriteLine("Month to recalculate (integer value)");
                    selectionData.level2MenuMonth = Console.ReadLine();
                    Console.WriteLine("Day to recalculate (integer value)");
                    selectionData.level2MenuDay = Console.ReadLine();
                }
            }
            else
            {
                selectionData.level2Menu = "Unknown";
            }

            return selectionData;
        }

        static public SelectionData GetDatabase(SelectionData selectionData, string? testData = null)
        {
            if (testData != null)
            {
                selectionData.db = testData;
            }
            else
            {
                Console.Clear();
                Console.WriteLine("**************************************************************************");
                Console.WriteLine("DB name from settings file to recalculate");
                Console.WriteLine("**************************************************************************");
                selectionData.db = Console.ReadLine();
            }

            if (selectionData.appSettings.Settings == null || selectionData.appSettings.Settings.settingsKpiCalculator == null || selectionData.appSettings.Settings.settingsKpiCalculator.mssql == null)
            {
                throw new Exception("No settings found in settings file");
                
            }
            return selectionData;
        }

        static public void Run(SelectionData selectionData)
        {
            DateTime startTime = DateTime.Now;
            //Hourly
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth == null && selectionData.level2MenuYear != null && selectionData.calculateHourlyMachineKPIs != null)
            {
                selectionData.calculateHourlyMachineKPIs.ReCalculateKPIsForYear(int.Parse(selectionData.level2MenuYear), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth == null && selectionData.level2MenuYear != null && selectionData.calculateHourlyStationKPIs != null)
            {
                selectionData.calculateHourlyStationKPIs.ReCalculateKPIsForYear(int.Parse(selectionData.level2MenuYear), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth == null && selectionData.level2MenuYear != null && selectionData.calculateHourlyModuleKPIs != null)
            {
                selectionData.calculateHourlyModuleKPIs.ReCalculateKPIsForYear(int.Parse(selectionData.level2MenuYear), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth == null && selectionData.level2MenuYear != null && selectionData.calculateHourlyAreaKPIs != null)
            {
                selectionData.calculateHourlyAreaKPIs.ReCalculateKPIsForYear(int.Parse(selectionData.level2MenuYear), selectionData.msSQL);
            }

            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateHourlyMachineKPIs != null)
            {
                selectionData.calculateHourlyMachineKPIs.ReCalculateKPIsForMonth(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateHourlyStationKPIs != null)
            {
                selectionData.calculateHourlyStationKPIs.ReCalculateKPIsForMonth(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateHourlyModuleKPIs != null)
            {
                selectionData.calculateHourlyModuleKPIs.ReCalculateKPIsForMonth(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateHourlyAreaKPIs != null)
            {
                selectionData.calculateHourlyAreaKPIs.ReCalculateKPIsForMonth(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), selectionData.msSQL);
            }

            if (selectionData.level2MenuDay != null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateHourlyMachineKPIs != null)
            {
                selectionData.calculateHourlyMachineKPIs.ReCalculateKPIsForDay(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), int.Parse(selectionData.level2MenuDay), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay != null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateHourlyStationKPIs != null)
            {
                selectionData.calculateHourlyStationKPIs.ReCalculateKPIsForDay(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), int.Parse(selectionData.level2MenuDay), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay != null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateHourlyModuleKPIs != null)
            {
                selectionData.calculateHourlyModuleKPIs.ReCalculateKPIsForDay(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), int.Parse(selectionData.level2MenuDay), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay != null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateHourlyAreaKPIs != null)
            {
                selectionData.calculateHourlyAreaKPIs.ReCalculateKPIsForDay(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), int.Parse(selectionData.level2MenuDay), selectionData.msSQL);
            }

            //Daily
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth == null && selectionData.level2MenuYear != null && selectionData.calculateDailyMachineKPIs != null)
            {
                selectionData.calculateDailyMachineKPIs.ReCalculateKPIsForYear(int.Parse(selectionData.level2MenuYear), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth == null && selectionData.level2MenuYear != null && selectionData.calculateDailyStationKPIs != null)
            {
                selectionData.calculateDailyStationKPIs.ReCalculateKPIsForYear(int.Parse(selectionData.level2MenuYear), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth == null && selectionData.level2MenuYear != null && selectionData.calculateDailyModuleKPIs != null)
            {
                selectionData.calculateDailyModuleKPIs.ReCalculateKPIsForYear(int.Parse(selectionData.level2MenuYear), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth == null && selectionData.level2MenuYear != null && selectionData.calculateDailyAreaKPIs != null)
            {
                selectionData.calculateDailyAreaKPIs.ReCalculateKPIsForYear(int.Parse(selectionData.level2MenuYear), selectionData.msSQL);
            }

            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateDailyMachineKPIs != null)
            {
                selectionData.calculateDailyMachineKPIs.ReCalculateKPIsForMonth(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateDailyStationKPIs != null)
            {
                selectionData.calculateDailyStationKPIs.ReCalculateKPIsForMonth(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateDailyModuleKPIs != null)
            {
                selectionData.calculateDailyModuleKPIs.ReCalculateKPIsForMonth(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateDailyAreaKPIs != null)
            {
                selectionData.calculateDailyAreaKPIs.ReCalculateKPIsForMonth(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), selectionData.msSQL);
            }

            if (selectionData.level2MenuDay != null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateDailyMachineKPIs != null)
            {
                selectionData.calculateDailyMachineKPIs.ReCalculateKPIsForDay(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), int.Parse(selectionData.level2MenuDay), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay != null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateDailyStationKPIs != null)
            {
                selectionData.calculateDailyStationKPIs.ReCalculateKPIsForDay(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), int.Parse(selectionData.level2MenuDay), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay != null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateDailyModuleKPIs != null)
            {
                selectionData.calculateDailyModuleKPIs.ReCalculateKPIsForDay(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), int.Parse(selectionData.level2MenuDay), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay != null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateDailyAreaKPIs != null)
            {
                selectionData.calculateDailyAreaKPIs.ReCalculateKPIsForDay(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), int.Parse(selectionData.level2MenuDay), selectionData.msSQL);
            }

            //Shift
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth == null && selectionData.level2MenuYear != null && selectionData.calculateShiftMachineKPIs != null)
            {
                selectionData.calculateShiftMachineKPIs.ReCalculateKPIsForYear(int.Parse(selectionData.level2MenuYear), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth == null && selectionData.level2MenuYear != null && selectionData.calculateShiftStationKPIs != null)
            {
                selectionData.calculateShiftStationKPIs.ReCalculateKPIsForYear(int.Parse(selectionData.level2MenuYear), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth == null && selectionData.level2MenuYear != null && selectionData.calculateShiftModuleKPIs != null)
            {
                selectionData.calculateShiftModuleKPIs.ReCalculateKPIsForYear(int.Parse(selectionData.level2MenuYear), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth == null && selectionData.level2MenuYear != null && selectionData.calculateShiftAreaKPIs != null)
            {
                selectionData.calculateShiftAreaKPIs.ReCalculateKPIsForYear(int.Parse(selectionData.level2MenuYear), selectionData.msSQL);
            }

            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateShiftMachineKPIs != null)
            {
                selectionData.calculateShiftMachineKPIs.ReCalculateKPIsForMonth(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateShiftStationKPIs != null)
            {
                selectionData.calculateShiftStationKPIs.ReCalculateKPIsForMonth(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateShiftModuleKPIs != null)
            {
                selectionData.calculateShiftModuleKPIs.ReCalculateKPIsForMonth(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateShiftAreaKPIs != null)
            {
                selectionData.calculateShiftAreaKPIs.ReCalculateKPIsForMonth(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), selectionData.msSQL);
            }

            if (selectionData.level2MenuDay != null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateShiftMachineKPIs != null)
            {
                selectionData.calculateShiftMachineKPIs.ReCalculateKPIsForDay(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), int.Parse(selectionData.level2MenuDay), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay != null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateShiftStationKPIs != null)
            {
                selectionData.calculateShiftStationKPIs.ReCalculateKPIsForDay(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), int.Parse(selectionData.level2MenuDay), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay != null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateShiftModuleKPIs != null)
            {
                selectionData.calculateShiftModuleKPIs.ReCalculateKPIsForDay(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), int.Parse(selectionData.level2MenuDay), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay != null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateShiftAreaKPIs != null)
            {
                selectionData.calculateShiftAreaKPIs.ReCalculateKPIsForDay(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), int.Parse(selectionData.level2MenuDay), selectionData.msSQL);
            }

            //Weekly
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth == null && selectionData.level2MenuYear != null && selectionData.calculateWeeklyMachineKPIs != null)
            {
                selectionData.calculateWeeklyMachineKPIs.ReCalculateKPIsForYear(int.Parse(selectionData.level2MenuYear), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth == null && selectionData.level2MenuYear != null && selectionData.calculateWeeklyStationKPIs != null)
            {
                selectionData.calculateWeeklyStationKPIs.ReCalculateKPIsForYear(int.Parse(selectionData.level2MenuYear), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth == null && selectionData.level2MenuYear != null && selectionData.calculateWeeklyModuleKPIs != null)
            {
                selectionData.calculateWeeklyModuleKPIs.ReCalculateKPIsForYear(int.Parse(selectionData.level2MenuYear), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth == null && selectionData.level2MenuYear != null && selectionData.calculateWeeklyAreaKPIs != null)
            {
                selectionData.calculateWeeklyAreaKPIs.ReCalculateKPIsForYear(int.Parse(selectionData.level2MenuYear), selectionData.msSQL);
            }

            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateWeeklyMachineKPIs != null)
            {
                selectionData.calculateWeeklyMachineKPIs.ReCalculateKPIsForMonth(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateWeeklyStationKPIs != null)
            {
                selectionData.calculateWeeklyStationKPIs.ReCalculateKPIsForMonth(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateWeeklyModuleKPIs != null)
            {
                selectionData.calculateWeeklyModuleKPIs.ReCalculateKPIsForMonth(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateWeeklyAreaKPIs != null)
            {
                selectionData.calculateWeeklyAreaKPIs.ReCalculateKPIsForMonth(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), selectionData.msSQL);
            }

            //Monthly
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth == null && selectionData.level2MenuYear != null && selectionData.calculateMonthlyMachineKPIs != null)
            {
                selectionData.calculateMonthlyMachineKPIs.ReCalculateKPIsForYear(int.Parse(selectionData.level2MenuYear), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth == null && selectionData.level2MenuYear != null && selectionData.calculateMonthlyStationKPIs != null)
            {
                selectionData.calculateMonthlyStationKPIs.ReCalculateKPIsForYear(int.Parse(selectionData.level2MenuYear), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth == null && selectionData.level2MenuYear != null && selectionData.calculateMonthlyModuleKPIs != null)
            {
                selectionData.calculateMonthlyModuleKPIs.ReCalculateKPIsForYear(int.Parse(selectionData.level2MenuYear), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth == null && selectionData.level2MenuYear != null && selectionData.calculateMonthlyAreaKPIs != null)
            {
                selectionData.calculateMonthlyAreaKPIs.ReCalculateKPIsForYear(int.Parse(selectionData.level2MenuYear), selectionData.msSQL);
            }

            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateMonthlyMachineKPIs != null)
            {
                selectionData.calculateMonthlyMachineKPIs.ReCalculateKPIsForMonth(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateMonthlyStationKPIs != null)
            {
                selectionData.calculateMonthlyStationKPIs.ReCalculateKPIsForMonth(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateMonthlyModuleKPIs != null)
            {
                selectionData.calculateMonthlyModuleKPIs.ReCalculateKPIsForMonth(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth != null && selectionData.level2MenuYear != null && selectionData.calculateMonthlyAreaKPIs != null)
            {
                selectionData.calculateMonthlyAreaKPIs.ReCalculateKPIsForMonth(int.Parse(selectionData.level2MenuYear), int.Parse(selectionData.level2MenuMonth), selectionData.msSQL);
            }

            //Yearly
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth == null && selectionData.level2MenuYear != null && selectionData.calculateYearlyMachineKPIs != null)
            {
                selectionData.calculateYearlyMachineKPIs.ReCalculateKPIsForYear(int.Parse(selectionData.level2MenuYear), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth == null && selectionData.level2MenuYear != null && selectionData.calculateYearlyStationKPIs != null)
            {
                selectionData.calculateYearlyStationKPIs.ReCalculateKPIsForYear(int.Parse(selectionData.level2MenuYear), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth == null && selectionData.level2MenuYear != null && selectionData.calculateYearlyModuleKPIs != null)
            {
                selectionData.calculateYearlyModuleKPIs.ReCalculateKPIsForYear(int.Parse(selectionData.level2MenuYear), selectionData.msSQL);
            }
            if (selectionData.level2MenuDay == null && selectionData.level2MenuMonth == null && selectionData.level2MenuYear != null && selectionData.calculateYearlyAreaKPIs != null)
            {
                selectionData.calculateYearlyAreaKPIs.ReCalculateKPIsForYear(int.Parse(selectionData.level2MenuYear), selectionData.msSQL);
            }

            Console.WriteLine("Calculation took: " + (DateTime.Now - startTime));
        }
    }
}
