
using KBBasics.SetupForFileSystem;
using Microsoft.Extensions.Logging;
using System.Runtime.Versioning;

namespace KBBasicsTest
{
    [TestClass]
    public class Logger
    {
        [TestMethod]
        [SupportedOSPlatform("windows")]
        public void CreateLoggerConsoleTest()
        {
            KBBasics.Logger logger = new();
            logger.Log(KBBasics.LogLevel.INFO,"Test");
        }

//        [TestMethod]
//        [SupportedOSPlatform("windows")]
//        public void CreateLoggerEventLogTest()
//        {
//            KBBasics.Logger logger = new("eventLogName", "eventSourceName", KBBasics.LogType.EVENT_LOG);
//            logger.Log(KBBasics.LogLevel.ERROR, "Test");
//        }
    }
}